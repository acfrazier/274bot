//! Live: Elkoy's Tree Gnome Village maze escorts on the wire — the live
//! twin of the nav `derive_transports_emits_elkoy_escort_both_ways` unit
//! test. Waits for the slot `ingame && scene_state == 2`, then loads the
//! process nav pack and asserts the two `TransportKind::Npc` escort edges
//! are on it: the maze-side Elkoy (npc 473) at (2504,3191) escorts into
//! the village (`to` the maze coord (2515,3159)) and the village Elkoy
//! (npc 474) at (2514,3159) escorts out (`to` the entrance coord
//! (2504,3192)), each carrying the Tree Gnome Village quest req, and that
//! `find_with` with a WorldState proving that quest still routes from the
//! maze-side Elkoy's tile to the village on the pack, with the escort as
//! a `Transport` Npc leg. Either failure exits 1 (rs2b0t style). Route
//! detail prints only under `BOT_DEBUG=1`.
//!
//! `nav_elkoy_follow` is the execute twin — the same `nav_elkoy` scenario
//! `panel-play --live script_nav_elkoy` drives. The scenario seeds Tree
//! Gnome Village green (`~completequests` + dialog drain), cheat-teles to
//! the maze-side Elkoy, `Follow`s into the village (across the hedge
//! maze, whose 1-tick escort hop beats the maze walk in the router, so
//! the route executes the packed escort edge), the traveller answers
//! Elkoy's escort dialog, and PASSes on `TravelOutcome::Arrived` at the
//! packed `edge.to`.
//!
//! Run with the engine up and the rebaked v5 pack at the standard path:
//! `LIVE=1 cargo test -p e2e --test nav_elkoy -- --ignored --test-threads=1 --nocapture`

mod common;

use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use api::snapshot::WorldTile;
use common::{fail, live, mint_seed, options, profiles, wait_ingame};
use host_play::run_with_io;
use nav::router::{find_with, FindOptions, Leg};
use nav::transport::TransportKind;
use nav::world::NavWorld;
use scenario::{default_pack_path, RunnerStatus, ScenarioRunner};

/// The maze entrance coord (`^elkoy_entrance_coord = 0_39_49_8_56`).
const ENTRANCE: WorldTile = WorldTile {
    x: 2504,
    z: 3192,
    level: 0,
};
/// The village (maze) coord (`^elkoy_maze_coord = 0_39_49_19_23`).
const MAZE: WorldTile = WorldTile {
    x: 2515,
    z: 3159,
    level: 0,
};
/// The maze-side Elkoy (npc 473, m39_49 local (8,55)): one tile south of
/// the entrance coord.
const ELKOY_MAZE_SIDE: WorldTile = WorldTile {
    x: 2504,
    z: 3191,
    level: 0,
};

#[test]
#[ignore = "requires a local 274 engine, a rebaked v5 nav pack, and LIVE=1"]
fn nav_elkoy() {
    if !live() {
        return;
    }

    // Single slot with the mainland hop (lands the Lumbridge courtyard).
    let seed = [("test", "test")];
    let mut opts = options();
    opts.mainland = true;
    let play = run_with_io(&opts, profiles(&seed), |_| (None, None), |_, _, _| {});
    wait_ingame(&play, 1, Duration::from_secs(150), "nav_elkoy");

    let world = NavWorld::load_pack(&default_pack_path())
        .unwrap_or_else(|e| fail(&format!("nav_elkoy: nav pack must load: {e:?}")));
    let elk: Vec<_> = world
        .graph
        .edges
        .iter()
        .filter(|e| e.kind == TransportKind::Npc && (e.to == ENTRANCE || e.to == MAZE))
        .cloned()
        .collect();
    if elk.len() != 2 {
        fail(&format!(
            "nav_elkoy: pack carries {} Elkoy escort edges, need 2 \
             (rebake with `cargo run -p nav --bin nav-pack`)",
            elk.len()
        ));
    }
    if !elk.iter().any(|e| e.at == ELKOY_MAZE_SIDE && e.to == MAZE) {
        fail(&format!(
            "nav_elkoy: the maze-side Elkoy {ELKOY_MAZE_SIDE:?} -> village {MAZE:?} \
             escort is missing (rebake with `cargo run -p nav --bin nav-pack`)"
        ));
    }
    if !elk.iter().any(|e| e.to == ENTRANCE) {
        fail(&format!(
            "nav_elkoy: the village Elkoy -> entrance {ENTRANCE:?} escort is missing \
             (rebake with `cargo run -p nav --bin nav-pack`)"
        ));
    }
    for e in &elk {
        if e.option != 1 {
            fail(&format!(
                "nav_elkoy: escort edge {e:?} is not Talk-to (op 1)"
            ));
        }
        if !e.quest_req.iter().any(|q| q == "Tree Gnome Village") {
            fail(&format!(
                "nav_elkoy: escort edge {e:?} lacks the Tree Gnome Village quest req"
            ));
        }
    }
    // The maze-side Elkoy's tile reaches the village through his escort
    // hop (the traveller walks no maze tiles) — the escort edge carries
    // the Tree Gnome Village quest req, so the proof must state the quest
    // done: the fail-closed empty state refuses the gated hop.
    let mut state = nav::WorldState::empty();
    state.quests.insert("Tree Gnome Village".to_string());
    find_with(
        &world.collision,
        &world.graph,
        ELKOY_MAZE_SIDE,
        MAZE,
        FindOptions::default(),
        &state,
    )
    .map(|route| {
        if route.dest != MAZE {
            fail(&format!(
                "nav_elkoy: route ends at {:?}, not the village {MAZE:?}",
                route.dest
            ));
        }
        if !route
            .legs
            .iter()
            .any(|l| matches!(l, Leg::Transport { edge } if edge.kind == TransportKind::Npc))
        {
            fail(&format!(
                "nav_elkoy: the maze-side -> village route carries no Transport Npc \
                 leg ({:?})",
                route.legs
            ));
        }
        if nav::debug_enabled() {
            println!(
                "nav_elkoy: maze-side elkoy -> village routed ({:.0} ticks, {} legs)",
                route.ticks,
                route.legs.len()
            );
        }
    })
    .unwrap_or_else(|e| {
        fail(&format!(
            "nav_elkoy: maze-side elkoy {ELKOY_MAZE_SIDE:?} -> village {MAZE:?} \
             is NoPath ({e:?})"
        ))
    });
    println!(
        "PASS: nav_elkoy pack carries {} Elkoy escort edges ({} edges, {} npc hops)",
        elk.len(),
        world.graph.edges.len(),
        world
            .graph
            .edges
            .iter()
            .filter(|e| e.kind == TransportKind::Npc)
            .count()
    );
}

/// The execute twin: the `nav_elkoy` scenario run headlessly, exactly
/// like `panel-play --live script_nav_elkoy`. One slot; PASS is the
/// runner's proof — `arrived` at the packed maze coord (2515,3159), the
/// maze-side escort edge's `to`.
#[test]
#[ignore = "requires a local 274 engine, nav pack, and LIVE=1"]
fn nav_elkoy_follow() {
    if !live() {
        return;
    }

    let scenario = scenario::get("nav_elkoy").expect("nav_elkoy scenario in registry");
    let mainland = scenario.seed.mainland;
    let n = scenario.seed.profiles.len();
    let runner = Arc::new(Mutex::new(ScenarioRunner::new(scenario)));
    // Mint a fresh per-run account: the engine auto-registers unknown
    // names, so this run never logs the shared `test` save.
    let entries = {
        let mut r = runner.lock().unwrap();
        r.set_shot_sink(Box::new(|_, _| {}));
        mint_seed(&mut r, n)
    };
    let mut opts = options();
    opts.mainland = mainland;
    let play = run_with_io(&opts, profiles(&entries), |_| (None, None), {
        let runner = Arc::clone(&runner);
        move |c, name, hold| {
            let mut r = runner.lock().unwrap();
            if r.drives(name) {
                r.tick_with_hold(c, hold);
            } else if let Some(index) = r.companion_for(name) {
                r.companion_tick(index, c);
            }
        }
    });
    runner.lock().unwrap().set_obj_names(play.obj_names());

    wait_ingame(&play, 1, Duration::from_secs(150), "nav_elkoy_follow");

    let deadline = Instant::now() + Duration::from_secs(360);
    loop {
        let (status, evidence) = {
            let r = runner.lock().unwrap();
            (r.status(), r.evidence().cloned())
        };
        let record = evidence.as_ref().map(|ev| ev.to_json()).unwrap_or_default();
        match status {
            RunnerStatus::Passed => {
                println!("PASS: nav_elkoy_follow {record}");
                return;
            }
            RunnerStatus::Failed(msg) => {
                eprintln!("FAIL: nav_elkoy_follow {record}");
                fail(&format!("nav_elkoy_follow: {msg}"));
            }
            other => {
                if Instant::now() >= deadline {
                    fail(&format!(
                        "nav_elkoy_follow: no terminal status within 360s ({other:?})"
                    ));
                }
                std::thread::sleep(Duration::from_millis(250));
            }
        }
    }
}
