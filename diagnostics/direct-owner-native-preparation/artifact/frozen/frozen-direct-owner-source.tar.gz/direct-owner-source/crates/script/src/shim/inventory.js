// Our Inventory module: reads posted inv rows; item handles queue held/use-on
// ops on `__rs2b0t_host.interact`. Missing members throw `not impl`.
import { snap, notImpl, queue, proxy } from '../../shim/_kernel.js';

function rows() {
    return snap().inv || [];
}

function capacity() {
    const h = globalThis.__rs2b0t_host || {};
    if (typeof h.invSize === 'number') return h.invSize;
    return typeof snap().inv_size === 'number' ? snap().inv_size : 0;
}

function useOnKind(target) {
    const cn = target?.constructor?.name;
    if (cn === 'Npc') return 'npc';
    if (cn === 'Loc') return 'loc';
    if (cn === 'GroundItem') return 'obj';
    if (cn === 'Player') return 'player';
    throw notImpl('Inventory.useOn');
}

function held(row) {
    return {
        name: row.name,
        count: row.count,
        id: row.id ?? 0,
        slot: row.slot ?? 0,
        noted: row.noted === true,
        cert: row.cert ?? -1,
        interact(action) {
            queue({ op: 'held', name: row.name, action: String(action) });
            return true;
        },
        actions() {
            return Array.isArray(row.ops) ? row.ops.slice() : [];
        },
        useOn(target) {
            if (!target) return false;
            if (target.name && !target.snap) {
                queue({
                    op: 'use-on',
                    name: row.name,
                    kind: 'inv',
                    target_name: target.name,
                    x: 0,
                    z: 0,
                    level: 0,
                    index: null,
                });
                return true;
            }
            if (target.name && target.snap) {
                const kind = useOnKind(target);
                queue({
                    op: 'use-on',
                    name: row.name,
                    kind,
                    target_name: target.name ?? target.snap.name ?? null,
                    x: target.snap?.x ?? 0,
                    z: target.snap?.z ?? 0,
                    level: target.snap?.level ?? 0,
                    index:
                        kind === 'npc'
                            ? (target.snap?.index ?? target.index ?? null)
                            : null,
                });
                return true;
            }
            return false;
        },
    };
}

export const Inventory = new Proxy(
    {
        count(name) {
            const wanted = String(name).toLowerCase();
            return rows()
                .filter((r) => r && typeof r.name === 'string' && r.name.toLowerCase() === wanted)
                .reduce((sum, row) => sum + (typeof row.count === 'number' ? row.count : 0), 0);
        },
        countById(id) {
            const rs = rows();
            if (rs.length === 0) {
                return 0;
            }
            if (!rs.some((r) => r && typeof r.id === 'number' && r.id !== 0)) {
                throw notImpl('Inventory.countById');
            }
            const want = Number(id);
            return rs
                .filter((r) => r && r.id === want)
                .reduce((sum, row) => sum + (typeof row.count === 'number' ? row.count : 0), 0);
        },
        first(name) {
            const wanted = String(name).toLowerCase();
            const row = rows().find(
                (r) => r && typeof r.name === 'string' && r.name.toLowerCase() === wanted,
            );
            return row ? held(row) : null;
        },
        items() {
            return rows().filter((r) => r && r.name).map((r) => held(r));
        },
        contains(name) {
            return Inventory.first(name) !== null;
        },
        used() {
            return rows().filter((r) => r && r.name).length;
        },
        isFull() {
            const size = capacity();
            return size > 0 && Inventory.used() >= size;
        },
        free() {
            const size = capacity();
            return size > 0 ? Math.max(0, size - Inventory.used()) : 0;
        },
    },
    {
        get(target, prop) {
            if (typeof prop === 'symbol') return target[prop];
            if (prop in target) return target[prop];
            throw notImpl('Inventory.' + String(prop));
        },
    },
);
