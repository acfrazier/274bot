//! Game Image: RGBA8 765×503 texture filled from the mailbox's taken
//! `FrameOutput`s.
//!
//! The client paints a 765×503 applet (`client::APPLET_W/H`); the panel keeps
//! the texture at exactly that size and lets the Image widget scale it.
//!
//! Two consume paths (the shared-device seam): the CPU backend's `PixMap`
//! frames upload into the panel-owned texture; the GPU backend's `Texture`
//! frames register the client's frame-texture view directly with the ImGui
//! renderer — the client renders on the panel's injected device, so the
//! frame never round-trips through the CPU. `frame_pixels` keeps the
//! read-back fallback for consumers that still want CPU pixels.

use crate::window::Gpu;
use client::graphics::PixMap;
use client::render::backend::{FrameOutput, TextureHandle};
use dear_imgui_rs::TextureId;

/// Applet draw size the client always paints (never DPI-scaled).
pub const APPLET_W: u32 = 765;
pub const APPLET_H: u32 = 503;

/// The panel window's GPU calls the game-view texture paths need, abstracted
/// so the consume path is unit-testable without a full ImGui renderer (the
/// `Texture`-frame tests drive a recording registrar on a headless device).
pub trait FrameGpu {
    fn device(&self) -> &wgpu::Device;
    fn queue(&self) -> &wgpu::Queue;
    fn register_texture(&mut self, texture: &wgpu::Texture, view: &wgpu::TextureView) -> TextureId;
    fn unregister_texture(&mut self, tex_id: TextureId);
}

impl FrameGpu for Gpu<'_> {
    fn device(&self) -> &wgpu::Device {
        Gpu::device(self)
    }
    fn queue(&self) -> &wgpu::Queue {
        Gpu::queue(self)
    }
    fn register_texture(&mut self, texture: &wgpu::Texture, view: &wgpu::TextureView) -> TextureId {
        Gpu::register_texture(self, texture, view)
    }
    fn unregister_texture(&mut self, tex_id: TextureId) {
        Gpu::unregister_texture(self, tex_id)
    }
}

/// Game texture registered with the ImGui renderer. A new view owns only a
/// 1×1 empty placeholder; the APPLET_W×APPLET_H CPU texture is lazy and the
/// Image widget's display size remains independent of the backing texture.
pub struct GameView {
    pub tex_id: TextureId,
    /// A 1×1 empty placeholder avoids allocating a full upload texture for GPU-only views.
    placeholder: wgpu::Texture,
    placeholder_view: wgpu::TextureView,
    /// Allocated lazily when a CPU frame is actually presented.
    cpu_owner: Option<CpuOwner>,
    rgba: Option<Vec<u8>>,
    /// Which texture `tex_id` currently names: the panel-owned `texture`
    /// (the CPU/upload path) or a client's frame texture (the shared GPU
    /// path). wgpu handles compare by id, so re-registration happens only
    /// on a mode switch or a new client frame texture (a slot restart).
    bound: Bound,
    /// `BOT_DEBUG` / unit-test counters for present routing.
    pub present_stats: PresentStats,
}

struct CpuOwner {
    texture: wgpu::Texture,
    view: wgpu::TextureView,
}

/// Which texture the view's `tex_id` names. `Client` holds the client's
/// frame texture (a cheap clone) so the direct-bind path detects a new
/// client texture without re-registering every frame.
#[derive(Clone, PartialEq)]
enum Bound {
    /// The panel-owned `texture`, registered by [`GameView::init`] (and
    /// re-registered after a GPU-frame spell).
    Owned,
    /// A client's frame texture (the shared-device seam), registered
    /// directly into the ImGui renderer.
    Client(wgpu::Texture),
}

/// `BOT_DEBUG=1` present counters for one [`GameView`] (rail tile or game pane).
#[derive(Clone, Copy, Debug, Default)]
pub struct PresentStats {
    pub pixmap: u64,
    pub tex: u64,
    pub bind_noop: u64,
    pub bind_rereg: u64,
}

impl GameView {
    /// Create and register the empty placeholder. The 765×503 RGBA8 CPU
    /// texture is created only if a CPU frame is presented. Call once from
    /// the first frame, when `gpu.device()` is live.
    pub fn init(gpu: &mut impl FrameGpu) -> Self {
        let placeholder = gpu.device().create_texture(&wgpu::TextureDescriptor {
            label: Some("274 game image placeholder"),
            size: wgpu::Extent3d {
                width: 1,
                height: 1,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8Unorm,
            usage: wgpu::TextureUsages::TEXTURE_BINDING
                | wgpu::TextureUsages::COPY_DST
                | wgpu::TextureUsages::COPY_SRC,
            view_formats: &[],
        });
        let placeholder_view = placeholder.create_view(&wgpu::TextureViewDescriptor::default());
        gpu.queue().write_texture(
            wgpu::TexelCopyTextureInfo {
                texture: &placeholder,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            // Match the old zero-initialized, not-yet-uploaded applet texture.
            &[0, 0, 0, 0],
            wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(4),
                rows_per_image: Some(1),
            },
            wgpu::Extent3d {
                width: 1,
                height: 1,
                depth_or_array_layers: 1,
            },
        );
        let tex_id = gpu.register_texture(&placeholder, &placeholder_view);
        Self {
            tex_id,
            placeholder,
            placeholder_view,
            cpu_owner: None,
            rgba: None,
            bound: Bound::Owned,
            present_stats: PresentStats::default(),
        }
    }

    /// Route a taken frame to the view: `PixMap` (CPU backend) frames
    /// upload into the panel-owned texture; `Texture` (GPU backend) frames
    /// bind the client's frame-texture view directly. The GPU arm never
    /// reads the frame back — the client and panel share one device.
    pub fn present(&mut self, gpu: &mut impl FrameGpu, frame: FrameOutput) {
        match frame {
            FrameOutput::PixMap(pix) => {
                self.present_stats.pixmap += 1;
                self.upload(gpu, &pixmap_pixels(&pix));
            }
            FrameOutput::Texture(handle) => {
                self.present_stats.tex += 1;
                self.bind(gpu, &handle);
            }
        }
    }

    /// Direct-bind a client GPU frame (the shared-device seam): register
    /// the client's frame-texture view with the ImGui renderer instead of
    /// reading it back, and make the Image draw it. Re-registers only when
    /// the underlying client texture changes — a stable present texture
    /// from the GPU backend makes the per-frame case a no-op. A
    /// transition unregisters the texture the view last drew, so the
    /// renderer's texture cache stays bounded across slot restarts.
    pub fn bind(&mut self, gpu: &mut impl FrameGpu, handle: &TextureHandle) {
        let texture = handle.view.texture();
        if matches!(&self.bound, Bound::Client(held) if held == texture) {
            self.present_stats.bind_noop += 1;
            return;
        }
        self.present_stats.bind_rereg += 1;
        gpu.unregister_texture(self.tex_id);
        self.tex_id = gpu.register_texture(texture, &handle.view);
        self.bound = Bound::Client(texture.clone());
    }

    /// Stop drawing a client's `frame_texture` (GPU→CPU while the slot
    /// still paints). Re-registers the panel-owned texture so ImGui cannot
    /// sample a GPU head that the slot thread is about to drop.
    pub fn unbind_client(&mut self, gpu: &mut impl FrameGpu) {
        if self.bound == Bound::Owned {
            return;
        }
        gpu.unregister_texture(self.tex_id);
        let (texture, view) = self.owned_texture_view();
        self.tex_id = gpu.register_texture(texture, view);
        self.bound = Bound::Owned;
    }

    /// Drop this view entirely (draw-off / only-render-selected / leave
    /// the wall). Unregisters the current tex_id and does **not**
    /// re-register the panel-owned 765×503 texture — Metal pads that to
    /// 8 MB, and keeping 49 of them after detach is the leftover GPU
    /// histogram. Consume `self` so the owned texture drops with it.
    pub fn dispose(self, gpu: &mut impl FrameGpu) {
        gpu.unregister_texture(self.tex_id);
    }

    /// Upload packed `0x00RRGGBB` pixels (a `FrameBuf` snapshot) into the
    /// texture. `Gpu` exposes no per-texture sampler choice, so
    /// the Image samples with the renderer's default rather than a pixelated
    /// one. Reuses an RGBA scratch buffer so Poll-rate frames don't allocate.
    pub fn upload(&mut self, gpu: &mut impl FrameGpu, pixels: &[u32]) {
        let was_placeholder = self.cpu_owner.is_none();
        if was_placeholder {
            let texture = gpu.device().create_texture(&wgpu::TextureDescriptor {
                label: Some("274 game image"),
                size: wgpu::Extent3d {
                    width: APPLET_W,
                    height: APPLET_H,
                    depth_or_array_layers: 1,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: wgpu::TextureFormat::Rgba8Unorm,
                usage: wgpu::TextureUsages::TEXTURE_BINDING
                    | wgpu::TextureUsages::COPY_DST
                    | wgpu::TextureUsages::COPY_SRC,
                view_formats: &[],
            });
            let view = texture.create_view(&wgpu::TextureViewDescriptor::default());
            self.cpu_owner = Some(CpuOwner { texture, view });
        }
        if self.bound != Bound::Owned || was_placeholder {
            gpu.unregister_texture(self.tex_id);
            let (texture, view) = self.owned_texture_view();
            self.tex_id = gpu.register_texture(texture, view);
            self.bound = Bound::Owned;
        }
        let n = (APPLET_W * APPLET_H) as usize;
        let rgba = self.rgba.get_or_insert_with(|| vec![0u8; n * 4]);
        expand_rgba(&pixels[..n.min(pixels.len())], rgba);
        let texture = &self
            .cpu_owner
            .as_ref()
            .expect("CPU owner initialized")
            .texture;
        gpu.queue().write_texture(
            wgpu::TexelCopyTextureInfo {
                texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            rgba,
            wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(APPLET_W * 4),
                rows_per_image: Some(APPLET_H),
            },
            wgpu::Extent3d {
                width: APPLET_W,
                height: APPLET_H,
                depth_or_array_layers: 1,
            },
        );
    }

    fn owned_texture_view(&self) -> (&wgpu::Texture, &wgpu::TextureView) {
        self.cpu_owner
            .as_ref()
            .map(|owner| (&owner.texture, &owner.view))
            .unwrap_or((&self.placeholder, &self.placeholder_view))
    }

    #[cfg(test)]
    fn cpu_texture(&self) -> Option<&wgpu::Texture> {
        self.cpu_owner.as_ref().map(|owner| &owner.texture)
    }
}

/// Pack a `PixMap` frame (the CPU backend) into `0x00RRGGBB` pixels,
/// shape-gated like the old `FrameBuf::snapshot`.
fn pixmap_pixels(pix: &PixMap) -> Vec<u32> {
    let n = (APPLET_W * APPLET_H) as usize;
    let mut out = Vec::with_capacity(n);
    if pix.width == APPLET_W as i32 && pix.height == APPLET_H as i32 && pix.pixels.len() >= n {
        for src in pix.pixels.iter().take(n) {
            out.push(*src as u32);
        }
    }
    out
}

/// Pack a taken [`FrameOutput`] into `0x00RRGGBB` pixels. The `PixMap` arm
/// (the CPU backend) packs the applet directly; the `Texture` arm reads the
/// wgpu frame back — the pre-seam fallback. The panel's consume path
/// ([`GameView::present`]) binds `Texture` frames directly instead, so this
/// is the CPU-pixel path for consumers that still need it.
pub fn frame_pixels(frame: FrameOutput) -> Vec<u32> {
    match frame {
        FrameOutput::PixMap(pix) => pixmap_pixels(&pix),
        FrameOutput::Texture(handle) => {
            let n = (handle.width as usize) * (handle.height as usize);
            handle
                .read_back()
                .into_iter()
                .take(n)
                .map(|p| p as u32)
                .collect()
        }
    }
}

/// Expand packed `0x00RRGGBB` pixels into RGBA8 bytes with alpha 255.
fn expand_rgba(src: &[u32], dst: &mut [u8]) {
    for (i, p) in src.iter().enumerate() {
        dst[i * 4] = ((*p >> 16) & 0xff) as u8;
        dst[i * 4 + 1] = ((*p >> 8) & 0xff) as u8;
        dst[i * 4 + 2] = (*p & 0xff) as u8;
        dst[i * 4 + 3] = 255;
    }
}

#[cfg(test)]
mod tests {
    use super::{expand_rgba, frame_pixels, FrameGpu, GameView, APPLET_H, APPLET_W};
    use client::graphics::PixMap;
    use client::render::backend::{FrameOutput, TextureHandle};
    use dear_imgui_rs::TextureId;

    #[test]
    fn expand_rgba_splits_0x00rrggbb() {
        let mut dst = [0u8; 4];
        expand_rgba(&[0x00aa_bbcc], &mut dst);
        assert_eq!(dst, [0xaa, 0xbb, 0xcc, 255]);
    }

    #[test]
    fn expand_rgba_writes_alpha_for_every_pixel() {
        let mut dst = [0u8; 8];
        expand_rgba(&[0x00aa_bbcc, 0x0011_2233], &mut dst);
        assert_eq!(dst, [0xaa, 0xbb, 0xcc, 255, 0x11, 0x22, 0x33, 255]);
    }

    #[test]
    fn frame_pixels_packs_a_full_applet_pixmap() {
        let mut pix = vec![0i32; (APPLET_W * APPLET_H) as usize];
        pix[0] = 0x00aa_bbcc;
        pix[1] = 0x0011_2233;
        let out = frame_pixels(FrameOutput::PixMap(PixMap {
            width: APPLET_W as i32,
            height: APPLET_H as i32,
            pixels: pix,
        }));
        assert_eq!(out.len(), (APPLET_W * APPLET_H) as usize);
        assert_eq!(out[0], 0x00aa_bbcc);
        assert_eq!(out[1], 0x0011_2233);
    }

    #[test]
    fn frame_pixels_of_wrong_shape_pixmap_is_empty() {
        let out = frame_pixels(FrameOutput::PixMap(PixMap {
            width: 2,
            height: 2,
            pixels: vec![1, 2, 3],
        }));
        assert!(out.is_empty());
    }

    /// A real headless wgpu device/queue on this machine's adapter
    /// (`None` when no adapter exists — the GPU tests then skip).
    fn headless_gpu() -> Option<(wgpu::Device, wgpu::Queue)> {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor::new_without_display_handle());
        let adapter = pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions {
            power_preference: wgpu::PowerPreference::HighPerformance,
            compatible_surface: None,
            force_fallback_adapter: false,
        }))
        .ok()?;
        let (device, queue) = pollster::block_on(adapter.request_device(&wgpu::DeviceDescriptor {
            label: Some("274 panel test"),
            required_features: wgpu::Features::empty(),
            required_limits: wgpu::Limits::default(),
            experimental_features: wgpu::ExperimentalFeatures::default(),
            memory_hints: wgpu::MemoryHints::default(),
            trace: wgpu::Trace::default(),
        }))
        .ok()?;
        Some((device, queue))
    }

    /// A real 2×2 RGBA8 texture on the given device, written with four
    /// known pixels, as a client `TextureHandle` would arrive from
    /// `FrameOutput::Texture`.
    fn frame_handle(device: &wgpu::Device, queue: &wgpu::Queue) -> TextureHandle {
        let texture = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("274 panel test frame"),
            size: wgpu::Extent3d {
                width: 2,
                height: 2,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8Unorm,
            usage: wgpu::TextureUsages::TEXTURE_BINDING
                | wgpu::TextureUsages::COPY_DST
                | wgpu::TextureUsages::COPY_SRC,
            view_formats: &[],
        });
        queue.write_texture(
            wgpu::TexelCopyTextureInfo {
                texture: &texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            &[
                255, 0, 0, 255, 0, 255, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255,
            ],
            wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(2 * 4),
                rows_per_image: Some(2),
            },
            wgpu::Extent3d {
                width: 2,
                height: 2,
                depth_or_array_layers: 1,
            },
        );
        let view = texture.create_view(&wgpu::TextureViewDescriptor::default());
        TextureHandle {
            device: device.clone(),
            queue: queue.clone(),
            view,
            width: 2,
            height: 2,
        }
    }

    /// A real 2×2 RGBA8 texture on a headless wgpu device, written with
    /// four known pixels. `None` when no adapter exists (headless CI) —
    /// the read-back test then skips.
    fn test_texture_handle() -> Option<TextureHandle> {
        let (device, queue) = headless_gpu()?;
        Some(frame_handle(&device, &queue))
    }

    #[test]
    fn frame_pixels_reads_a_texture_frame_back() {
        let Some(handle) = test_texture_handle() else {
            return; // no adapter: headless CI has nothing to read back
        };
        let pixels = frame_pixels(FrameOutput::Texture(handle));
        assert_eq!(
            pixels,
            vec![0x00ff_0000, 0x0000_ff00, 0x0000_00ff, 0x00ff_ffff]
        );
    }

    /// A recording [`FrameGpu`] on a real headless device: every
    /// `register_texture`/`unregister_texture` records the id (and the
    /// registered texture), so the direct-bind path is testable without a
    /// full ImGui renderer.
    struct RecordingGpu {
        device: wgpu::Device,
        queue: wgpu::Queue,
        /// `(assigned id, registered texture)` in registration order.
        registered: Vec<(u64, wgpu::Texture)>,
        /// Unregistered ids, in order.
        unregistered: Vec<u64>,
    }

    impl RecordingGpu {
        fn new(device: wgpu::Device, queue: wgpu::Queue) -> Self {
            Self {
                device,
                queue,
                registered: Vec::new(),
                unregistered: Vec::new(),
            }
        }
        fn last_registered(&self) -> Option<&wgpu::Texture> {
            self.registered.last().map(|(_, t)| t)
        }
    }

    impl FrameGpu for RecordingGpu {
        fn device(&self) -> &wgpu::Device {
            &self.device
        }
        fn queue(&self) -> &wgpu::Queue {
            &self.queue
        }
        fn register_texture(
            &mut self,
            texture: &wgpu::Texture,
            _view: &wgpu::TextureView,
        ) -> TextureId {
            let id = self.registered.len() as u64 + 1;
            self.registered.push((id, texture.clone()));
            TextureId::new(id)
        }
        fn unregister_texture(&mut self, tex_id: TextureId) {
            self.unregistered.push(tex_id.id());
        }
    }

    fn read_rgba(
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        texture: &wgpu::Texture,
        width: u32,
        height: u32,
    ) -> Vec<u8> {
        let bytes_per_row = (width * 4).div_ceil(256) * 256;
        let buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("274 panel test readback"),
            size: (bytes_per_row * height) as u64,
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        });
        let mut encoder = device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("274 panel test readback encoder"),
        });
        encoder.copy_texture_to_buffer(
            wgpu::TexelCopyTextureInfo {
                texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            wgpu::TexelCopyBufferInfo {
                buffer: &buffer,
                layout: wgpu::TexelCopyBufferLayout {
                    offset: 0,
                    bytes_per_row: Some(bytes_per_row),
                    rows_per_image: Some(height),
                },
            },
            wgpu::Extent3d {
                width,
                height,
                depth_or_array_layers: 1,
            },
        );
        queue.submit([encoder.finish()]);
        let slice = buffer.slice(..);
        let (tx, rx) = std::sync::mpsc::channel();
        slice.map_async(wgpu::MapMode::Read, move |result| {
            let _ = tx.send(result);
        });
        loop {
            let _ = device.poll(wgpu::PollType::wait_indefinitely());
            if let Ok(result) = rx.recv_timeout(std::time::Duration::from_millis(1)) {
                result.expect("panel test texture readback must map");
                break;
            }
        }
        let data = slice.get_mapped_range();
        let mut pixels = Vec::with_capacity((width * height * 4) as usize);
        for row in 0..height as usize {
            let start = row * bytes_per_row as usize;
            pixels.extend_from_slice(&data[start..start + width as usize * 4]);
        }
        drop(data);
        buffer.unmap();
        pixels
    }

    #[test]
    fn initialized_placeholder_matches_empty_pixels() {
        let Some((device, queue)) = headless_gpu() else {
            return;
        };
        let mut gpu = RecordingGpu::new(device.clone(), queue.clone());
        let view = GameView::init(&mut gpu);

        let texture = gpu
            .last_registered()
            .expect("init registers the placeholder texture");
        assert_eq!(read_rgba(&device, &queue, texture, 1, 1), [0, 0, 0, 0]);
        assert!(view.cpu_texture().is_none());
    }

    #[test]
    fn gpu_first_unbind_restores_empty_placeholder_pixels() {
        let Some((device, queue)) = headless_gpu() else {
            return;
        };
        let mut gpu = RecordingGpu::new(device.clone(), queue.clone());
        let mut view = GameView::init(&mut gpu);
        view.present(
            &mut gpu,
            FrameOutput::Texture(frame_handle(&device, &queue)),
        );
        view.unbind_client(&mut gpu);

        let texture = gpu
            .last_registered()
            .expect("unbind re-registers the owned placeholder");
        assert_eq!(read_rgba(&device, &queue, texture, 1, 1), [0, 0, 0, 0]);
        assert!(view.cpu_texture().is_none());
    }

    #[test]
    fn cpu_pixels_survive_gpu_bind_and_unbind() {
        let Some((device, queue)) = headless_gpu() else {
            return;
        };
        let mut gpu = RecordingGpu::new(device.clone(), queue.clone());
        let mut view = GameView::init(&mut gpu);
        let mut pixels = vec![0i32; (APPLET_W * APPLET_H) as usize];
        pixels[0] = 0x0012_3456;
        pixels[1] = 0x00ab_cdef_u32 as i32;
        view.present(
            &mut gpu,
            FrameOutput::PixMap(PixMap {
                width: APPLET_W as i32,
                height: APPLET_H as i32,
                pixels,
            }),
        );
        let cpu_texture = view.cpu_texture().expect("CPU present creates an owner");
        assert_eq!(
            &read_rgba(&device, &queue, cpu_texture, APPLET_W, APPLET_H)[..8],
            [0x12, 0x34, 0x56, 255, 0xab, 0xcd, 0xef, 255]
        );

        view.present(
            &mut gpu,
            FrameOutput::Texture(frame_handle(&device, &queue)),
        );
        view.unbind_client(&mut gpu);
        let retained = gpu
            .last_registered()
            .expect("unbind re-registers the retained CPU owner");
        assert_eq!(
            &read_rgba(&device, &queue, retained, APPLET_W, APPLET_H)[..8],
            [0x12, 0x34, 0x56, 255, 0xab, 0xcd, 0xef, 255]
        );
    }

    /// The shared-device seam: a `Texture` frame's consume path registers
    /// the client's frame-texture view directly with the renderer — the
    /// `read_back` fallback is never on this path. A real 2×2 client
    /// texture (same device the panel's own texture lives on, as in
    /// production) plus a recording registrar prove the routing: init
    /// registers the panel texture; the first `Texture` frame registers
    /// the client's view and adopts its id; a repeat frame of the same
    /// client texture is a no-op; a new client texture re-registers and
    /// unregisters the old one; a `PixMap` frame switches back to the
    /// panel-owned texture.
    #[test]
    fn texture_frame_binds_the_client_view_directly() {
        let Some((device, queue)) = headless_gpu() else {
            return; // no adapter: headless CI has nothing to bind
        };
        let mut gpu = RecordingGpu::new(device.clone(), queue.clone());
        let mut view = GameView::init(&mut gpu);
        assert!(
            view.cpu_texture().is_none(),
            "GPU-first init has no CPU owner"
        );
        assert_eq!(
            gpu.registered.len(),
            1,
            "init registers the panel-owned texture"
        );
        assert_eq!(view.tex_id.id(), gpu.registered[0].0);

        // The `Texture` consume path: bind the client's view directly (no
        // `read_back`), and the Image draws the client's frame texture.
        // The transition unregisters the panel texture init registered.
        let handle = frame_handle(&device, &queue);
        let client_texture = handle.view.texture().clone();
        view.present(&mut gpu, FrameOutput::Texture(handle));
        assert!(
            view.cpu_texture().is_none(),
            "GPU-first bind stays CPU-free"
        );
        assert_eq!(
            gpu.registered.len(),
            2,
            "the Texture frame must register the client's view"
        );
        assert_eq!(
            view.tex_id.id(),
            2,
            "the Image must now draw the client's frame texture"
        );
        assert_eq!(
            gpu.last_registered(),
            Some(&client_texture),
            "the registered texture must be the client's frame texture"
        );
        assert_eq!(
            gpu.unregistered,
            vec![1],
            "switching to the client frame must unregister the panel texture"
        );

        // The client reuses one `frame_texture` per backend: a re-taken
        // frame of the same texture must not re-register.
        let re_take = TextureHandle {
            device: device.clone(),
            queue: queue.clone(),
            view: client_texture.create_view(&Default::default()),
            width: 2,
            height: 2,
        };
        view.present(&mut gpu, FrameOutput::Texture(re_take));
        assert_eq!(
            gpu.registered.len(),
            2,
            "re-binding the same client frame texture is a no-op"
        );

        // A new client texture (a slot restart) re-registers and
        // unregisters the previous client frame.
        let fresh = frame_handle(&device, &queue);
        view.present(&mut gpu, FrameOutput::Texture(fresh));
        assert_eq!(
            gpu.registered.len(),
            3,
            "a new client frame texture re-registers"
        );
        assert_eq!(view.tex_id.id(), 3);
        assert_eq!(
            gpu.unregistered,
            vec![1, 2],
            "the old client frame must be unregistered"
        );

        // Back to the CPU path: a `PixMap` frame re-registers the
        // panel-owned texture (unregistering the client frame) and uploads
        // into it.
        let mut pix = vec![0i32; (APPLET_W * APPLET_H) as usize];
        pix[0] = 0x00aa_bbcc;
        view.present(
            &mut gpu,
            FrameOutput::PixMap(PixMap {
                width: APPLET_W as i32,
                height: APPLET_H as i32,
                pixels: pix,
            }),
        );
        assert!(
            view.cpu_texture().is_some(),
            "CPU fallback allocates on demand"
        );
        assert_eq!(
            gpu.registered.len(),
            4,
            "the PixMap frame must re-register the panel texture"
        );
        assert_eq!(
            view.tex_id.id(),
            4,
            "the Image must draw the panel's texture again"
        );
        assert_eq!(
            gpu.last_registered(),
            Some(view.cpu_texture().expect("CPU frame allocates its owner")),
            "the registered texture must be the panel-owned texture"
        );
        assert_eq!(
            gpu.unregistered,
            vec![1, 2, 3],
            "every replaced texture must be unregistered (bounded renderer cache)"
        );

        let handle = frame_handle(&device, &queue);
        view.present(&mut gpu, FrameOutput::Texture(handle));
        view.unbind_client(&mut gpu);
        assert_eq!(
            gpu.unregistered,
            vec![1, 2, 3, 4, 5],
            "unbind_client must drop the client frame before the GPU head is destroyed"
        );
        view.unbind_client(&mut gpu);
        assert_eq!(
            gpu.unregistered,
            vec![1, 2, 3, 4, 5],
            "unbind_client on an owned bind is a no-op"
        );
    }

    /// Draw-off / only-render-selected must *drop* the panel GameView, not
    /// `unbind_client` back to the owned 765×503 texture. Metal pads that
    /// texture to 2048×1024 (8 MB); 49 leftover views after detach are
    /// ~400 MB still resident. Dispose unregisters the current tex_id and
    /// does not re-register the panel texture.
    #[test]
    fn dispose_unregisters_without_re_registering_the_panel_texture() {
        let Some((device, queue)) = headless_gpu() else {
            return; // no adapter: headless CI has nothing to bind
        };
        let mut gpu = RecordingGpu::new(device.clone(), queue.clone());
        let mut view = GameView::init(&mut gpu);
        let handle = frame_handle(&device, &queue);
        view.present(&mut gpu, FrameOutput::Texture(handle));
        assert_eq!(gpu.registered.len(), 2);
        let client_id = view.tex_id.id();
        view.dispose(&mut gpu);
        assert_eq!(
            gpu.unregistered.last().copied(),
            Some(client_id),
            "dispose must unregister the bound client frame"
        );
        assert_eq!(
            gpu.registered.len(),
            2,
            "dispose must not re-register the panel-owned 765×503 texture"
        );
    }

    /// Two consecutive `Texture` presents of the same client texture (the
    /// stable-present contract) must re-register once then no-op: bind_rereg
    /// stays 1 and bind_noop climbs.
    #[test]
    fn stable_texture_present_bind_is_noop_after_first() {
        let Some((device, queue)) = headless_gpu() else {
            return;
        };
        let mut gpu = RecordingGpu::new(device.clone(), queue.clone());
        let mut view = GameView::init(&mut gpu);
        let handle = frame_handle(&device, &queue);
        let tex = handle.view.texture().clone();
        view.present(&mut gpu, FrameOutput::Texture(handle));
        assert_eq!(view.present_stats.tex, 1);
        assert_eq!(view.present_stats.bind_rereg, 1);
        assert_eq!(view.present_stats.bind_noop, 0);

        let again = TextureHandle {
            device: device.clone(),
            queue: queue.clone(),
            view: tex.create_view(&Default::default()),
            width: 2,
            height: 2,
        };
        view.present(&mut gpu, FrameOutput::Texture(again));
        assert_eq!(view.present_stats.tex, 2);
        assert_eq!(
            view.present_stats.bind_rereg, 1,
            "same texture identity must not re-register"
        );
        assert_eq!(
            view.present_stats.bind_noop, 1,
            "second present of the stable texture is a bind no-op"
        );
        assert_eq!(gpu.registered.len(), 2, "no extra ImGui registration");
    }
}
