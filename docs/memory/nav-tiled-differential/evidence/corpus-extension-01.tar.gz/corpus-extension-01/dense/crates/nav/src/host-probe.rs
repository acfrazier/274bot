pub struct PendingBankFetch {
    pub steps: VecDeque<BankStep>,
    pub dest: WorldTile,
    pub opts: FindOptions,
    pub final_route: Route,
}

enum RouteOutcome {
    Routed(Route),
    BankSession {
        pending: PendingBankFetch,
        route: Route,
    },
    NoPath,
}

fn route_or_bank_fetch(
    world: &NavWorld,
    from: WorldTile,
    to: WorldTile,
    opts: FindOptions,
    state: &WorldState,
    bank: &[(i32, i32)],
) -> RouteOutcome {
    match find_with(&world.collision, &world.graph, from, to, opts, state) {
        Ok(route) => RouteOutcome::Routed(route),
        Err(_) if opts.allow_bank_fetch => {
            let Some(missing) =
                find_missing_item_reqs(&world.collision, &world.graph, from, to, opts, state)
            else {
                return RouteOutcome::NoPath;
            };
            let Some(fetch) = plan_bank_fetch(&missing, state, bank, world.banks(), from) else {
                return RouteOutcome::NoPath;
            };
            // Re-find against the post-session state (ADR 0005: find itself
            // stayed fail-closed; the session is what unblocks).
            let Ok(route) = find_with(
                &world.collision,
                &world.graph,
                from,
                to,
                FindOptions {
                    allow_bank_fetch: false,
                    ..opts
                },
                &fetch.state,
            ) else {
                return RouteOutcome::NoPath;
            };
            RouteOutcome::BankSession {
                pending: PendingBankFetch {
                    steps: fetch.steps.into(),
                    dest: to,
                    opts: FindOptions {
                        allow_bank_fetch: false,
                        ..opts
                    },
                    final_route: route.clone(),
                },
                route,
            }
        }
        Err(_) => RouteOutcome::NoPath,
    }
}

fn approach_tiles(world: &NavWorld, from: WorldTile, to: WorldTile, radius: i32) -> Vec<WorldTile> {
    let r = radius.clamp(0, 104);
    let mut tiles = Vec::new();
    for dx in -r..=r { for dz in -r..=r {
        let t=WorldTile { x:to.x+dx,z:to.z+dz,level:to.level };
        if world.collision.standable(t) {tiles.push(t);}
    }}
    tiles.sort_by_key(|t| ((t.x-from.x).abs().max((t.z-from.z).abs()),(t.x-to.x).abs().max((t.z-to.z).abs()),t.x,t.z));
    tiles
}

struct ScriptRouteRequest {
    generation: u64,
    world: Arc<NavWorld>,
    from: WorldTile,
    to: WorldTile,
    radius: i32,
    opts: FindOptions,
    state: Option<WorldState>,
    bank: Vec<(i32,i32)>,
}

impl ScriptRouteRequest {
    fn calculate(&self) -> RouteOutcome {
        let empty = WorldState::empty();
        let state = self.state.as_ref().unwrap_or(&empty);
        if self.radius <= 0 { return route_or_bank_fetch(&self.world,self.from,self.to,self.opts.clone(),state,&self.bank); }
        for target in approach_tiles(&self.world,self.from,self.to,self.radius) {
            let outcome = route_or_bank_fetch(&self.world,self.from,target,self.opts.clone(),state,&self.bank);
            if !matches!(outcome,RouteOutcome::NoPath) { return outcome; }
        }
        RouteOutcome::NoPath
    }
}
