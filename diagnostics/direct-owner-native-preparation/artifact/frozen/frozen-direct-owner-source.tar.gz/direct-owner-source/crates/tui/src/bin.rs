//! `tui-play`: the headless operator panel binary. Same flag spirit as
//! `host-play` / `panel-play` (`--vault`, `--vault-pass` / `BOT_VAULT_PASS`,
//! `--host`, `--port`, `--cache`, `--user`, `--live script_<name>`).
//!
//! The binary owns the `host_play::Play` session: a per-frame hook
//! publishes each slot's snapshot and steps the focused slot's walk arm,
//! and the UI loop polls statuses, refreshes [`TuiApp`], routes
//! keys/clicks, and dispatches the returned [`AppAction`] onto the play —
//! map Walk-confirm routes through `host_play::arm_walk_on`, chat
//! Continue/Answer and WASD walks go through `host_play::WireCmd`, and
//! the settings popup writes `ProfileSettings` on the focused profile.
//!
//! **Raster Off:** every profile is spawned with `RasterMode::Off` and the
//! TUI never attaches a `Renderer` (no `panel` / imgui / wgpu anywhere).
//! `--live script_<name>` mints per-run usernames into an ephemeral vault
//! (like the panel) and PASS/FAIL comes from the scenario runner, not a
//! screenshot.

use std::collections::HashMap;
use std::env;
use std::path::{Path, PathBuf};
use std::process::ExitCode;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use crossterm::event::{self, Event, KeyEventKind, MouseEventKind};
use crossterm::terminal::{
    disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen,
};
use host_play::{
    arm_walk_on, default_vault_path, live_vault_passphrase, mint_live_entries, mint_live_names,
    open_vault, player_here_tile, profile_password, run_with_io, step_walk_arm_bank_fetch,
    walk_arm_bank_fetch_freezes_follow, Play, PlayOptions, SlotArm, WalkArm, WireCmd,
};
use nav::tile::Tile;
use nav::traveller::{TravelOptions, TravelOutcome};
use nav::WorldState;
use ratatui::backend::CrosstermBackend;
use ratatui::Terminal;
use vault::{Profile, Vault};

use crate::app::{AppAction, ChatData, TuiApp};
use crate::chat::ChatAction;
use crate::script_shape::{
    categories_present, resolve_category_order, rs2b0t_root_has_index, BrowseCard,
};

/// What `tui-play` should do this run.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RunMode {
    /// Interactive operator panel.
    Interactive,
    /// `--live script_<name>`: PASS/FAIL from the scenario runner.
    Live(String),
}

/// Parsed `tui-play` flags.
#[derive(Debug, Clone)]
pub struct Args {
    pub vault: PathBuf,
    pub pass: Option<String>,
    pub host: String,
    pub port: u16,
    pub cache: String,
    pub users: Vec<String>,
    pub live: Option<String>,
    /// `--prod`: apply Prod host/port in `main` (OnceLock, not in parse).
    pub prod: bool,
}

fn usage() -> ! {
    eprintln!(
        "usage: tui-play [--vault PATH] [--vault-pass PASS] \
         [--host HOST] [--port PORT] [--cache DIR] [--prod] \
         [--live script_<name>] [--user USER]... (default user: first vault profile)"
    );
    std::process::exit(2);
}

fn need_value(
    it: &mut impl Iterator<Item = impl AsRef<str>>,
    flag: &str,
) -> Result<String, String> {
    it.next()
        .map(|s| s.as_ref().to_string())
        .ok_or_else(|| format!("tui-play: {flag} needs a value"))
}

fn default_vault() -> PathBuf {
    default_vault_path()
}

fn default_cache_dir() -> String {
    client::cache_dir().display().to_string()
}

/// `--live NAME` wins over `BOT_LIVE`; empty env is ignored.
/// `--help`/`-h` print the usage line (exit 2, the CLI family's
/// convention). `--prod` is recorded here; `main` applies the OnceLock.
pub fn parse_args() -> Args {
    match parse_args_from(env::args().skip(1)) {
        Ok(args) => args,
        Err(msg) => {
            if msg != "usage" {
                eprintln!("{msg}");
            }
            usage();
        }
    }
}

/// Testable CLI parse. Does not flip [`client::set_bot_target`].
pub fn parse_args_from(args: impl IntoIterator<Item = impl AsRef<str>>) -> Result<Args, String> {
    let mut parsed = Args {
        vault: default_vault(),
        pass: env::var("BOT_VAULT_PASS").ok(),
        host: host_play::default_world_host(),
        port: client::game_port_for(client::bot_target()),
        cache: default_cache_dir(),
        users: Vec::new(),
        live: env::var("BOT_LIVE").ok().filter(|s| !s.is_empty()),
        prod: false,
    };
    let mut it = args.into_iter();
    while let Some(arg) = it.next() {
        match arg.as_ref() {
            "--vault" => parsed.vault = PathBuf::from(need_value(&mut it, "--vault")?),
            "--vault-pass" => parsed.pass = Some(need_value(&mut it, "--vault-pass")?),
            "--host" => parsed.host = need_value(&mut it, "--host")?,
            "--port" => {
                parsed.port = need_value(&mut it, "--port")?
                    .parse()
                    .map_err(|_| "tui-play: --port needs a number".to_string())?
            }
            "--cache" => parsed.cache = need_value(&mut it, "--cache")?,
            "--user" => parsed.users.push(need_value(&mut it, "--user")?),
            "--live" => parsed.live = Some(need_value(&mut it, "--live")?),
            "--prod" => parsed.prod = true,
            "--help" | "-h" => return Err("usage".into()),
            other => return Err(format!("tui-play: unknown {other}")),
        }
    }
    Ok(parsed)
}

/// Refuse a non-loopback `--host` while local RSA is active (same bind as host-play).
pub fn validate_startup_host(host: &str) -> Result<(), &'static str> {
    host_play::validate_play_host(host, client::bot_target())
}

/// The `--live` scenario, `Err` when the name is not a `script_<name>`.
/// Unknown names fail the run (same usage contract as panel-play).
pub fn live_scenario(name: &str) -> Result<scenario::Scenario, String> {
    let script = name
        .strip_prefix("script_")
        .ok_or_else(|| format!("tui-play: --live {name}: only script_<name> is supported"))?;
    scenario::get(script).ok_or_else(|| format!("tui-play: --live {name}: unknown scenario"))
}

/// Throwaway encrypted vault for `--live` (minted names, target-aware pass).
fn temp_live_vault(entries: &[(String, String)], vault_pass: &str) -> PathBuf {
    static SERIAL: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
    let serial = SERIAL.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    let dir = env::temp_dir().join(format!(
        "274bot-tui-live-{}-{}-{serial}",
        std::process::id(),
        entries.len()
    ));
    std::fs::create_dir_all(&dir).unwrap();
    let path = dir.join("vault");
    if path.exists() {
        std::fs::remove_file(&path).unwrap();
    }
    let mut vault = Vault::create(&path, vault_pass).unwrap();
    for (i, (user, pass)) in entries.iter().enumerate() {
        vault
            .upsert(Profile {
                username: user.clone(),
                password: pass.clone(),
                uid: 274_000_001 + i as i32,
                settings: vault::ProfileSettings {
                    auto_login: true,
                    ..vault::ProfileSettings::default()
                },
            })
            .unwrap();
    }
    path
}

/// The walk-arm step latch key: `(player gen, here)` per username, so a
/// hop is sent once per server tick, not every 20 ms frame.
type NavStepLatch = HashMap<String, (u64, (i32, i32, i32))>;

/// Panel-parity walk-arm tick: BankBudget session first, then route follow.
fn step_walk_arm_follow<D: api::interact::Driver>(
    driver: &mut D,
    snapshot: &api::snapshot::GameSnapshot,
    arm: &mut WalkArm,
    world: Option<&nav::world::NavWorld>,
    here: (i32, i32, i32),
) -> bool {
    if arm.bank_fetch.is_some() {
        step_walk_arm_bank_fetch(driver, snapshot, arm, world, Some(here));
        if walk_arm_bank_fetch_freezes_follow(arm) {
            return false;
        }
    }
    let Some(route) = arm.route.clone() else {
        return false;
    };
    let walking_stand = arm.bank_fetch.as_ref().is_some_and(|p| {
        matches!(
            p.steps.front(),
            Some(nav::bank_fetch::BankStep::Walk { x, z, level })
                if route.dest.x == *x
                    && route.dest.z == *z
                    && route.dest.level == *level
        )
    });
    let mut options = TravelOptions {
        close_enough: 0,
        teleports: world.map(|w| w.graph.teleports.as_slice()),
        edges: world.map(|w| w.graph.edges.as_slice()),
        ..TravelOptions::default()
    };
    let outcome = arm.traveller.follow(driver, snapshot, route, &mut options);
    if walking_stand
        && matches!(
            &outcome,
            Some(o) if !matches!(o, TravelOutcome::Arrived { .. })
        )
    {
        arm.bank_fetch = None;
        arm.route = None;
        return false;
    }
    if outcome.is_some() {
        arm.route = None;
        true
    } else {
        false
    }
}

/// Catalog card live_prepare stashes so the StartScript pump can
/// `script_start_load` once after seed waits.
struct PendingCatalogStart {
    slot: String,
    js: String,
    shape: script::LoadShape,
    bag: Option<serde_json::Map<String, serde_json::Value>>,
    siblings: Vec<(String, String)>,
}

/// When the runner is on [`scenario::StepKind::StartScript`], start the
/// stashed catalog isolate once. Returns false when Start was attempted
/// and failed, so the pump must not consume the one-tick wait.
fn fire_pending_catalog_start(
    pending: &Mutex<Option<PendingCatalogStart>>,
    handle: &Mutex<Option<host_play::ScriptStartHandle>>,
    runner: &scenario::ScenarioRunner,
) -> bool {
    if !runner.on_start_script() {
        return true;
    }
    let mut pending = pending.lock().unwrap();
    let Some(card) = pending.as_ref() else {
        return true;
    };
    let handle = handle.lock().unwrap();
    let Some(h) = handle.as_ref() else {
        return false;
    };
    if h.start_load(
        &card.slot,
        card.js.clone(),
        card.shape,
        card.bag.clone(),
        card.siblings.clone(),
    )
    .is_ok()
    {
        pending.take();
        true
    } else {
        false
    }
}

/// The TUI session: the running play, the vault, the per-slot snapshot
/// publication, and the per-username walk arms (the same `WalkArm` map
/// `host_play::arm_walk_on` latches and the panel drives).
pub struct TuiSession {
    #[cfg(feature = "memory-profile")]
    memory: Option<host_play::memory::Run>,
    play: Option<Play>,
    vault: Option<Vault>,
    pub error: Option<String>,
    /// All profile names (for the strip's slot list), in vault order.
    names: Vec<String>,
    options: PlayOptions,
    /// The username the settings popup currently edits; reload
    /// `ProfileSettings` into the app when it changes.
    last_focused: Option<String>,
    /// Per-username snapshots, rebuilt by the per-frame hook.
    snapshots: Arc<Mutex<HashMap<String, api::snapshot::GameSnapshot>>>,
    /// Per-username walk arms; the focused arm's route paints the map and
    /// the per-frame hook steps it via `Traveller::follow`.
    travellers: Arc<Mutex<HashMap<String, Arc<Mutex<WalkArm>>>>>,
    /// Last `(player gen, here)` ticked per username, so a walk hop is
    /// sent once per server tick, not every 20 ms frame.
    tick_latch: Arc<Mutex<NavStepLatch>>,
    /// Slot threads set this when a traveller returns Arrived/Budget so
    /// the UI can clear the picked walk dest.
    walk_clear: Arc<AtomicBool>,
    /// The shared nav world (`Play::world`), read by the per-frame walk
    /// step and the app thread's route arms.
    nav_world: Arc<Mutex<Option<Arc<nav::world::NavWorld>>>>,
    /// The shared `--live script_*` runner (slot threads tick it from the
    /// per-frame hook; the UI loop reads its status/evidence).
    scenario: Arc<Mutex<Option<scenario::ScenarioRunner>>>,
    /// Catalog card `live_prepare_script` stashes; the live pump Starts
    /// it once on [`scenario::StepKind::StartScript`].
    pending_script: Arc<Mutex<Option<PendingCatalogStart>>>,
    /// Isolate-start handle the per-frame hook uses (filled after Play).
    script_start_handle: Arc<Mutex<Option<host_play::ScriptStartHandle>>>,
    /// The `--live` run's scenario name, for the PASS/FAIL label.
    live_name: Option<String>,
    /// `BUDGET_S` soak: keep pumping after proof PASS until this instant.
    live_soak_until: Option<Instant>,
    live_announced_pass: bool,
    /// The Browse-selected card (catalog Start after seed, or operator Start).
    script_sel: Option<script::ScriptSel>,
    /// The out-of-tree JS library: the Browse picker's cards and the
    /// Load/Start source for the focused slot (same store the panel
    /// persists to).
    js: script::JsLibrary,
    /// The `$RS2B0T` registry cards were filled into `js` once (first
    /// Browse/Load, like the panel).
    rs2b0t_filled: bool,
    /// First-run rs2b0t clone-root folder browser.
    rs2b0t_catalog_open: bool,
    rs2b0t_catalog_dir: PathBuf,
    /// Browse category order keys (in-memory; panel persists to panel-ui.json).
    script_category_order: Vec<String>,
    /// Operator script-parameter overrides (`~/.274bot/script-settings.json`).
    script_settings: script::ScriptSettingsStore,
    /// Process-wide loadout presets (`~/.274bot/loadouts.json`).
    loadouts: script::LoadoutsStore,
    /// Scenario/live inject merged last on Start.
    script_settings_inject: Option<serde_json::Map<String, serde_json::Value>>,
    /// Last directory visited in the out-of-tree Load file browser.
    script_load_last_dir: Option<PathBuf>,
}

#[cfg(test)]
impl TuiSession {
    /// Inject a `Play` for unit tests (no vault / slot threads).
    fn inject_play(&mut self, play: Play) {
        self.play = Some(play);
    }
}

impl TuiSession {
    /// Empty session over the default engine options.
    fn new(options: PlayOptions) -> Self {
        #[cfg(test)]
        script::IsolatedEnv::ensure_thread();
        let mut js = script::JsLibrary::new(script::default_js_store());
        let _ = js.restore(); // missing/broken store is not fatal here
        Self {
            #[cfg(feature = "memory-profile")]
            memory: None,
            play: None,
            vault: None,
            error: None,
            names: Vec::new(),
            options,
            last_focused: None,
            snapshots: Arc::new(Mutex::new(HashMap::new())),
            travellers: Arc::new(Mutex::new(HashMap::new())),
            tick_latch: Arc::new(Mutex::new(HashMap::new())),
            walk_clear: Arc::new(AtomicBool::new(false)),
            nav_world: Arc::new(Mutex::new(None)),
            scenario: Arc::new(Mutex::new(None)),
            pending_script: Arc::new(Mutex::new(None)),
            script_start_handle: Arc::new(Mutex::new(None)),
            live_name: None,
            live_soak_until: None,
            live_announced_pass: false,
            script_sel: None,
            js,
            rs2b0t_filled: false,
            rs2b0t_catalog_open: false,
            rs2b0t_catalog_dir: Self::default_catalog_browse_dir(),
            script_category_order: Vec::new(),
            script_settings: script::ScriptSettingsStore::with_default_path(),
            loadouts: script::LoadoutsStore::with_default_path(),
            script_settings_inject: None,
            script_load_last_dir: None,
        }
    }

    fn merged_settings_bag(
        &self,
        source: script::ScriptSource,
        name: &str,
        schema: &[script::SettingDef],
    ) -> serde_json::Map<String, serde_json::Value> {
        self.script_settings
            .merged_bag(source, name, schema, self.script_settings_inject.as_ref())
    }

    /// Schema defaults + overrides + inject. Empty schema still keeps
    /// inject keys (Thiever `target: Guard`). `None` only when the merged
    /// bag is empty.
    fn pending_settings_bag(
        &self,
        source: script::ScriptSource,
        name: &str,
        schema: &[script::SettingDef],
    ) -> Option<serde_json::Map<String, serde_json::Value>> {
        let merged = self.merged_settings_bag(source, name, schema);
        if merged.is_empty() {
            None
        } else {
            Some(merged)
        }
    }

    fn default_catalog_browse_dir() -> PathBuf {
        let home = script::bot_home();
        if home.as_os_str() == "." {
            PathBuf::from("/")
        } else {
            home
        }
    }

    /// Unlock (or first-run create) the vault at `path` and start the play.
    fn unlock_at(&mut self, path: &Path, pass: &str) -> Result<(), String> {
        let vault = open_vault(path, pass).map_err(|e| e.to_string())?;
        self.start_play(vault);
        Ok(())
    }

    /// Empty `Play` (shared cache + FIFO + per-frame hook), then spawn the
    /// focused profile only; `m` spawns the rest.
    fn start_play(&mut self, vault: Vault) {
        let snapshots = Arc::clone(&self.snapshots);
        let travellers = Arc::clone(&self.travellers);
        let tick_latch = Arc::clone(&self.tick_latch);
        let walk_clear = Arc::clone(&self.walk_clear);
        let nav_world = Arc::clone(&self.nav_world);
        let scenario = Arc::clone(&self.scenario);
        let pending_script = Arc::clone(&self.pending_script);
        let script_start_handle = Arc::clone(&self.script_start_handle);
        let options = self.options.clone();
        let play = run_with_io(
            &options,
            Vec::new(),
            |_| (None, None),
            move |c, name, hold| {
                // Publish the slot's snapshot (chat ring / modal, inv /
                // stats / locs) for the UI thread; the rebuild is
                // incremental, so a quiet frame publishes nothing new.
                let mut all = snapshots.lock().unwrap();
                let snap = all.entry(name.to_string()).or_default();
                snap.rebuild(c);

                // The shared `--live script_*` runner: tick the driven
                // slot and its companions before the local-player gate
                // (seeding must observe frames with no player decode).
                // Hold freezes scenario follow like `step_nav_bot`.
                if let Some(runner) = scenario.lock().unwrap().as_mut() {
                    if runner.drives(name) {
                        if fire_pending_catalog_start(&pending_script, &script_start_handle, runner)
                        {
                            runner.tick_with_hold(c, hold);
                        }
                    } else if let Some(index) = runner.companion_for(name) {
                        runner.companion_tick(index, c);
                    }
                }

                let Some(here) = player_here_tile(c) else {
                    return;
                };
                // Guardian hold freezes WalkArm follow; the armed route
                // stays latched and resumes when hold lifts.
                if !WalkArm::may_follow(hold) {
                    return;
                }
                // Step the armed walk route one leg per player-info tick
                // (the panel's `tick_latch` pattern — a hop is sent once
                // per server tick, not re-sent every 20 ms frame).
                let Some(arm) = travellers.lock().unwrap().get(name).cloned() else {
                    return;
                };
                {
                    let mut latch = tick_latch.lock().unwrap();
                    if latch.get(name) == Some(&(c.gens.player, here)) {
                        return;
                    }
                    latch.insert(name.to_string(), (c.gens.player, here));
                }
                let finished = {
                    let mut arm = arm.lock().unwrap();
                    let world = nav_world.lock().unwrap().clone();
                    step_walk_arm_follow(c, snap, &mut arm, world.as_deref(), here)
                };
                if finished {
                    walk_clear.store(true, Ordering::Relaxed);
                }
            },
        );
        self.nav_world.lock().unwrap().clone_from(&play.world());
        *self.script_start_handle.lock().unwrap() = Some(play.script_start_handle());
        self.play = Some(play);
        self.vault = Some(vault);
    }

    /// Spawn `name`'s profile as a slot thread. `RasterMode::Off` always
    /// (the TUI never attaches a `Renderer`); the slot logs in
    /// immediately and re-handshakes after a DC only when the profile's
    /// `auto_login` is on.
    fn spawn(&mut self, name: &str) -> bool {
        let Some(mut profile) = self.vault.as_ref().and_then(|v| v.get(name)).cloned() else {
            return false;
        };
        profile.settings.raster = vault::RasterMode::Off;
        let auto_login = profile.settings.auto_login;
        let arm = SlotArm::new(profile.uid, true);
        arm.auto_login.store(auto_login, Ordering::Relaxed);
        arm.random_events
            .store(profile.settings.random_events, Ordering::Relaxed);
        arm.lamp_auto
            .store(profile.settings.lamp_auto, Ordering::Relaxed);
        *arm.lamp_skill.lock().unwrap() = profile.settings.lamp_skill.clone();
        if let Some(play) = self.play.as_mut() {
            play.spawn_slot(profile, None, None, Some(arm));
            true
        } else {
            false
        }
    }

    /// Spawn every vault profile that is not running yet (the `m` key).
    fn spawn_all(&mut self) -> usize {
        let names: Vec<String> = self
            .vault
            .as_ref()
            .map(|v| v.profiles().map(|p| p.username.clone()).collect())
            .unwrap_or_default();
        let mut spawned = 0;
        for name in names {
            if self.play.as_ref().is_some_and(|p| p.arm(&name).is_some()) {
                continue;
            }
            if self.spawn(&name) {
                spawned += 1;
            }
        }
        spawned
    }

    /// Focus `name` in the play (pure bookkeeping in the flat model).
    fn focus(&mut self, name: &str) {
        if let Some(play) = self.play.as_mut() {
            play.focus(name);
        }
    }

    /// `--live script_*` boot: minted ephemeral vault + spawn + runner.
    fn live_prepare_script(&mut self, scenario: scenario::Scenario) -> Result<(), String> {
        let name = scenario.name.to_string();
        let start_script = scenario.settings.start_script;
        let settings_inject = scenario.settings.script_settings_inject;
        let names = mint_live_names(scenario.seed.profiles.len());
        let entries = mint_live_entries(&names);
        let pass = live_vault_passphrase();
        let path = temp_live_vault(&entries, &pass);
        self.unlock_at(&path, &pass)?;
        self.live_name = Some(name);
        let mut runner = scenario::ScenarioRunner::new(scenario);
        if let Some(budget) = scenario::budget_s_from_env() {
            runner.set_deadline(budget);
            self.live_soak_until = Some(Instant::now() + budget);
            self.live_announced_pass = false;
        }
        runner.set_live_names(&names);
        if let Some(play) = &self.play {
            runner.set_obj_names(play.obj_names());
        }
        *self.scenario.lock().unwrap() = Some(runner);
        self.script_settings_inject = scenario::settings_inject_map(settings_inject);
        self.names = names.clone();
        for n in &names {
            self.spawn(n);
        }
        self.focus(&names[0]);
        // A scenario that names a script card selects the real `$RS2B0T`
        // catalog script on the driven slot (same as the panel): fill the
        // catalog from `$RS2B0T`, then Start on StartScript after seed.
        if let Some(card_name) = start_script {
            self.fill_rs2b0t_cards_once();
            self.js
                .ensure_js(script::ScriptSource::Catalog, card_name)
                .map_err(|e| format!("transpile {card_name}: {e}"))?;
            let card = self
                .js
                .get(script::ScriptSource::Catalog, card_name)
                .cloned()
                .ok_or_else(|| {
                    format!("$RS2B0T catalog has no {card_name} card (is $RS2B0T set?)")
                })?;
            self.script_sel = Some(script::ScriptSel::Loaded(
                script::ScriptSource::Catalog,
                card_name.to_string(),
            ));
            let bag = self.pending_settings_bag(
                script::ScriptSource::Catalog,
                card_name,
                &card.settings_schema,
            );
            let siblings = script::resolve_sibling_modules(
                &card.path,
                &card.origin,
                self.js.cache(),
                script::CacheMeta {
                    kind: card.kind,
                    source: card.source,
                    shape: None,
                },
            )?;
            *self.pending_script.lock().unwrap() = Some(PendingCatalogStart {
                slot: names[0].clone(),
                js: card.js.clone(),
                shape: card.shape,
                bag,
                siblings,
            });
        }
        Ok(())
    }

    /// The focused slot's last published [`WorldState`] (inv/equipment/
    /// stats/varps/quests), or the fail-closed empty state when the slot
    /// has not published yet.
    fn focused_walk_state(&self, name: &Option<String>) -> WorldState {
        name.as_deref()
            .and_then(|n| {
                self.snapshots
                    .lock()
                    .unwrap()
                    .get(n)
                    .map(WorldState::from_snapshot)
            })
            .unwrap_or_else(WorldState::empty)
    }

    /// Map Walk-confirm: store the picked dest, then route and arm the
    /// focused slot's walk arm when the player tile and nav world are
    /// known (`host_play::arm_walk_on`, the same shared arm the panel
    /// uses — the two views cannot drift).
    fn arm_walk_on(&mut self, app: &mut TuiApp, dest: Tile) {
        app.walk_dest = Some(dest);
        self.walk_clear.store(false, Ordering::Relaxed);
        let name = app.focused_name();
        let from = app.here.map(|h| Tile {
            x: h.x,
            z: h.z,
            level: h.level,
        });
        let world = self.nav_world.lock().unwrap().clone();
        let (Some(world), Some(from)) = (world, from) else {
            return; // no player tile / no pack: dest stored only
        };
        let state = self.focused_walk_state(&name);
        let bank = name
            .as_deref()
            .and_then(|n| {
                self.snapshots.lock().unwrap().get(n).map(|snap| {
                    snap.bank()
                        .iter()
                        .map(|it| (it.def.id, it.count))
                        .collect::<Vec<_>>()
                })
            })
            .unwrap_or_default();
        let routed = arm_walk_on(
            &world,
            from,
            dest,
            app.nav.find_options(),
            &state,
            &bank,
            &self.travellers,
            name.as_deref(),
        );
        app.error = match routed {
            Ok(_) => None,
            Err(_) => Some(format!("no path to {} {} {}", dest.x, dest.z, dest.level)),
        };
    }

    /// WASD one-tile walk: a direct `try_move` through the slot's wire
    /// queue (adjacent world tile; the client pathfinds the step).
    fn wasd_walk(&self, app: &TuiApp, dest: Tile) {
        let Some(name) = app.focused_name() else {
            return;
        };
        if let Some(play) = &self.play {
            play.queue_wire(
                &name,
                WireCmd::Walk {
                    x: dest.x,
                    z: dest.z,
                    level: dest.level,
                },
            );
        }
    }

    /// Chat modal advance: queue `continue_dialog` / `answer_choice` on
    /// the focused slot (the guardian's hold still lets chat through).
    fn chat_send(&self, app: &TuiApp, action: ChatAction) {
        let Some(name) = app.focused_name() else {
            return;
        };
        if let Some(play) = &self.play {
            match action {
                ChatAction::Continue => play.queue_wire(&name, WireCmd::Continue),
                ChatAction::Answer(option) => {
                    play.queue_wire(&name, WireCmd::Answer(option as i32))
                }
                ChatAction::None => {}
            }
        }
    }

    /// Fill the JS library's cards from the `$RS2B0T` registry once when
    /// the env/persisted root is already known (live boot). Errors are debug-only.
    fn fill_rs2b0t_cards_once(&mut self) {
        if self.rs2b0t_filled {
            return;
        }
        self.rs2b0t_filled = true;
        if let Some(root) = script::rs2b0t_root() {
            if let Err(e) = self
                .js
                .register_rs2b0t(&root, &script::default_rs2b0t_path_file())
            {
                if std::env::var("BOT_DEBUG").is_ok() {
                    eprintln!("[tui-play] $RS2B0T registry: {e}");
                }
            }
        }
    }

    /// Opening Browse: fill from `$RS2B0T`/persisted root, or prompt for a
    /// clone root, or honour a prior defer (panel parity).
    fn on_script_browse_open(&mut self, app: &mut TuiApp) {
        if self.rs2b0t_filled {
            return;
        }
        self.rs2b0t_filled = true;
        if let Some(root) = script::rs2b0t_root() {
            if let Err(e) = self
                .js
                .register_rs2b0t(&root, &script::default_rs2b0t_path_file())
            {
                if std::env::var("BOT_DEBUG").is_ok() {
                    eprintln!("[tui-play] $RS2B0T registry: {e}");
                }
            }
            return;
        }
        if script::rs2b0t_import_deferred_at(&script::default_rs2b0t_import_file()) {
            return;
        }
        self.rs2b0t_catalog_open = true;
        self.rs2b0t_catalog_dir = Self::default_catalog_browse_dir();
        app.rs2b0t_catalog_open = true;
        app.rs2b0t_catalog_dir = self.rs2b0t_catalog_dir.clone();
        app.catalog_sel = 0;
    }

    fn defer_rs2b0t_catalog(&mut self, app: &mut TuiApp) {
        let _ = script::set_rs2b0t_import_deferred_at(&script::default_rs2b0t_import_file());
        self.rs2b0t_catalog_open = false;
        app.rs2b0t_catalog_open = false;
    }

    fn import_rs2b0t_catalog(&mut self, app: &mut TuiApp, root: &Path) -> Result<usize, String> {
        if !rs2b0t_root_has_index(root) {
            return Err(format!(
                "no catalog at {}",
                script::registry_index_path(root).display()
            ));
        }
        let n = self
            .js
            .register_rs2b0t(root, &script::default_rs2b0t_path_file())?;
        let _ = script::clear_rs2b0t_import_at(&script::default_rs2b0t_import_file());
        self.rs2b0t_catalog_open = false;
        app.rs2b0t_catalog_open = false;
        Ok(n)
    }

    /// Start the Browse-selected card on the focused slot.
    fn script_start(&mut self, app: &mut TuiApp, sel: &script::ScriptSel) {
        let Some(name) = app.focused_name() else {
            app.error = Some("script: no focused profile".into());
            return;
        };
        let result = match &self.play {
            Some(play) => match sel {
                script::ScriptSel::Loaded(source, card_name) => {
                    match self.js.get(*source, card_name) {
                        Some(card) if card.unloadable.is_some() => Err(format!(
                            "unloadable import: {}",
                            card.unloadable.as_deref().unwrap_or("")
                        )),
                        Some(_) => match self.js.ensure_js(*source, card_name) {
                            Err(e) => Err(e),
                            Ok(()) => match self.js.get(*source, card_name) {
                                Some(card) => {
                                    let bag = self.pending_settings_bag(
                                        *source,
                                        card_name,
                                        &card.settings_schema,
                                    );
                                    match script::resolve_sibling_modules(
                                        &card.path,
                                        &card.origin,
                                        self.js.cache(),
                                        script::CacheMeta {
                                            kind: card.kind,
                                            source: card.source,
                                            shape: None,
                                        },
                                    ) {
                                        Ok(siblings) => play.script_start_load(
                                            &name,
                                            card.js.clone(),
                                            card.shape,
                                            bag,
                                            siblings,
                                        ),
                                        Err(e) => Err(e),
                                    }
                                }
                                None => Err(format!("no loaded script: {card_name}")),
                            },
                        },
                        None => Err(format!("no loaded script: {card_name}")),
                    }
                }
                script::ScriptSel::Compiled(id) => play.script_start(&name, *id),
            },
            None => Err("no play".to_string()),
        };
        app.error = match result {
            Ok(()) => None,
            Err(e) => Some(format!("script: {e}")),
        };
    }

    /// Pause or resume the focused slot's script (toggle like the panel).
    fn script_toggle_pause(&mut self, app: &mut TuiApp) {
        let Some(name) = app.focused_name() else {
            return;
        };
        if let Some(play) = &self.play {
            if play.script_state(&name) == script::RunState::Paused {
                play.script_resume(&name);
            } else {
                play.script_pause(&name);
            }
        }
    }

    /// Stop the focused slot's script.
    fn script_stop(&mut self, app: &mut TuiApp) {
        let Some(name) = app.focused_name() else {
            return;
        };
        if let Some(play) = &self.play {
            play.script_stop(&name);
        }
    }

    /// Load a local JS bot file into the library, select it for Start,
    /// and persist the store. Errors land on the strip.
    fn script_load(&mut self, app: &mut TuiApp, path: &Path) {
        match self.js.load(path) {
            Ok(card) => {
                app.script_sel = Some(script::ScriptSel::Loaded(card.source, card.name));
                app.error = None;
                if let Some(parent) = path.parent() {
                    self.script_load_last_dir = Some(parent.to_path_buf());
                    app.script_load_last_dir = self.script_load_last_dir.clone();
                }
            }
            Err(e) => app.error = Some(format!("script: {e}")),
        }
    }

    /// Persist the settings popup's changes onto the focused vault
    /// profile (the operator vault; `--live`'s temp vault is ephemeral)
    /// and mirror guardian settings onto a running slot's arm.
    fn persist_settings(&mut self, app: &mut TuiApp) {
        let Some(vault) = self.vault.as_mut() else {
            return;
        };
        let Some(name) = app.focused_name() else {
            return;
        };
        let Some(mut profile) = vault.get(&name).cloned() else {
            return;
        };
        profile.settings = app.settings.clone();
        let random_events = profile.settings.random_events;
        let lamp_auto = profile.settings.lamp_auto;
        let lamp_skill = profile.settings.lamp_skill.clone();
        if let Err(e) = vault.upsert(profile) {
            app.error = Some(format!("settings: {e}"));
        }
        if let Some(arm) = self.play.as_ref().and_then(|p| p.arm(&name)) {
            arm.random_events.store(random_events, Ordering::Relaxed);
            arm.lamp_auto.store(lamp_auto, Ordering::Relaxed);
            *arm.lamp_skill.lock().unwrap() = lamp_skill;
        }
    }

    /// Copy the focused slot's views into the app and poll the runner.
    fn pump(&mut self, app: &mut TuiApp) {
        #[cfg(feature = "memory-profile")]
        if let Some(run) = self.memory.as_mut() {
            app.focused = Some(run.focus_index());
            if let Some(play) = self.play.as_mut() {
                play.focus(&run.names[run.focus_index()]);
                // Data-only nav capture: drain checkpoint JSON immediately —
                // no GUI focus, no screenshots, no 25s terminal wait (panel
                // keeps its own screenshot drain/timeout semantics).
                // Do not gate Ok/Err completion on pending screenshot-style
                // queues: drain always dequeues/discards and reports counts.
                if host_play::nav_capture::enabled() {
                    // Routine pump: silent when queue empty; notes/loss only.
                    report_nav_json_drain(host_play::nav_capture::drain_json_files());
                }
                match run.poll(play) {
                    Ok(true) => {
                        if host_play::nav_capture::enabled() {
                            report_nav_json_drain_terminal(
                                host_play::nav_capture::drain_json_files(),
                            );
                        }
                        eprintln!("PASS: memory tui observation complete");
                        std::process::exit(0);
                    }
                    Ok(false) => {}
                    Err(error) if host_play::nav_capture::enabled() => {
                        // Immediate drain of existing checkpoints / failure
                        // boundary already latched by nav failure path.
                        // Preserve original Err/exit1 — never hold for observe.
                        report_nav_json_drain_terminal(
                            host_play::nav_capture::drain_json_files(),
                        );
                        eprintln!("FAIL: memory tui: {error}");
                        std::process::exit(1);
                    }
                    Err(error) => {
                        eprintln!("FAIL: memory tui: {error}");
                        std::process::exit(1);
                    }
                }
            }
        }

        let statuses = self.play.as_ref().map(|p| p.statuses()).unwrap_or_default();
        // Running slots join the strip even when they are not in the
        // vault (live minted names).
        let mut names = self.names.clone();
        for s in &statuses {
            if !names.contains(&s.username) {
                names.push(s.username.clone());
            }
        }
        app.names = names;
        app.statuses = statuses;
        // The script pane's Browse picker lists library cards with registry fields.
        app.script_cards = self.js.cards().iter().map(BrowseCard::from).collect();
        let present = categories_present(&app.script_cards);
        let order = resolve_category_order(&self.script_category_order, &present);
        if order != self.script_category_order {
            self.script_category_order = order.clone();
        }
        app.script_category_order = self.script_category_order.clone();
        app.params_schema = match &app.script_sel {
            Some(script::ScriptSel::Loaded(source, name)) => self
                .js
                .get(*source, name)
                .map(|c| c.settings_schema.clone())
                .unwrap_or_default(),
            _ => Vec::new(),
        };
        if app.params_state.open && app.params_schema.is_empty() {
            app.params_state.open = false;
        }
        app.rs2b0t_catalog_open = self.rs2b0t_catalog_open;
        app.script_load_last_dir = self.script_load_last_dir.clone();
        if !app.rs2b0t_catalog_open {
            app.rs2b0t_catalog_dir = self.rs2b0t_catalog_dir.clone();
        } else {
            self.rs2b0t_catalog_dir.clone_from(&app.rs2b0t_catalog_dir);
        }
        // The map paints `Play`'s packed collision, not the live loc
        // snapshot. Copy the session world each pump (an `Arc` clone)
        // so a loaded pack is not stuck behind the empty-state title.
        app.world = self.nav_world.lock().unwrap().clone();
        app.refresh();

        // The settings popup edits the focused profile: reload when the
        // focus changes (a fresh focus must not show the old slot's
        // random toggle).
        let focused = app.focused_name();
        if self.last_focused.as_deref() != focused.as_deref() {
            self.last_focused = focused.clone();
            app.settings = focused
                .as_deref()
                .and_then(|n| self.vault.as_ref().and_then(|v| v.get(n)))
                .map(|p| p.settings.clone())
                .unwrap_or_default();
            app.settings_state.open = false;
        }

        if let Some(name) = &focused {
            // The paint-as-chat toggle is operator state: rebuild the
            // pane data without losing it across pumps.
            let show_game_chat = app.chat_data.show_game_chat;
            // Borrow the focused slot's snapshot under the lock and copy
            // the small views the panes need (GameSnapshot is not Clone).
            let snap = self.snapshots.lock().unwrap();
            match snap.get(name) {
                Some(s) => {
                    app.chat_data = chat_data_from(s);
                    app.chat_data.show_game_chat = show_game_chat;
                    app.inv_items = s
                        .inventory()
                        .iter()
                        .map(|i| (i.def.name.clone().unwrap_or_else(|| "?".into()), i.count))
                        .collect();
                    app.stats_rows = s
                        .stats()
                        .iter()
                        .filter(|st| st.used)
                        .map(|st| (st.name.clone(), st.effective))
                        .collect();
                    let here = app.here;
                    app.locs_near = s
                        .locs()
                        .iter()
                        .filter_map(|l| {
                            let name = l.name.as_deref()?.to_string();
                            let d = here
                                .map(|h| (l.tile.x - h.x).abs().max((l.tile.z - h.z).abs()))
                                .unwrap_or(l.distance);
                            Some((d, name))
                        })
                        .collect();
                    app.locs_near.sort_by_key(|(d, _)| *d);
                    app.locs_near.truncate(3);
                }
                None => {
                    // A slot with no published snapshot must not show the
                    // previous focused slot's chat / inventory.
                    app.chat_data = ChatData::default();
                    app.chat_data.show_game_chat = show_game_chat;
                    app.inv_items.clear();
                    app.stats_rows.clear();
                    app.locs_near.clear();
                }
            }
            drop(snap);
            // The script's paint frame rides the status row (copied from
            // the isolate each observe); the chat pane shows it in place
            // of the game chat while it is non-empty.
            app.chat_data.script_paint =
                app.focused_status().and_then(|st| st.script_paint.clone());
            // Stop drops the isolate (and its paint with it); reset the
            // operator's game-chat toggle when no paint is showing so a
            // fresh Start shows the new paint by default instead of
            // hiding it until `p` again.
            if app.chat_data.script_paint.is_none() {
                app.chat_data.show_game_chat = false;
            }
            app.route = self
                .travellers
                .lock()
                .unwrap()
                .get(name)
                .and_then(|a| a.lock().unwrap().route.clone());
            if self.walk_clear.swap(false, Ordering::Relaxed) {
                app.walk_dest = None;
            }
            if let Some(play) = &self.play {
                app.script_state = play.script_state(name);
            }
        }
        if app.settings_dirty {
            self.persist_settings(app);
            app.settings_dirty = false;
        }
    }

    /// The `--live` terminal state: `Some(exit code)` when the runner
    /// passed (0) or failed (1); `None` while it runs.
    fn live_status(&mut self) -> Option<i32> {
        let name = self.live_name.as_deref().unwrap_or("script");
        let status = self.scenario.lock().unwrap().as_ref().map(|r| r.status());
        let evidence = self
            .scenario
            .lock()
            .unwrap()
            .as_ref()
            .and_then(|r| r.evidence().cloned())
            .map(|ev| ev.to_json())
            .unwrap_or_default();
        match status {
            Some(scenario::RunnerStatus::Passed) => {
                if !self.live_announced_pass {
                    println!("PASS: live {name} {evidence}");
                    self.live_announced_pass = true;
                }
                if self.live_soak_until.is_some_and(|t| Instant::now() < t) {
                    return None;
                }
                Some(0)
            }
            Some(scenario::RunnerStatus::Failed(msg)) => {
                eprintln!("FAIL: live {name} {evidence}");
                eprintln!("FAIL: {msg}");
                Some(1)
            }
            _ => None,
        }
    }
}

/// The chat pane's owned data, copied from the focused snapshot each pump.
fn chat_data_from(s: &api::snapshot::GameSnapshot) -> ChatData {
    ChatData {
        lines: s.chat_lines().to_vec(),
        modal_texts: s.chat_modal_texts().to_vec(),
        options: s.chat_options().to_vec(),
        has_continue: s.chat_continue_component_id() != -1,
        // The paint rides the status row, not the snapshot; the pump
        // patches it in, and the toggle is operator state.
        script_paint: None,
        show_game_chat: false,
    }
}

/// Run the interactive (or `--live`) TUI: unlock, spawn, event loop.
fn run(args: &Args, mode: RunMode) -> Result<i32, String> {
    let mut session = TuiSession::new(PlayOptions {
        host: args.host.clone(),
        port: args.port,
        cache_dir: args.cache.clone(),
        lowmem: true,
        mainland: false,
    });

    #[cfg(feature = "memory-profile")]
    if let Some(config) = host_play::memory::Config::from_env()? {
        host_play::memory::require_live_benchmark()?;
        // Vault/card first; unlock constructs Play once (single load_pack).
        let run = host_play::memory::Run::prepare_unseeded(config, "tui")?;
        session.options.mainland = true;
        session.unlock_at(&run.vault, &run.pass)?;
        run.bind_seed_nav(host_play::memory::SeedNav::FromPlay(
            session.play.as_ref().and_then(|p| p.world()),
        ))?;
        session.names = run.names.clone();
        session.spawn_all();
        session.focus(&run.names[0]);
        let mut app = TuiApp::new("274bot memory benchmark");
        app.names = run.names.clone();
        app.focused = Some(0);
        session.memory = Some(run);
        return run_loop(session, app);
    }

    match mode {
        RunMode::Live(name) => {
            let scenario = live_scenario(&name)?;
            session.options.mainland = scenario.seed.mainland;
            session.live_prepare_script(scenario)?;
            let mut app = TuiApp::new(format!("tui-play --live {name}"));
            app.names = session.names.clone();
            app.focused = Some(0);
            run_loop(session, app)
        }
        RunMode::Interactive => {
            let Some(pass) = args.pass.clone() else {
                return Err("no vault passphrase (set BOT_VAULT_PASS or --vault-pass)".into());
            };
            let vault_exists = args.vault.is_file();
            if let Err(e) = session.unlock_at(&args.vault, &pass) {
                return Err(format!("vault {}: {e}", args.vault.display()));
            }
            if !vault_exists {
                // First run: create the default `test`/`test` profile so
                // unlock is not a dead end (host-play CLI convention).
                session.create_profile("test")?;
            }
            // `--user` names may not exist: create them like host-play
            // does (`password = username`, fresh uid).
            for u in &args.users {
                if session.vault.as_ref().is_none_or(|v| v.get(u).is_none()) {
                    session.create_profile(u)?;
                }
            }
            session.names = session
                .vault
                .as_ref()
                .map(|v| v.profiles().map(|p| p.username.clone()).collect())
                .unwrap_or_default();
            let focus = args
                .users
                .first()
                .cloned()
                .or_else(|| session.names.first().cloned());
            let Some(focus) = focus else {
                return Err("vault has no profiles (create one with host-play --user)".into());
            };
            session.spawn(&focus);
            session.focus(&focus);
            let mut app = TuiApp::new("274bot headless");
            app.names = session.names.clone();
            app.focused = session.names.iter().position(|n| n == &focus);
            run_loop(session, app)
        }
    }
}

impl TuiSession {
    /// Create a missing profile (host-play CLI convention: password =
    /// username, uid one past the vault's max, from the 274M base).
    fn create_profile(&mut self, username: &str) -> Result<(), String> {
        let uid = self
            .vault
            .as_ref()
            .map(|v| v.profiles().map(|p| p.uid).max().unwrap_or(274_000_000) + 1)
            .unwrap_or(274_000_001);
        let profile = Profile {
            username: username.into(),
            password: profile_password(username),
            uid,
            settings: vault::ProfileSettings::default(),
        };
        let Some(vault) = self.vault.as_mut() else {
            return Ok(());
        };
        vault.upsert(profile).map_err(|e| format!("profile: {e}"))
    }
}

/// Retain the slot that successfully recorded a TUI input start until the
/// next successful `terminal.draw`, then flush **that** origin.
///
/// One event is read per loop iteration, so a single `Option<u64>` is enough
/// (no per-loop allocation or registry scan). Only set when
/// [`host::responsiveness_profile::note_input_start`] returns true — disabled
/// or dropped starts must not fabricate an ack. Do not take/flush on draw
/// error; the retained origin waits for the next successful draw.
///
/// Host `Local` Drop already cuts `INPUT_PENDING` for a slot_id and counts
/// lost; this Option does not claim generation coverage beyond that existing
/// hook. Flushing a slot with no remaining pending is a host no-op.
fn remember_tui_input_origin(origin: &mut Option<u64>, started: bool, slot_id: u64) {
    if started {
        *origin = Some(slot_id);
    }
}

/// After a successful draw only: acknowledge the retained input origin slot.
fn flush_tui_input_origin(origin: &mut Option<u64>, at: Instant) {
    if let Some(slot_id) = origin.take() {
        host::responsiveness_profile::note_tui_draw_flush(slot_id, at);
    }
}

/// Old producer routing (focus-at-draw): complete only the post-pump focused
/// slot. Kept for regression proof that this strands a prior-focus start.
#[cfg(test)]
fn flush_tui_input_focused_at_draw(focused_slot_id: u64, at: Instant) {
    host::responsiveness_profile::note_tui_draw_flush(focused_slot_id, at);
}

/// Record a TUI key/MouseDown start against `name` when present; on success
/// retain that slot as the next-draw flush origin.
fn note_tui_input_start_for_focus(origin: &mut Option<u64>, name: Option<&str>, at: Instant) {
    let Some(name) = name else {
        return;
    };
    let slot_id = host::responsiveness_profile::slot_id_for(name);
    let started = host::responsiveness_profile::note_input_start(slot_id, at, 0);
    remember_tui_input_origin(origin, started, slot_id);
}

/// The crossterm event loop. `--live` runs headed when a controlling
/// terminal is available (the operator watches the panes) and degrades to
/// a headless pump loop otherwise, so the PASS/FAIL still lands in CI.
fn run_loop(mut session: TuiSession, mut app: TuiApp) -> Result<i32, String> {
    if enable_raw_mode().is_err() {
        // No controlling terminal: pump the runner without drawing.
        host::responsiveness_profile::set_input_surface(
            host::responsiveness_profile::InputSurface::TuiHeadless,
        );
        loop {
            session.pump(&mut app);
            if let Some(code) = session.live_status() {
                return Ok(code);
            }
            std::thread::sleep(Duration::from_millis(50));
        }
    }
    host::responsiveness_profile::set_input_surface(
        host::responsiveness_profile::InputSurface::Tui,
    );
    let mut stdout = std::io::stdout();
    crossterm::execute!(
        stdout,
        EnterAlternateScreen,
        crossterm::event::EnableMouseCapture
    )
    .map_err(|e| format!("terminal setup: {e}"))?;
    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend).map_err(|e| e.to_string())?;
    // Origin slot of a successfully-recorded key/MouseDown until next ok draw.
    let mut input_flush_origin: Option<u64> = None;

    let result = (|| loop {
        session.pump(&mut app);
        if let Some(code) = session.live_status() {
            return Ok(code);
        }
        {
        let _profile_frame = client::profiling::UI_FRAME.start();
        terminal
            .draw(|frame| {
                let _profile_draw = client::profiling::UI_DRAW.start();
                app.draw(frame);
                app.draw_loadouts_overlay(frame, &mut session.loadouts);
                app.draw_params_overlay(frame, &mut session.script_settings, &session.loadouts);
            })
            .map_err(|e| e.to_string())?;
        // Flush the input-start origin, not post-pump focused_name (focus may
        // have rotated in session.pump before this draw).
        flush_tui_input_origin(&mut input_flush_origin, Instant::now());
        }
        if event::poll(Duration::from_millis(50)).map_err(|e| e.to_string())? {
            match event::read().map_err(|e| e.to_string())? {
                Event::Key(k) if k.kind == KeyEventKind::Press => {
                    note_tui_input_start_for_focus(
                        &mut input_flush_origin,
                        app.focused_name().as_deref(),
                        Instant::now(),
                    );
                    if app.params_state.open {
                        app.params_on_key(&mut session.script_settings, &session.loadouts, k);
                    } else if app.loadouts_on_key(&mut session.loadouts, k) {
                    } else {
                        let action = app.on_key(k);
                        dispatch(&mut session, &mut app, action);
                    }
                }
                Event::Mouse(m) => {
                    if let MouseEventKind::Down(_) = m.kind {
                        note_tui_input_start_for_focus(
                            &mut input_flush_origin,
                            app.focused_name().as_deref(),
                            Instant::now(),
                        );
                        let action = app.on_click(m.column, m.row);
                        dispatch(&mut session, &mut app, action);
                    }
                }
                _ => {}
            }
        }
        if app.quit {
            return Ok(0);
        }
    })();

    disable_raw_mode().ok();
    crossterm::execute!(
        terminal.backend_mut(),
        crossterm::event::DisableMouseCapture,
        LeaveAlternateScreen
    )
    .ok();
    result
}

/// Route one [`AppAction`] onto the session: map walks arm through
/// `host_play::arm_walk_on`, chat and WASD go through [`WireCmd`], the
/// script actions dispatch `Play::script_start_load` / pause / stop /
/// the JS library, and the settings popup persists on the next pump.
fn dispatch(session: &mut TuiSession, app: &mut TuiApp, action: AppAction) {
    match action {
        AppAction::Quit => app.quit = true,
        AppAction::Focus(name) => session.focus(&name),
        AppAction::ArmWalk(tile) => session.arm_walk_on(app, tile),
        AppAction::WalkTile(tile) => session.wasd_walk(app, tile),
        AppAction::Chat(action) => session.chat_send(app, action),
        AppAction::SpawnAll => multibox_key(session, app),
        AppAction::ScriptStart(sel) => session.script_start(app, &sel),
        AppAction::ScriptPause => session.script_toggle_pause(app),
        AppAction::ScriptStop => session.script_stop(app),
        AppAction::ScriptBrowse => {
            if app.script_browse_open {
                session.on_script_browse_open(app);
            }
        }
        AppAction::ScriptImportCatalog => {
            session.rs2b0t_catalog_open = true;
            session.rs2b0t_catalog_dir = app.rs2b0t_catalog_dir.clone();
            app.rs2b0t_catalog_open = true;
            app.catalog_sel = 0;
        }
        AppAction::ScriptDeferCatalog => session.defer_rs2b0t_catalog(app),
        AppAction::ScriptUseCatalog => {
            let root = app.rs2b0t_catalog_dir.clone();
            session.rs2b0t_catalog_dir = root.clone();
            app.error = session.import_rs2b0t_catalog(app, &root).err();
        }
        AppAction::ScriptLoad(path) => session.script_load(app, &path),
        AppAction::ScriptParams => app.open_script_params(&session.script_settings),
        AppAction::None => {}
    }
}

/// The `m` key spawns the rest of the MultiBox wall.
fn multibox_key(session: &mut TuiSession, app: &mut TuiApp) {
    let spawned = session.spawn_all();
    if spawned > 0 {
        app.error = Some(format!("spawned {spawned} slot(s)"));
    }
}

/// Routine pump drain: print I/O notes and write-loss only. Empty queue is silent
/// so per-poll drains do not flood missing-capture on stderr.
#[cfg(feature = "memory-profile")]
fn report_nav_json_drain(result: host_play::nav_capture::JsonDrainResult) {
    for note in &result.notes {
        eprintln!("[nav-capture] {note}");
    }
    if let Some(note) = result.completion_note() {
        eprintln!("[nav-capture] {note}");
    }
}

/// Terminal Ok/Err boundary only: may report empty queue as boundary-local
/// (earlier files may exist). Never gates harness exit.
#[cfg(feature = "memory-profile")]
fn report_nav_json_drain_terminal(result: host_play::nav_capture::JsonDrainResult) {
    for note in &result.notes {
        eprintln!("[nav-capture] {note}");
    }
    if let Some(note) = result.terminal_boundary_note() {
        eprintln!("[nav-capture] {note}");
    }
}

pub fn main() -> ExitCode {
    let mut args = parse_args();
    if args.prod {
        client::set_bot_target(client::BotTarget::Prod);
        let (host, port) = host_play::play_endpoint_for(client::BotTarget::Prod);
        args.host = host;
        args.port = port;
        args.cache = client::cache_dir().display().to_string();
    }
    if let Err(msg) = validate_startup_host(&args.host) {
        eprintln!("{msg}");
        return ExitCode::FAILURE;
    }
    let mode = match args.live.clone() {
        Some(name) => RunMode::Live(name),
        None => RunMode::Interactive,
    };
    match run(&args, mode) {
        Ok(0) => ExitCode::SUCCESS,
        Ok(code) => ExitCode::from(code as u8),
        Err(e) => {
            eprintln!("tui-play: {e}");
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use nav::grid::StepGrid;
    use nav::router::FindOptions;
    use nav::world::NavWorld;
    use script::IsolatedEnv;
    use std::sync::Arc;

    fn dummy_options() -> PlayOptions {
        PlayOptions {
            host: "127.0.0.1".into(),
            port: 43594,
            cache_dir: "/tmp".into(),
            lowmem: true,
            mainland: false,
        }
    }

    /// The map pane reads `TuiApp::world`. The session holds the pack on
    /// `nav_world` after `Play` loads it; pump must copy that Arc so a
    /// running script's loc list is not the only live world view.
    #[test]
    fn pump_copies_nav_world_onto_the_app() {
        let mut session = TuiSession::new(dummy_options());
        *session.nav_world.lock().unwrap() =
            Some(Arc::new(NavWorld::from_grid(&StepGrid::fixture_open_3x3())));
        let mut app = TuiApp::new("274bot headless");
        assert!(app.world.is_none(), "fresh app has no pack");
        session.pump(&mut app);
        assert!(
            app.world.is_some(),
            "pump copies the session nav world onto the map"
        );
    }

    #[test]
    fn parse_args_from_prod_is_not_unknown() {
        let args = parse_args_from(["--prod"]).expect("prod is a known flag");
        assert!(args.prod);
        assert!(args.live.is_none());
    }

    #[test]
    fn validate_startup_host_refuses_non_loopback_with_local_rsa() {
        assert!(
            host_play::validate_play_host("attacker.example", client::BotTarget::Local).is_err(),
            "non-loopback host must be refused with local RSA"
        );
        assert!(host_play::validate_play_host("127.0.0.1", client::BotTarget::Local).is_ok());
        // `tui-play` startup must delegate to the shared helper (not duplicate checks).
        assert_eq!(
            validate_startup_host("attacker.example").is_ok(),
            host_play::validate_play_host("attacker.example", client::bot_target()).is_ok(),
        );
        assert_eq!(
            validate_startup_host("127.0.0.1").is_ok(),
            host_play::validate_play_host("127.0.0.1", client::bot_target()).is_ok(),
        );
    }

    #[test]
    #[cfg(unix)]
    fn create_profile_upsert_error_returns_err() {
        use std::os::unix::fs::PermissionsExt;

        let dir = std::env::temp_dir().join(format!(
            "274bot-tui-create-profile-err-{}",
            std::process::id()
        ));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("vault.vault");
        let mut session = TuiSession::new(dummy_options());
        session.start_play(Vault::create(&path, "bot").unwrap());
        std::fs::set_permissions(&dir, std::fs::Permissions::from_mode(0o500)).unwrap();
        let err = session.create_profile("alice").unwrap_err();
        assert!(
            err.starts_with("profile:"),
            "upsert failure must return Err, got {err:?}"
        );
    }

    fn fake_rs2b0t_tree(dir: &Path) -> PathBuf {
        let root = dir.join("rs2b0t");
        let scripts = root.join("src/bot/scripts");
        std::fs::create_dir_all(scripts.join("BoneBurier")).unwrap();
        std::fs::write(
            scripts.join("index.ts"),
            r#"
import BoneBurier from './BoneBurier/BoneBurier.js';
ScriptRegistry.register({
  name: 'BoneBurier',
  description: 'Buries bones',
  category: 'Prayer',
  tags: ['bones'],
  create: () => new BoneBurier(),
});
"#,
        )
        .unwrap();
        std::fs::write(
            scripts.join("BoneBurier/BoneBurier.ts"),
            "export default class BoneBurier extends LoopingBot { override loop() {} }",
        )
        .unwrap();
        root
    }

    #[test]
    fn live_prepare_bone_burier_selects_the_rs2b0t_card_without_starting() {
        let iso = IsolatedEnv::enter("tui-bone-live");
        let root = fake_rs2b0t_tree(&iso.dir);
        iso.set_rs2b0t(&root);
        let mut session = TuiSession::new(dummy_options());
        session
            .live_prepare_script(scenario::get("bone_burier").expect("registered"))
            .expect("prepare");
        let name = session.names.first().expect("minted name").clone();
        assert_ne!(name, "test", "live must not log in `test`");
        assert_eq!(
            session.script_sel,
            Some(script::ScriptSel::Loaded(
                script::ScriptSource::Catalog,
                "BoneBurier".into()
            )),
            "prepare sets script_sel to the catalog card"
        );
        let play = session.play.as_ref().expect("play started");
        assert_ne!(
            play.script_state(&name),
            script::RunState::Running,
            "isolate is not Running yet — Start waits for the StartScript step"
        );
    }

    #[test]
    fn live_prepare_thiever_posts_guard_target_when_schema_empty() {
        let iso = IsolatedEnv::enter("tui-thiever-bag");
        let root = iso.dir.join("rs2b0t");
        let scripts = root.join("src/bot/scripts");
        std::fs::create_dir_all(scripts.join("ThievingBot")).unwrap();
        std::fs::write(
            scripts.join("index.ts"),
            r#"
import ThievingBot from './ThievingBot/ThievingBot.js';
ScriptRegistry.register({ name: 'Thiever', create: () => new ThievingBot() });
"#,
        )
        .unwrap();
        std::fs::write(
            scripts.join("ThievingBot/ThievingBot.ts"),
            "export default class ThievingBot extends LoopingBot { override loop() {} }",
        )
        .unwrap();
        iso.set_rs2b0t(&root);
        let mut session = TuiSession::new(dummy_options());
        session
            .live_prepare_script(scenario::get("thiever").expect("registered"))
            .expect("prepare");
        let bag = session
            .pending_script
            .lock()
            .unwrap()
            .as_ref()
            .expect("catalog start stashed")
            .bag
            .clone()
            .expect("inject bag is posted even when the card schema is empty");
        assert_eq!(
            bag.get("target"),
            Some(&serde_json::json!("Guard")),
            "thiever inject must beat the Man fallback"
        );
    }

    #[test]
    fn first_browse_without_rs2b0t_opens_catalog_prompt() {
        let iso = IsolatedEnv::enter("tui-browse");
        let mut session = TuiSession::new(dummy_options());
        let mut app = TuiApp::new("274bot headless");
        app.script_browse_open = true;
        session.on_script_browse_open(&mut app);
        assert!(
            session.rs2b0t_catalog_open,
            "first browse opens folder picker"
        );
        assert!(
            !iso.home.join(".274bot/rs2b0t-path").exists(),
            "first browse must not write rs2b0t-path"
        );
    }

    #[test]
    fn defer_rs2b0t_catalog_leaves_no_path_and_zero_catalog_cards() {
        let iso = IsolatedEnv::enter("tui-defer");
        let mut session = TuiSession::new(dummy_options());
        let mut app = TuiApp::new("274bot headless");
        app.script_browse_open = true;
        session.on_script_browse_open(&mut app);
        session.defer_rs2b0t_catalog(&mut app);
        assert!(
            script::rs2b0t_import_deferred_at(&iso.home.join(".274bot/rs2b0t-import")),
            "defer flag written"
        );
        assert!(
            !iso.home.join(".274bot/rs2b0t-path").exists(),
            "defer must not write rs2b0t-path"
        );
        assert!(
            session
                .js
                .cards()
                .iter()
                .all(|c| c.source != script::ScriptSource::Catalog),
            "zero Catalog cards after defer"
        );
    }

    #[test]
    fn import_rs2b0t_catalog_persists_path_and_registers_cards() {
        let iso = IsolatedEnv::enter("tui-import");
        let root = fake_rs2b0t_tree(&iso.dir);
        let mut session = TuiSession::new(dummy_options());
        let mut app = TuiApp::new("274bot headless");
        let n = session
            .import_rs2b0t_catalog(&mut app, &root)
            .expect("import");
        assert_eq!(n, 1);
        assert!(iso.home.join(".274bot/rs2b0t-path").is_file());
        let card = session
            .js
            .get(script::ScriptSource::Catalog, "BoneBurier")
            .expect("catalog card");
        assert_eq!(card.description, "Buries bones");
    }

    #[test]
    fn create_profile_prod_password_is_not_username() {
        let pass = host_play::profile_password_for("alice", client::BotTarget::Prod);
        assert_ne!(pass, "alice");
        assert_eq!(
            host_play::profile_password_for("alice", client::BotTarget::Local),
            "alice"
        );
    }

    #[test]
    fn pump_leaves_app_world_none_when_no_pack_loaded() {
        let mut session = TuiSession::new(dummy_options());
        let mut app = TuiApp::new("274bot headless");
        session.pump(&mut app);
        assert!(
            app.world.is_none(),
            "no session pack stays the empty-state title"
        );
    }

    /// Task 13 fix: the paint-as-chat toggle must not stick across a
    /// Stop → new Start. A slot whose script has no paint (stopped, or
    /// not painted yet) resets the toggle, so the fresh paint is visible
    /// by default instead of hidden behind the game-chat toggle.
    /// TR-TUI-001: dispatching ScriptPause toggles pause/resume like the
    /// panel's `script_toggle_pause` (Resume when Paused, Pause when Running).
    #[test]
    fn script_pause_toggle_resumes_when_paused_and_pauses_when_running() {
        let mut play = run_with_io(&dummy_options(), vec![], |_| (None, None), |_, _, _| {});
        play.attach_arm("alice", SlotArm::new(7, false));
        let src = "export function tick(api) { api._n = (api._n||0)+1 }".to_string();
        play.script_start_load("alice", src, script::LoadShape::NativeTick, None, vec![])
            .unwrap();
        assert_eq!(play.script_state("alice"), script::RunState::Running);

        let mut session = TuiSession::new(dummy_options());
        session.inject_play(play);
        let mut app = TuiApp::new("274bot headless");
        app.names = vec!["alice".into()];
        app.focused = Some(0);

        dispatch(&mut session, &mut app, AppAction::ScriptPause);
        assert_eq!(
            session.play.as_ref().unwrap().script_state("alice"),
            script::RunState::Paused,
            "Pause while Running"
        );

        dispatch(&mut session, &mut app, AppAction::ScriptPause);
        assert_eq!(
            session.play.as_ref().unwrap().script_state("alice"),
            script::RunState::Running,
            "Resume while Paused"
        );
    }

    #[test]
    fn pump_resets_the_paint_toggle_when_the_paint_is_gone() {
        let mut session = TuiSession::new(dummy_options());
        session.names = vec!["test".into()];
        let mut app = TuiApp::new("274bot headless");
        app.focused = Some(0);
        // The operator toggled to game chat while the old script painted.
        app.chat_data.show_game_chat = true;
        session.pump(&mut app);
        assert!(
            !app.chat_data.show_game_chat,
            "a stopped/not-yet-painted slot must fall back to showing paint by default"
        );
    }

    mod bank_fetch_fixtures {
        use std::sync::Arc;

        use api::snapshot::GameSnapshot;
        use api::snapshot::WorldTile;
        use client::client::{Client, ClientConfig, ClientPlayer};
        use client::config::if_type::ComponentType;
        use client::config::{Cache, IfType, IfTypeMut, LocType, ObjType};
        use client::io::ServerProt;
        use nav::pack::BankAccess;
        use nav::transport::{TransportEdge, TransportGraph, TransportKind};
        use nav::world::NavWorld;

        pub fn bank_client() -> Client {
            let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            let addr = listener.local_addr().unwrap();
            let stream =
                client::io::ClientStream::connect(&addr.ip().to_string(), addr.port()).unwrap();
            std::mem::forget(listener);
            let mut c = host::prepare_client(
                ClientConfig {
                    host: "127.0.0.1".into(),
                    port: 1,
                    cache_dir: String::new(),
                    members: true,
                    lowmem: true,
                },
                1,
                Arc::new(Cache::default()),
                Arc::new(vec![]),
                Vec::new(),
            );
            c.stream = Some(stream);
            c.ingame = true;
            c.scene_state = 2;
            c.map_build_base_x = 3200;
            c.map_build_base_z = 3200;
            c.minusedlevel = 0;
            c.local_player = Some(ClientPlayer::at(5, 5));
            {
                let cache = Arc::get_mut(&mut c.cache).expect("sole cache owner");
                cache.objs.resize(3, ObjType::default());
                cache.objs[1].id = 1;
                cache.objs[1].name = "Bones".into();
                cache.objs[2].id = 2;
                cache.objs[2].name = "Lobster".into();
                cache.locs.extend(
                    (0..(2214usize.saturating_sub(cache.locs.len()))).map(|_| LocType::default()),
                );
                cache.locs[2213].id = 2213;
                cache.locs[2213].name = "Bank booth".into();
                cache.locs[2213].op = vec![None, Some("Use-quickly".into()), None, None, None];
            }
            let booth_typecode = 0x4000_0000 + (2213 << 14) + 1 + (2 << 7);
            c.world
                .set_wall(0, 5, 6, 0, 0, 0, booth_typecode, 0, 0, 0, 0, 0);
            c.main_modal_id = 600;
            c.set_iface(
                600,
                IfType {
                    id: 600,
                    layer_id: 600,
                    r#type: ComponentType::TYPE_LAYER,
                    children: Some(vec![601]),
                    ..Default::default()
                },
            );
            c.set_iface(
                601,
                IfType {
                    id: 601,
                    layer_id: 600,
                    r#type: ComponentType::TYPE_INV,
                    iop: [
                        Some("Withdraw 1".into()),
                        Some("Withdraw 5".into()),
                        Some("Withdraw 10".into()),
                        Some("Withdraw All".into()),
                        None,
                    ],
                    ..Default::default()
                },
            );
            c.set_iface_mut(
                601,
                IfTypeMut {
                    link_obj_type: Some(vec![2, 0]),
                    link_obj_number: Some(vec![20, 0]),
                    ..Default::default()
                },
            );
            c.side_modal_id = 700;
            c.set_iface(
                700,
                IfType {
                    id: 700,
                    layer_id: 700,
                    r#type: ComponentType::TYPE_LAYER,
                    children: Some(vec![701]),
                    ..Default::default()
                },
            );
            c.set_iface(
                701,
                IfType {
                    id: 701,
                    layer_id: 700,
                    r#type: ComponentType::TYPE_INV,
                    iop: [Some("Deposit All".into()), None, None, None, None],
                    ..Default::default()
                },
            );
            c.set_iface_mut(
                701,
                IfTypeMut {
                    link_obj_type: Some(vec![2, 0]),
                    link_obj_number: Some(vec![3, 0]),
                    ..Default::default()
                },
            );
            for prot in [
                ServerProt::IF_OPENMAIN,
                ServerProt::IF_OPENCHAT,
                ServerProt::UPDATE_INV_FULL,
                ServerProt::REBUILD_NORMAL,
                ServerProt::PLAYER_INFO,
            ] {
                c.bump_gens(prot);
            }
            c
        }

        pub fn bank_fetch_client() -> Client {
            let mut c = bank_client();
            {
                let cache = Arc::get_mut(&mut c.cache).expect("sole cache owner");
                cache.objs[2].name = "Knife".into();
            }
            c.side_icon[3] = 500;
            c.set_iface(
                500,
                IfType {
                    id: 500,
                    r#type: ComponentType::TYPE_INV,
                    obj_ops: true,
                    ..Default::default()
                },
            );
            c.set_iface_mut(
                500,
                IfTypeMut {
                    link_obj_type: Some(vec![2, 0]),
                    link_obj_number: Some(vec![3, 0]),
                    ..Default::default()
                },
            );
            c.set_iface_mut(
                601,
                IfTypeMut {
                    link_obj_type: Some(vec![3, 0]),
                    link_obj_number: Some(vec![20, 0]),
                    ..Default::default()
                },
            );
            c.bump_gens(ServerProt::IF_OPENMAIN);
            c.bump_gens(ServerProt::UPDATE_INV_FULL);
            c
        }

        pub fn knife_nav_world(knife_id: i32) -> NavWorld {
            let mut flags = vec![0u32; 25];
            for z in 0..5 {
                flags[z * 5 + 1] |= client::dash3d::CollisionFlag::W_E as u32;
                flags[z * 5 + 2] |= client::dash3d::CollisionFlag::W_W as u32;
            }
            let edge = TransportEdge {
                kind: TransportKind::Door,
                at: WorldTile {
                    x: 1,
                    z: 2,
                    level: 0,
                },
                to: WorldTile {
                    x: 2,
                    z: 2,
                    level: 0,
                },
                loc_id: 2882,
                option: 1,
                ticks: 2,
                dir: None,
                open_loc_id: None,
                skill_req: vec![],
                item_req: vec![],
                quest_req: vec![],
                varp_req: vec![],
                worn_req: vec![knife_id],
            };
            let mut graph = TransportGraph::default();
            graph.at.entry(edge.at).or_default().push(0);
            graph.edges.push(edge);
            let (walk, blocked) = nav::collision::pack_walk(&flags);
            NavWorld::from_parts(
                nav::collision::WorldCollision {
                    origin: WorldTile {
                        x: 0,
                        z: 0,
                        level: 0,
                    },
                    width: 5,
                    height: 5,
                    walk,
                    blocked,
                    flags: None,
                },
                graph,
                vec![nav::pack::BankStand {
                    name: "Bank booth".into(),
                    tile: WorldTile {
                        x: 0,
                        z: 4,
                        level: 0,
                    },
                    access: BankAccess::Booth { op: 2 },
                }],
            )
        }

        pub fn seed_bank_fetch_snapshot() -> GameSnapshot {
            let c = bank_fetch_client();
            let mut snap = GameSnapshot::new();
            snap.rebuild(&c);
            snap
        }
    }

    /// TR-TUI-003: Walk-confirm must pass `allow_bank_fetch` from nav
    /// settings so `arm_walk_on` can latch a BankBudget session.
    #[test]
    fn arm_walk_on_with_allow_bank_fetch_latches_bank_fetch() {
        use api::snapshot::WorldTile as SnapTile;
        use bank_fetch_fixtures::{knife_nav_world, seed_bank_fetch_snapshot};

        let mut session = TuiSession::new(dummy_options());
        *session.nav_world.lock().unwrap() = Some(Arc::new(knife_nav_world(2)));
        session
            .snapshots
            .lock()
            .unwrap()
            .insert("alice".into(), seed_bank_fetch_snapshot());
        let mut app = TuiApp::new("274bot headless");
        app.names = vec!["alice".into()];
        app.focused = Some(0);
        app.here = Some(SnapTile {
            x: 0,
            z: 0,
            level: 0,
        });
        app.nav.allow_bank_fetch = true;
        session.arm_walk_on(
            &mut app,
            Tile {
                x: 4,
                z: 4,
                level: 0,
            },
        );
        let latched = session
            .travellers
            .lock()
            .unwrap()
            .get("alice")
            .is_some_and(|a| a.lock().unwrap().bank_fetch.is_some());
        assert!(
            latched,
            "allow_bank_fetch must latch WalkArm.bank_fetch on the focused arm"
        );
    }

    /// Whole-branch fix: follow hook must pass minusedlevel, not plane 0.
    #[test]
    fn player_at_plane_one_follow_uses_level() {
        use api::snapshot::WorldTile;
        use bank_fetch_fixtures::bank_client;
        use host_play::{player_here_tile, step_walk_arm_bank_fetch, PendingBankFetch};
        use nav::bank_fetch::BankStep;
        use nav::router::Route;
        use std::collections::VecDeque;

        let mut c = bank_client();
        c.minusedlevel = 1;
        let here = player_here_tile(&c).expect("bank_client has local_player");
        assert_eq!(here.2, 1, "fixture player must be upstairs");
        let mut snap = api::snapshot::GameSnapshot::new();
        snap.rebuild(&c);
        let final_route = Route {
            dest: WorldTile {
                x: 99,
                z: 99,
                level: 0,
            },
            legs: vec![],
            ticks: 0.0,
        };
        let pending = PendingBankFetch {
            steps: VecDeque::from([BankStep::Walk {
                x: here.0,
                z: here.1,
                level: 1,
            }]),
            dest: final_route.dest,
            opts: FindOptions::default(),
            final_route: final_route.clone(),
        };

        let mut arm = WalkArm {
            bank_fetch: Some(pending.clone()),
            ..Default::default()
        };
        step_walk_arm_bank_fetch(&mut c, &snap, &mut arm, None, Some(here));
        assert_eq!(
            arm.route.as_ref().map(|r| r.dest),
            Some(final_route.dest),
            "follow at (x,z,1) must complete the stand Walk on the player plane"
        );
        assert!(
            arm.bank_fetch.is_none(),
            "stand Walk must clear bank_fetch when here matches plane 1"
        );

        let mut arm_ground = WalkArm {
            bank_fetch: Some(pending),
            ..Default::default()
        };
        step_walk_arm_bank_fetch(
            &mut c,
            &snap,
            &mut arm_ground,
            None,
            Some((here.0, here.1, 0)),
        );
        assert!(
            arm_ground.route.is_none(),
            "ground-plane here must not complete an upstairs stand Walk"
        );
    }

    /// OPT-012: the follow tick must pump BankBudget before route follow.
    #[test]
    fn follow_tick_pumps_bank_budget_step() {
        use api::snapshot::WorldTile;
        use bank_fetch_fixtures::{bank_client, knife_nav_world};
        use host_play::PendingBankFetch;
        use nav::bank_fetch::BankStep;
        use nav::router::Route;
        use std::collections::VecDeque;

        let mut c = bank_client();
        let mut snap = api::snapshot::GameSnapshot::new();
        snap.rebuild(&c);
        let world = Arc::new(knife_nav_world(2));
        let final_route = Route {
            dest: WorldTile {
                x: 4,
                z: 4,
                level: 0,
            },
            legs: vec![],
            ticks: 0.0,
        };
        let mut arm = WalkArm {
            bank_fetch: Some(PendingBankFetch {
                steps: VecDeque::from([
                    BankStep::DepositAll,
                    BankStep::Withdraw { id: 2, count: 1 },
                    BankStep::Close,
                ]),
                dest: WorldTile {
                    x: 4,
                    z: 4,
                    level: 0,
                },
                opts: FindOptions::default(),
                final_route: final_route.clone(),
            }),
            route: Some(Route {
                dest: WorldTile {
                    x: 0,
                    z: 4,
                    level: 0,
                },
                legs: vec![],
                ticks: 0.0,
            }),
            ..Default::default()
        };
        let before = c.out.pos;
        step_walk_arm_follow(&mut c, &snap, &mut arm, Some(world.as_ref()), (0, 4, 0));
        assert!(
            c.out.pos > before,
            "BankBudget pump must drive deposit on the Driver (pos {before} → {})",
            c.out.pos
        );
    }

    // --- TUI input origin ack (focus change before next draw) ---------------
    // Serialize against host process-wide responsiveness registry / pending.
    static INPUT_ORIGIN_TEST_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());

    fn row_for(sid: u64) -> host::responsiveness_profile::SlotObservation {
        host::responsiveness_profile::read()
            .expect("profile enabled")
            .into_iter()
            .find(|s| s.slot_id == sid && !s.ended)
            .expect("live row")
    }

    /// Old focus-at-draw routing: start on A, pump would move focus to B, flush
    /// B only — A stays open, B is not a real completion target.
    #[test]
    fn old_focus_at_draw_flush_strands_prior_origin() {
        let _g = INPUT_ORIGIN_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        host::responsiveness_profile::enable();
        host::responsiveness_profile::set_input_surface(
            host::responsiveness_profile::InputSurface::Tui,
        );
        let a = host::responsiveness_profile::Local::new(host::responsiveness_profile::slot_id_for(
            "tui-origin-old-a",
        ))
        .expect("enabled");
        let b = host::responsiveness_profile::Local::new(host::responsiveness_profile::slot_id_for(
            "tui-origin-old-b",
        ))
        .expect("enabled");
        let sid_a = a.slot_id();
        let sid_b = b.slot_id();
        let t0 = Instant::now();
        assert!(host::responsiveness_profile::note_input_start(sid_a, t0, 0));
        // Simulate post-pump focus B then old draw flush on focused name only.
        flush_tui_input_focused_at_draw(sid_b, t0 + Duration::from_millis(5));
        let ra = row_for(sid_a);
        let rb = row_for(sid_b);
        assert_eq!(ra.input_start_n, 1);
        assert_eq!(ra.input_complete_n, 0, "old routing leaves A open");
        assert_eq!(ra.input_pending_n, 1);
        assert_eq!(rb.input_start_n, 0);
        assert_eq!(rb.input_complete_n, 0, "B never started; no fabricated complete");
        // keep Locals alive through asserts
        drop((a, b));
    }

    /// Correct routing: start on A, focus becomes B before next draw, flush
    /// retained origin A — A completes promptly; B is not fabricated.
    #[test]
    fn origin_flush_completes_a_when_focus_moves_to_b() {
        let _g = INPUT_ORIGIN_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        host::responsiveness_profile::enable();
        host::responsiveness_profile::set_input_surface(
            host::responsiveness_profile::InputSurface::Tui,
        );
        let a = host::responsiveness_profile::Local::new(host::responsiveness_profile::slot_id_for(
            "tui-origin-fix-a",
        ))
        .expect("enabled");
        let b = host::responsiveness_profile::Local::new(host::responsiveness_profile::slot_id_for(
            "tui-origin-fix-b",
        ))
        .expect("enabled");
        let sid_a = a.slot_id();
        let sid_b = b.slot_id();
        let mut origin = None;
        let t0 = Instant::now();
        note_tui_input_start_for_focus(&mut origin, Some("tui-origin-fix-a"), t0);
        assert_eq!(origin, Some(sid_a));
        // Focus would now be B (pump); draw succeeds → flush origin A.
        flush_tui_input_origin(&mut origin, t0 + Duration::from_millis(5));
        assert!(origin.is_none());
        let ra = row_for(sid_a);
        let rb = row_for(sid_b);
        assert_eq!(ra.input_start_n, 1);
        assert_eq!(ra.input_complete_n, 1, "A completes on next successful draw");
        assert_eq!(ra.input_pending_n, 0);
        assert_eq!(rb.input_complete_n, 0, "B not fabricated");
        assert_eq!(rb.input_start_n, 0);
        drop((a, b));
    }

    #[test]
    fn origin_flush_same_focus_still_completes() {
        let _g = INPUT_ORIGIN_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        host::responsiveness_profile::enable();
        host::responsiveness_profile::set_input_surface(
            host::responsiveness_profile::InputSurface::Tui,
        );
        let a = host::responsiveness_profile::Local::new(host::responsiveness_profile::slot_id_for(
            "tui-origin-same-a",
        ))
        .expect("enabled");
        let sid_a = a.slot_id();
        let mut origin = None;
        let t0 = Instant::now();
        note_tui_input_start_for_focus(&mut origin, Some("tui-origin-same-a"), t0);
        flush_tui_input_origin(&mut origin, t0 + Duration::from_millis(3));
        let ra = row_for(sid_a);
        assert_eq!(ra.input_complete_n, 1);
        assert_eq!(ra.input_pending_n, 0);
        drop(a);
    }

    #[test]
    fn no_start_does_not_fabricate_ack_on_draw() {
        let _g = INPUT_ORIGIN_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        host::responsiveness_profile::enable();
        host::responsiveness_profile::set_input_surface(
            host::responsiveness_profile::InputSurface::Tui,
        );
        let a = host::responsiveness_profile::Local::new(host::responsiveness_profile::slot_id_for(
            "tui-origin-nostart-a",
        ))
        .expect("enabled");
        let sid_a = a.slot_id();
        let mut origin = None;
        // No focused name → no start.
        note_tui_input_start_for_focus(&mut origin, None, Instant::now());
        assert!(origin.is_none());
        // Successful start=false must not retain a slot either.
        remember_tui_input_origin(&mut origin, false, sid_a);
        assert!(origin.is_none());
        flush_tui_input_origin(&mut origin, Instant::now());
        let ra = row_for(sid_a);
        assert_eq!(ra.input_start_n, 0);
        assert_eq!(ra.input_complete_n, 0);
        drop(a);
    }

    #[test]
    fn origin_not_flushed_until_draw_success() {
        let _g = INPUT_ORIGIN_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        host::responsiveness_profile::enable();
        host::responsiveness_profile::set_input_surface(
            host::responsiveness_profile::InputSurface::Tui,
        );
        let a = host::responsiveness_profile::Local::new(host::responsiveness_profile::slot_id_for(
            "tui-origin-hold-a",
        ))
        .expect("enabled");
        let sid_a = a.slot_id();
        let mut origin = None;
        let t0 = Instant::now();
        note_tui_input_start_for_focus(&mut origin, Some("tui-origin-hold-a"), t0);
        assert_eq!(origin, Some(sid_a));
        // Draw error path: do not call flush_tui_input_origin — origin retained.
        assert_eq!(origin, Some(sid_a));
        let ra = row_for(sid_a);
        assert_eq!(ra.input_complete_n, 0);
        assert_eq!(ra.input_pending_n, 1);
        // Later successful draw flushes the held origin.
        flush_tui_input_origin(&mut origin, t0 + Duration::from_millis(10));
        let ra = row_for(sid_a);
        assert_eq!(ra.input_complete_n, 1);
        assert_eq!(ra.input_pending_n, 0);
        drop(a);
    }
}
