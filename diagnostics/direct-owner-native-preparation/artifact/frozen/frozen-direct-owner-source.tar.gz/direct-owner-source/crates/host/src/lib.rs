//! 274 bot host: one OS thread per client slot.

mod auto_run;
pub mod cadence;
pub mod input_seam_trace;
pub mod login_queue;
#[cfg(feature = "memory-owner-capture")]
pub mod owner_capture;
mod random;
pub mod render_profile;
pub mod responsiveness_cohort;
pub mod responsiveness_profile;
mod slot;
mod slot_io;

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, OnceLock};
use std::thread;
use std::time::{Duration, Instant};

use api::interact::set_run;
use api::snapshot::{Family, GameSnapshot};
use auto_run::{auto_run_ready, auto_run_tick};
use client::client::{Client, ClientConfig};
use client::config::{Cache, IfType, IfTypeMut};
use client::render::backend::FrameOutput;
use client::render::Renderer;
use vault::{Profile, ProfileSettings};

pub use random::{
    detect, CooldownMap, DetectedRandom, Guardian, RandomClaim, RandomKind, RandomStatus,
};
pub use slot::{dirty_families, should_emit_tick, DirtyFamilies, DrainResult, Pump};
pub use slot_io::{
    map_image_to_applet, wake_channel, FrameBuf, InputEv, SlotInput, SlotPark, SlotWake,
};

/// Host debug toggle, set by host-play's `--debug`; `BOT_DEBUG=1` enables it
/// via [`debug_enabled`] regardless.
static DEBUG: AtomicBool = AtomicBool::new(false);
static BOT_DEBUG_ENV: OnceLock<bool> = OnceLock::new();

/// Enable host debug logging (host-play maps `--debug` to this).
pub fn set_debug(enabled: bool) {
    DEBUG.store(enabled, Ordering::Relaxed);
}

/// Host debug logging is on when `BOT_DEBUG=1` or [`set_debug`] ran.
pub fn debug_enabled() -> bool {
    debug_flag() || *BOT_DEBUG_ENV.get_or_init(read_bot_debug_env)
}

fn read_bot_debug_env() -> bool {
    debug_env_value(std::env::var_os("BOT_DEBUG").as_deref())
}

fn debug_env_value(value: Option<&std::ffi::OsStr>) -> bool {
    value == Some(std::ffi::OsStr::new("1"))
}

/// Non-allocating host debug latch (`set_debug` / `--debug` only).
/// Prefer [`debug_enabled`] for full `BOT_DEBUG=1` semantics.
#[inline]
pub fn debug_flag() -> bool {
    DEBUG.load(Ordering::Relaxed)
}

/// The 274 client's frame time: one `mainloop` pass every 20 ms.
const FRAME_MS: Duration = Duration::from_millis(20);

/// `BOT_DEBUG=1` summaries: every N `client_frame`s, **not** per game tick.
const DEBUG_SUMMARY_EVERY: u32 = 50;
/// One `client_frame` over this (µs) is a hitch vs the 20 ms cadence.
/// Logged as `[host] hitch` only — default `BOT_DEBUG=1` stays a window summary.
const HITCH_US: u64 = 50_000;
/// Observe sits in front of present. One missed ~60 fps frame is enough
/// to feel, and the 50 ms `client_frame` hitch never sees it.
const OBSERVE_HITCH_US: u64 = 16_000;

#[derive(Clone, Copy, Default)]
struct DebugSnap {
    loop_ns: u64,
    raster_ns: u64,
    observe_ns: u64,
    paint_n: u64,
    skip_n: u64,
    tick_n: u64,
}

/// Deltas since the last summary, in µs / counts.
fn debug_window_delta(prev: DebugSnap, now: DebugSnap) -> (u64, u64, u64, u64, u64, u64) {
    (
        now.loop_ns.wrapping_sub(prev.loop_ns) / 1000,
        now.raster_ns.wrapping_sub(prev.raster_ns) / 1000,
        now.observe_ns.wrapping_sub(prev.observe_ns) / 1000,
        now.paint_n.wrapping_sub(prev.paint_n),
        now.skip_n.wrapping_sub(prev.skip_n),
        now.tick_n.wrapping_sub(prev.tick_n),
    )
}

fn debug_hitch_us(frame_us: u64) -> Option<u64> {
    (frame_us >= HITCH_US).then_some(frame_us)
}

fn debug_observe_hitch_us(observe_us: u64) -> Option<u64> {
    (observe_us >= OBSERVE_HITCH_US).then_some(observe_us)
}

/// Park bound for an idle slot: the 274 server's game-tick cadence
/// (`PLAYER_INFO` every ~600 ms), so a missed/absent packet never leaves a
/// parked slot asleep past one tick.
const IDLE_PARK_MS: Duration = Duration::from_millis(600);

/// Park bound while the client socket is stalled (a wake consumed no bytes:
/// EOF, or a packet still mid-flight). Shorter than the tick bound so the
/// wall-clock game-loop watchdog still notices a dead server promptly, but
/// long enough that a permanently-readable socket cannot busy-spin the slot.
const STALL_PARK_MS: Duration = Duration::from_millis(200);

/// Park bound for a watch-only 1 fps sidecar: the 1 s wall-clock repaint
/// cadence. The slot wakes once a second to drain the socket and decide
/// the paint; a packet arriving mid-park still wakes the poll immediately,
/// so nothing is ever dropped.
const WATCH_PARK_MS: Duration = Duration::from_secs(1);

/// Host: spawns and owns per-client slot threads.
pub struct Host;

/// Build a slot `Client` from a process-wide cache and the shared iface
/// decode `Arc` (no second unpack / CRC probe). `error_loading` is false
/// after a successful `from_shared`.
pub fn prepare_client(
    config: ClientConfig,
    uid: i32,
    cache: Arc<Cache>,
    ifaces: Arc<Vec<Option<Box<IfType>>>>,
    ifaces_mut: impl Into<Arc<Vec<Option<Arc<IfTypeMut>>>>>,
) -> Client {
    let mut client = Client::from_shared(config, cache, ifaces, ifaces_mut);
    client.login_uid = uid;
    client
}

impl Host {
    /// Spawn one slot thread. Builds a `Client` from the shared cache/iface
    /// template (see [`prepare_client`]), then drives `mainloop` via
    /// [`Host::run_client`] at 20 ms. Login + `maininit` live in host-play
    /// so the FIFO sits in front of the handshake.
    pub fn spawn_slot(
        config: ClientConfig,
        profile: Profile,
        cache: Arc<Cache>,
        ifaces_template: Arc<Vec<Option<Box<IfType>>>>,
        ifaces_mut_template: Arc<Vec<Option<Arc<IfTypeMut>>>>,
    ) -> thread::JoinHandle<()> {
        thread::spawn(move || {
            let mut client = prepare_client(
                config,
                profile.uid,
                cache,
                ifaces_template,
                ifaces_mut_template,
            );

            if debug_enabled() {
                eprintln!("[host] slot {}: thread up", profile.username);
            }

            let settings = profile.settings;
            let lamp_auto = settings.lamp_auto;
            let lamp_skill = settings.lamp_skill.clone();
            Self::run_client(
                &mut client,
                &profile.username,
                settings,
                Arc::new(AtomicBool::new(true)),
                Arc::new(AtomicBool::new(lamp_auto)),
                Arc::new(Mutex::new(lamp_skill)),
                None,
                None,
                None,
                #[cfg(feature = "snapshot-dedup")]
                None,
                |_, _, _, _| false,
                |_| false,
                |_| RandomClaim::Host,
            );
        })
    }

    /// Drive one client's `mainloop` at the slot cadence until `probe`
    /// returns true (checked before every tick, so the slot thread can stop
    /// a rail ✕ or return to its control loop within one frame). Each
    /// tick [`Host::client_tick`] runs `observe` **before** [`Host::client_frame`]
    /// so the panel can latch slot state (draw/focus) before the paint
    /// decision for **this** tick, then drains input, latches the click,
    /// runs `mainloop`, and renders (via the slot's optional `Renderer`)
    /// only while `client.draw` is on. Dirty snapshot families
    /// rebuild from [`DrainResult::dirty`] (not `Pump::dirty()` after
    /// drain); think (auto-run) reads
    /// energy from the snapshot stat view when it has been rebuilt. The
    /// third observe arg is the count of accepted auto-run `set_run(true)`
    /// sends (from the previous tick); the fourth is the [`RandomStatus`]
    /// the previous frame's guardian published — the observe copies it
    /// onto the slot status row and gates script tick / follow on its
    /// hold. Observe's return is whether the slot has script/cheat/nav
    /// work, which keeps a busy slot on the frame loop. `settings` is the
    /// slot's vault profile settings (the guardian's toggle); `knock` is
    /// the script's rising-edge `on_random` arm (`Host` when the slot has
    /// no scripts).
    ///
    /// The scheduler is event-driven: a slot that captures input, is still
    /// loading (TV static), or runs full-rate TV keeps the fixed 20 ms
    /// [`FRAME_MS`] loop — that loop *is* the render cadence. A watch-only
    /// 1 fps sidecar (draw on, nothing on the 20 ms loop) parks on the 1 s
    /// wall-clock repaint bound; everything else parks on `poll(2)` over
    /// the client socket's readability, the `ctl` control wake
    /// (focus/draw/stop/spawn), and the game-tick timeout ([`IDLE_PARK_MS`]),
    /// waking once per park to drain the socket and re-evaluate. Packets
    /// are never dropped: a readable socket wakes the park, and `mainloop`
    /// is the first thing that drains it. A wake that consumed no bytes
    /// (EOF, partial packet) skips the socket on the next park so it cannot
    /// busy-spin.
    // The pub surface threads the slot's shared handles plus the guardian
    // status/knock; a context struct would churn every call site, so the
    // arg count is allowed on purpose (same as host-play's observe).
    #[allow(clippy::too_many_arguments)]
    pub fn run_client<F, P, K>(
        client: &mut Client,
        username: &str,
        settings: ProfileSettings,
        random_events: Arc<AtomicBool>,
        lamp_auto: Arc<AtomicBool>,
        lamp_skill: Arc<Mutex<String>>,
        input: Option<Arc<SlotInput>>,
        mailbox: Option<Arc<FrameBuf>>,
        ctl: Option<Arc<SlotPark>>,
        #[cfg(feature = "snapshot-dedup")] dedup_instance: Option<
            api::snapshot_dedup::SlotDedupInstance,
        >,
        mut observe: F,
        mut probe: P,
        mut knock: K,
    ) where
        F: FnMut(&mut Client, &str, u32, &RandomStatus) -> bool,
        P: FnMut(&mut Client) -> bool,
        K: FnMut(&DetectedRandom) -> RandomClaim,
    {
        let mut slot = SlotLoop {
            settings,
            random_events,
            lamp_auto,
            lamp_skill,
            render_prof: render_profile::Local::new(render_profile::slot_id_for(username)),
            resp_prof: responsiveness_profile::Local::new(responsiveness_profile::slot_id_for(
                username,
            )),
            ..SlotLoop::new()
        };
        // Slot-instance token: use the caller's instance when shared with
        // host-play/panel owners; otherwise a run-local instance so direct
        // Host::run_client exits free the registry (no process-wide name leak).
        #[cfg(feature = "snapshot-dedup")]
        let _dedup_keep_alive = {
            let instance =
                dedup_instance.unwrap_or_else(api::snapshot_dedup::SlotDedupInstance::new);
            slot.snapshot.attach_dedup(instance.attach());
            instance
        };
        let mut run_sends = 0u32;
        // The last published random-event status: `client_frame` returns it
        // and the next observe copies it onto the slot's status row and
        // gates script tick / follow on its hold.
        let mut status = RandomStatus::default();
        // Prime busy so the first pass runs one tick: the cadence decision
        // must see the observe hook's draw/capture/busy mirror, which only
        // exists after a tick has run.
        let mut busy = true;
        // A socket wake that consumed no bytes leaves the socket readable,
        // so re-polling it would busy-spin; skip the socket until a tick
        // consumes bytes again.
        let mut socket_stalled = false;
        let mut cadence = cadence::Local::new(cadence::slot_id_for(username));
        loop {
            if probe(client) {
                return;
            }
            if frame_cadence(client, input.as_deref()) || busy {
                socket_stalled = false;
                let start = std::time::Instant::now();
                let (new_busy, new_status) = Self::client_tick(
                    client,
                    &mut slot,
                    username,
                    input.as_deref(),
                    mailbox.as_deref(),
                    &mut run_sends,
                    &mut observe,
                    Some(&mut knock as &mut dyn FnMut(&DetectedRandom) -> RandomClaim),
                    &status,
                );
                busy = new_busy;
                status = new_status;
                // Java GameShell sleeps the leftover of 20 ms *after* the work.
                // A fixed sleep *before* the tick made the period 20 ms + Pix3D
                // (slow picture, extra idle). If the tick overruns, skip sleep.
                let work = start.elapsed();
                let rest = FRAME_MS.checked_sub(work);
                let sleep_start = cadence.as_ref().map(|_| Instant::now());
                if let Some(rest) = rest {
                    thread::sleep(rest);
                }
                if let Some(profile) = cadence.as_mut() {
                    let slept = if rest.is_some() { sleep_start.unwrap().elapsed() } else { Duration::ZERO };
                    profile.record(start, client.draw, work, rest.unwrap_or_default(), slept, FRAME_MS);
                }
                continue;
            }
            // Idle: park until a packet, a control kick, or the bound, then
            // run one tick (drain the socket / apply the panel's
            // `set_draw`) and re-evaluate. A watch-only sidecar wakes on
            // the 1 s repaint bound; everything else on the game-tick bound.
            if let Some(profile) = cadence.as_mut() { profile.parked(); }
            let before = stream_bytes(client);
            let timeout = if socket_stalled {
                STALL_PARK_MS
            } else if watch_only(client, input.as_deref()) {
                WATCH_PARK_MS
            } else {
                IDLE_PARK_MS
            };
            let reason = park(client, ctl.as_deref(), !socket_stalled, timeout);
            let (new_busy, new_status) = Self::client_tick(
                client,
                &mut slot,
                username,
                input.as_deref(),
                mailbox.as_deref(),
                &mut run_sends,
                &mut observe,
                Some(&mut knock as &mut dyn FnMut(&DetectedRandom) -> RandomClaim),
                &status,
            );
            busy = new_busy;
            status = new_status;
            if stream_bytes(client) != before {
                socket_stalled = false;
            } else if reason == ParkWake::Socket {
                socket_stalled = true;
            }
        }
    }

    /// One host tick: `observe` first (the panel latches slot state), then
    /// one [`Host::client_frame`]. Unfocused / renderer-off slots skip the
    /// paint on this tick, not the next. The observe hook sees the random
    /// status the previous frame's guardian published (`prev_status`) —
    /// it copies it onto the slot status row and gates script tick /
    /// follow on its hold. Returns observe's busy flag and the fresh
    /// [`RandomStatus`] this frame's guardian published.
    #[allow(private_interfaces)]
    #[allow(clippy::too_many_arguments)]
    pub fn client_tick<F>(
        client: &mut Client,
        slot: &mut SlotLoop,
        username: &str,
        input: Option<&SlotInput>,
        mailbox: Option<&FrameBuf>,
        run_sends: &mut u32,
        observe: &mut F,
        knock: Option<&mut dyn FnMut(&DetectedRandom) -> RandomClaim>,
        prev_status: &RandomStatus,
    ) -> (bool, RandomStatus)
    where
        F: FnMut(&mut Client, &str, u32, &RandomStatus) -> bool,
    {
        let _profile_tick = client::profiling::CLIENT_TICK.start();
        let t_obs = Instant::now();
        #[cfg(feature = "memory-owner-capture")]
        {
            // Immediately BEFORE observe: borrowed Client + host snapshot only.
            crate::owner_capture::pre_observe_hook(client, &slot.snapshot);
        }
        let busy = observe(client, username, *run_sends, prev_status);
        let observe_ns = t_obs.elapsed().as_nanos() as u64;
        slot.observe_ns = slot.observe_ns.wrapping_add(observe_ns);
        if observe_ns > slot.observe_max_ns {
            slot.observe_max_ns = observe_ns;
        }
        // Responsiveness: pair host-play script dispatch/cancel bridge events
        // stamped during observe with decode edges from prior after_drain.
        if let Some(resp) = slot.resp_prof.as_mut() {
            resp.drain_bridge();
        }
        if debug_enabled() {
            if let Some(us) = debug_observe_hitch_us(observe_ns / 1000) {
                eprintln!(
                    "[host] hitch {username}: observe_us={us} paints={} skips={} ticks={}",
                    slot.paint_n, slot.skip_n, slot.tick_n
                );
            }
        }
        let status = Self::client_frame(client, slot, username, input, mailbox, run_sends, knock);
        (busy, status)
    }

    /// One 20 ms frame: drain optional input into the shell, latch the
    /// click, run one `mainloop` pass, render the frame (the slot's
    /// optional `Renderer` — `client.draw` gates the paint; a drawing
    /// slot stores the rendered `FrameOutput` into the optional mailbox,
    /// mirroring `Client::run`), then drain gens. A GPU↔CPU or lowmem
    /// flip drops the `Renderer` here and reattaches it on the next paint
    /// — the `Client` and its socket never restart. The panel takes the
    /// mailbox: `FrameBuf::take` hands the whole `FrameOutput` off (the
    /// `Texture` binds / reads back at the panel, the `PixMap` packs via
    /// [`FrameBuf::snapshot`]). `run_sends` is
    /// overwritten with the slot's running count of accepted auto-run
    /// sends. Returns the [`RandomStatus`] the guardian published this
    /// frame (the pump threads it back into the next observe). `knock` is
    /// the script's rising-edge `on_random` arm; `None` (no scripts on
    /// the slot) keeps the claim Host.
    /// `SlotLoop` stays module-private (tests live in this module); the
    /// pub surface exists so `run_client` and the tests share the frame.
    #[allow(private_interfaces)]
    pub fn client_frame(
        client: &mut Client,
        slot: &mut SlotLoop,
        username: &str,
        input: Option<&SlotInput>,
        mailbox: Option<&FrameBuf>,
        run_sends: &mut u32,
        knock: Option<&mut dyn FnMut(&DetectedRandom) -> RandomClaim>,
    ) -> RandomStatus {
        if let Some(inp) = input {
            let _ = inp.drain_with_actionable_flag(&mut client.shell);
        }
        client.shell.latch_click();
        let t_loop = std::time::Instant::now();
        client.mainloop();
        slot.loop_ns = slot
            .loop_ns
            .wrapping_add(t_loop.elapsed().as_nanos() as u64);
        // Channel-tune / first rebuild: TV static must re-roll every 20 ms,
        // not the 1 fps watch cadence (otherwise the zap is one snow frame
        // a second and looks like a frozen splash).
        let zap = client.ingame && client.scene_state != 2;
        // 50 fps paint is `full_rate` (focused-50 / sidecar-50 / live overlay).
        // Capture still holds the 20 ms loop (`frame_cadence`) so input
        // drains; it does not raise paint.
        let full_rate = input.map(|i| i.full_rate()).unwrap_or(false);
        // The backend the slot's head must be built for: the per-slot
        // CpuPix3D latch **or** the process `BOT_CPU` env (both false is
        // GPU-first, the host default). SlotInput must not hide `BOT_CPU=1`.
        let want_cpu = slot_want_cpu(input);
        // A drawing slot lazily builds its `Renderer` on the first paint
        // tick; a headless (draw off) slot constructs none and never
        // enters a draw.
        // Draw off detaches: an unheaded slot must not keep headed data
        // (GPU textures, chrome) around. Cadence skips (1 fps watch, draw
        // still on) keep the renderer. A head that no longer matches the
        // live slot also detaches: GPU↔CPU and lowmem flips drop the head
        // and reattach the right backend on the **same** `Client` — never
        // a restart. The head's build *request* is compared, not the
        // fallback kind: `GpuBackend::try_new` failure lands a
        // GPU-requested head on `BackendKind::Cpu`, and dropping a head
        // whose request is unchanged would rebuild it every paint. A
        // backend/mem flip repaints this tick (like the draw toggle's
        // rising edge) so the new head attaches immediately, not on the
        // next 1 fps watch bound.
        let backend_flip = slot.renderer.is_some()
            && client.draw
            && (slot.renderer_prefer_cpu != Some(want_cpu)
                || slot.renderer_lowmem != Some(client.config.lowmem));
        if !client.draw || backend_flip {
            // Drop any GPU `FrameOutput::Texture` *before* the backend:
            // the handle's view aliases `GpuBackend.frame_texture`. 49
            // heads detaching at once (only-render-selected) would
            // otherwise leave mailboxes / ImGui bound to destroyed
            // textures.
            if let Some(mailbox) = mailbox {
                let _ = mailbox.take();
            }
            slot.renderer = None;
            slot.renderer_prefer_cpu = None;
            slot.renderer_lowmem = None;
            if backend_flip {
                slot.raster_last = None;
                slot.raster_was_on = false;
            }
            // A draw-off detach must not leave headed data on the sim:
            // drop the overlay meshes a headed build/attach wrote (keep
            // the compact tile stamps) and re-arm the attach materialize,
            // so the next head's first paint restores them without a
            // rebuild (rule 6 of the head design). Fires on the falling
            // edge only. A GPU↔CPU / mem flip drops the head while `draw`
            // stays on: overlay meshes on the sim survive, loc models do
            // not — re-arm share-light and dirty the minimap pixmap latch.
            rearm_after_head_drop(client, !client.draw && slot.draw_was_on, backend_flip);
        }
        slot.draw_was_on = client.draw;
        let paint = raster_this_tick(
            client.draw,
            zap || full_rate,
            t_loop,
            &mut slot.raster_last,
            &mut slot.raster_was_on,
        );
        let mut frame: Option<FrameOutput> = None;
        // Captured at mainredraw start for opt-in GPU completion latency
        // (sample → callback delivery). Not pre-paint host work or scanout.
        let mut redraw_started_at: Option<std::time::Instant> = None;
        if paint {
            let t_r = std::time::Instant::now();
            redraw_started_at = Some(t_r);
            // The head's build request is latched beside it so the detach
            // check above can see a GPU↔CPU or mem flip without deriving
            // it again.
            slot.renderer_prefer_cpu = Some(want_cpu);
            slot.renderer_lowmem = Some(client.config.lowmem);
            let renderer = slot.renderer.get_or_insert_with(|| {
                // A new head owns a blank 512×512 minimap. Dirty the
                // Client latch (GPU↔CPU / mem flip keeps `draw` on, so
                // `set_draw` does not) or `check_minimap` will skip.
                client.minimap_level = -1;
                // GPU-first (the host default): the slot's renderer
                // prefers the wgpu backend, with `CpuBackend` as the
                // fallback on wgpu init failure (`Renderer::new`
                // selects, `Renderer::backend_kind` reports). The
                // preference is process-wide and idempotent, so the
                // first paint of any slot opts the process in;
                // `BOT_CPU=1` forces the CPU fidelity path.
                Renderer::new_prefer(client.config.lowmem, !want_cpu)
            });
            // `mainredraw` is the fidelity seam: it runs the `check_minimap`
            // render half (loading splash + minimap image) and
            // `follow_camera` before dispatching game/title draw.
            frame = Some(renderer.mainredraw(client));
            slot.raster_ns = slot.raster_ns.wrapping_add(t_r.elapsed().as_nanos() as u64);
            slot.paint_n = slot.paint_n.wrapping_add(1);
        } else {
            slot.skip_n = slot.skip_n.wrapping_add(1);
        }
        if let Some(prof) = slot.render_prof.as_mut() {
            let present = slot.renderer.is_some();
            let kind = slot.renderer.as_ref().map(|r| r.backend_kind());
            let prefer = slot.renderer_prefer_cpu;
            prof.record(render_profile::FrameObs {
                now: t_loop,
                painted: paint,
                renderer_present: present,
                backend: render_profile::classify_backend(present, prefer, kind),
                prefer_cpu: prefer,
                ingame: client.ingame,
                scene_state: client.scene_state,
                draw: client.draw,
                full_rate,
            });
        }
        slot.log_n = slot.log_n.wrapping_add(1);
        let result = slot.after_drain(client);
        // Responsiveness: PLAYER_INFO edge is the decoded update that drives
        // script tick. Stamp here; host-play pairs on the next observe dispatch.
        if result.player_info {
            if let Some(resp) = slot.resp_prof.as_mut() {
                resp.note_decode_edge(Instant::now());
            }
        }
        // Random-event guardian (spec pump placement): the snapshot is
        // fresh after the drain. Sync the live toggle from the shared
        // atomic (panel/TUI may flip it mid-session) onto the cloned
        // `ProfileSettings` the guardian reads; the returned
        // `RandomStatus` rides the pump back into the next observe.
        slot.settings.random_events = slot.random_events.load(Ordering::Relaxed);
        slot.settings.lamp_auto = slot.lamp_auto.load(Ordering::Relaxed);
        if let Ok(skill) = slot.lamp_skill.lock() {
            slot.settings.lamp_skill = skill.clone();
        }
        let now_ms = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis() as u64)
            .unwrap_or(0);
        let status = slot
            .guardian
            .tick(client, &slot.snapshot, &slot.settings, now_ms, knock);
        if should_emit_tick(result.player_info) {
            slot.tick_n = slot.tick_n.wrapping_add(1);
        }
        if debug_enabled() {
            let frame_us = t_loop.elapsed().as_micros() as u64;
            if let Some(us) = debug_hitch_us(frame_us) {
                eprintln!(
                    "[host] hitch {username}: frame_us={us} paints={} skips={} ticks={}",
                    slot.paint_n, slot.skip_n, slot.tick_n
                );
            }
            if slot.log_n.is_multiple_of(DEBUG_SUMMARY_EVERY) {
                let now = DebugSnap {
                    loop_ns: slot.loop_ns,
                    raster_ns: slot.raster_ns,
                    observe_ns: slot.observe_ns,
                    paint_n: slot.paint_n,
                    skip_n: slot.skip_n,
                    tick_n: slot.tick_n,
                };
                let (d_loop, d_raster, d_observe, d_paint, d_skip, d_tick) =
                    debug_window_delta(slot.dbg, now);
                let window_ms = slot.dbg_at.map(|t| t.elapsed().as_millis()).unwrap_or(0);
                let max_observe_us = slot.observe_max_ns / 1000;
                eprintln!(
                    "[host] slot {username}: d_loop_us={d_loop} d_raster_us={d_raster} d_observe_us={d_observe} max_observe_us={max_observe_us} d_paints={d_paint} d_skips={d_skip} d_ticks={d_tick} window_ms={window_ms}"
                );
                slot.dbg = now;
                slot.dbg_at = Some(Instant::now());
                slot.observe_max_ns = 0;
            }
        }
        // The whole `FrameOutput` lands in the mailbox, not just the
        // packed pixels: the panel takes the `FrameOutput::Texture` (GPU
        // backend) or packs the `PixMap` (CPU backend) at its consume
        // site, and `FrameBuf::snapshot` keeps the CPU packing path for
        // the tests.
        //
        // GPU completion (opt-in): register `on_submitted_work_done` for a
        // Texture frame *before* mailbox ownership moves, so the callback
        // tracks the submit that produced this handle. No wait/readback;
        // delivery rides later existing submit/poll calls.
        if let Some(frame) = frame {
            if let Some(prof) = slot.render_prof.as_mut() {
                let sample_at = redraw_started_at.unwrap_or_else(std::time::Instant::now);
                match &frame {
                    FrameOutput::Texture(handle) => {
                        prof.observe_painted_output(true, sample_at, |cb| {
                            handle.queue.on_submitted_work_done(cb);
                        });
                    }
                    FrameOutput::PixMap(_) => {
                        prof.observe_painted_output(false, sample_at, |_| {});
                    }
                }
            }
            if let Some(mailbox) = mailbox {
                mailbox.store(frame);
                // Panel input→present: bind any still-unbound focused starts
                // (`require_gen==0`) to this mailbox generation on every store
                // after drain/mainloop — not only when actionable input drained
                // this frame — so a start on a skipped-paint tick still binds
                // on a later store. No-op when nothing is unbound.
                if let Some(resp) = slot.resp_prof.as_ref() {
                    responsiveness_profile::bind_input_to_mailbox_gen(
                        resp.slot_id(),
                        mailbox.generation(),
                    );
                }
            }
        }
        *run_sends = slot.run_sends;
        status
    }
}

/// Frame-loop cadence: a slot that captures input, is still loading (TV
/// static re-rolls every 20 ms), or runs full-rate (the panel's sidecar-50
/// pref, or the TV full-rate latch) keeps the fixed 20 ms loop — that loop
fn slot_want_cpu(input: Option<&SlotInput>) -> bool {
    let from_slot = input.map(|i| i.prefer_cpu()).unwrap_or(false);
    let from_env = std::env::var("BOT_CPU").map(|v| v == "1").unwrap_or(false);
    from_slot || from_env
}

/// Whether this slot's 20 ms loop is the **input** cadence (`SlotInput`
/// but not capture/full-rate is **watch-only 1 fps**: the picture only
/// refreshes once a second, so the slot parks on the 1 s wall-clock bound
/// instead of holding the 20 ms sim loop for a 1 fps sidecar. `busy`
/// (script/cheat/nav work from the observe hook) also keeps a slot on the
/// frame loop.
fn frame_cadence(client: &Client, input: Option<&SlotInput>) -> bool {
    input.map(|i| i.enabled()).unwrap_or(false)
        || (client.draw
            && (input.map(|i| i.full_rate()).unwrap_or(false)
                || (client.ingame && client.scene_state != 2)))
}

/// A watch-only 1 fps sidecar: the renderer is on but nothing needs the
/// 20 ms loop (no capture, no full-rate, not still loading) — it parks on
/// the 1 s wall-clock repaint bound.
fn watch_only(client: &Client, input: Option<&SlotInput>) -> bool {
    client.draw && !frame_cadence(client, input)
}

/// Payload bytes the client's stream has consumed; 0 when no stream.
fn stream_bytes(client: &Client) -> u64 {
    client.stream.as_ref().map(|s| s.bytes_in()).unwrap_or(0)
}

/// Re-arm sim flags after dropping a `Renderer`.
///
/// Draw-off: dematerialize overlay meshes (stamps stay) and re-arm
/// overlay + share-light. Backend flip (`draw` stays on): overlay meshes
/// stay on the sim, but loc models died with the head — re-arm share-light
/// and dirty `minimap_level` so the new pixmap is composed.
fn rearm_after_head_drop(client: &mut Client, draw_off_edge: bool, backend_flip: bool) {
    if draw_off_edge {
        client.world.dematerialize_overlay();
    } else if backend_flip {
        client.world.share_light_pending = true;
        client.minimap_level = -1;
    }
}

/// Why a park returned.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum ParkWake {
    /// The client socket became readable (data, EOF, or a socket error).
    Socket,
    /// A control kick landed (focus/draw/stop/spawn).
    Control,
    /// The park timeout (game-tick bound, or the stall bound) elapsed.
    Timeout,
}

/// Block until the client socket is readable, a control wake lands, or
/// `timeout` elapses. The socket is polled only when `poll_socket` — a
/// previous no-consumption wake (EOF or a packet still mid-flight) leaves
/// the socket permanently readable, so re-polling it would busy-spin.
/// No socket and no control channel falls back to sleeping the timeout.
///
/// Unix production body is stack `[pollfd; 2]` + inline `libc::poll` (no
/// heap). Windows counterpart uses fixed `[WSAPOLLFD; 2]` + `WSAPoll`.
#[cfg(unix)]
#[allow(unsafe_code)]
fn park(client: &Client, ctl: Option<&SlotPark>, poll_socket: bool, timeout: Duration) -> ParkWake {
    let mut fds = [libc::pollfd {
        fd: -1,
        events: 0,
        revents: 0,
    }; 2];
    let mut n = 0usize;
    if let Some(ctl) = ctl {
        fds[n] = libc::pollfd {
            fd: ctl.fd(),
            events: libc::POLLIN,
            revents: 0,
        };
        n += 1;
    }
    let socket = if poll_socket {
        client.stream.as_ref().map(|stream| {
            fds[n] = libc::pollfd {
                fd: stream.fd(),
                events: libc::POLLIN,
                revents: 0,
            };
            let idx = n;
            n += 1;
            idx
        })
    } else {
        None
    };
    if n == 0 {
        thread::sleep(timeout);
        return ParkWake::Timeout;
    }
    let ms = i32::try_from(timeout.as_millis()).unwrap_or(i32::MAX);
    let rc = unsafe { libc::poll(fds.as_mut_ptr(), n as libc::nfds_t, ms) };
    if rc > 0 {
        let fired = |i: usize| {
            fds[i].revents & (libc::POLLIN | libc::POLLHUP | libc::POLLERR | libc::POLLNVAL) != 0
        };
        let control_fired = ctl.is_some() && fired(0);
        if control_fired {
            // Consume the kick bytes: an undrained control fd stays
            // readable and would re-fire every park (busy loop).
            ctl.unwrap().drain();
        }
        if let Some(i) = socket {
            if fired(i) {
                return ParkWake::Socket;
            }
        }
        if control_fired {
            return ParkWake::Control;
        }
    }
    ParkWake::Timeout
}

/// Windows park: fixed-size stack `WSAPoll` arrays (max 2 handles), same
/// control-drain / socket-priority / timeout semantics as the Unix body.
#[cfg(windows)]
#[allow(unsafe_code)]
fn park(client: &Client, ctl: Option<&SlotPark>, poll_socket: bool, timeout: Duration) -> ParkWake {
    use windows_sys::Win32::Networking::WinSock::{
        WSAPoll, POLLERR, POLLHUP, POLLIN, POLLNVAL, SOCKET, WSAPOLLFD,
    };
    let mut fds = [WSAPOLLFD {
        fd: SOCKET::MAX,
        events: 0,
        revents: 0,
    }; 2];
    let mut n = 0usize;
    if let Some(ctl) = ctl {
        fds[n] = WSAPOLLFD {
            fd: ctl.raw_socket() as SOCKET,
            events: POLLIN,
            revents: 0,
        };
        n += 1;
    }
    let socket = if poll_socket {
        client.stream.as_ref().map(|stream| {
            fds[n] = WSAPOLLFD {
                fd: stream.raw_socket() as SOCKET,
                events: POLLIN,
                revents: 0,
            };
            let idx = n;
            n += 1;
            idx
        })
    } else {
        None
    };
    if n == 0 {
        thread::sleep(timeout);
        return ParkWake::Timeout;
    }
    let ms = i32::try_from(timeout.as_millis()).unwrap_or(i32::MAX);
    let rc = unsafe { WSAPoll(fds.as_mut_ptr(), n as u32, ms) };
    if rc > 0 {
        let fired = |i: usize| fds[i].revents & (POLLIN | POLLHUP | POLLERR | POLLNVAL) != 0;
        let control_fired = ctl.is_some() && fired(0);
        if control_fired {
            // Consume the kick bytes: an undrained control handle stays
            // readable and would re-fire every park (busy loop).
            ctl.unwrap().drain();
        }
        if let Some(i) = socket {
            if fired(i) {
                return ParkWake::Socket;
            }
        }
        if control_fired {
            return ParkWake::Control;
        }
    }
    ParkWake::Timeout
}

#[cfg(test)]
fn stream_wait_handle(stream: &client::io::ClientStream) -> slot_io::WaitHandle {
    #[cfg(unix)]
    {
        stream.fd()
    }
    #[cfg(windows)]
    {
        stream.raw_socket()
    }
}

/// Watch-only repaint bound: the rail/sidecar picture refreshes once a
/// wall-clock second. Elapsed time, not a tick count — the slot is parked
/// on [`WATCH_PARK_MS`], so ticks (one per wake) are not a clock.
const WATCH_PAINT_MS: Duration = Duration::from_secs(1);

/// rs2b0t rail: watch-only paints on a 1 s **wall-clock** cadence — the
/// slot is parked, so ticks are not a clock; elapsed time since the last
/// paint decides, not a tick count. The first tick after draw rises paints
/// immediately so checking the box is not a cold hitch. Capture (input /
/// TV static / full-rate) paints every tick. Draw off never paints.
fn raster_this_tick(
    draw: bool,
    capture: bool,
    now: Instant,
    last_paint: &mut Option<Instant>,
    was_on: &mut bool,
) -> bool {
    if !draw {
        *was_on = false;
        return false;
    }
    if capture {
        *last_paint = Some(now);
        *was_on = true;
        return true;
    }
    let rising = !*was_on;
    *was_on = true;
    let due = match *last_paint {
        Some(last) => rising || now.duration_since(last) >= WATCH_PAINT_MS,
        None => true, // first watch paint: nothing painted yet
    };
    if due {
        *last_paint = Some(now);
    }
    due
}

/// Per-slot post-drain state: snapshot, auto-run, the full-rate
/// switch, the random-event guardian, and the optional `Renderer` a
/// drawing slot owns.
struct SlotLoop {
    pump: Pump,
    snapshot: GameSnapshot,
    run_on: bool,
    run_sends: u32,
    /// The slot's real `ProfileSettings` (wired once by `run_client` from
    /// the vault profile; the guardian's toggle reads it). `random_events`,
    /// `lamp_auto`, and `lamp_skill` are refreshed each frame from the
    /// live atomics below.
    settings: ProfileSettings,
    /// Live guardian toggle (shared with `SlotArm::random_events`): a
    /// panel/TUI flip reaches the running slot without a respawn.
    random_events: Arc<AtomicBool>,
    /// Live lamp auto-use toggle (shared with `SlotArm::lamp_auto`).
    lamp_auto: Arc<AtomicBool>,
    /// Live lamp skill choice (shared with `SlotArm::lamp_skill`).
    lamp_skill: Arc<Mutex<String>>,
    /// Random-event guardian (act/hold; the trapped-kind hold and the
    /// `on_random` knock live here).
    guardian: Guardian,
    renderer: Option<Renderer>,
    /// The `prefer_cpu` request the attached head was built with, so a
    /// GPU↔CPU flip on a live slot is a drop+reattach, not a restart.
    /// `None` while no head is attached (kept in sync with
    /// [`SlotLoop::renderer`]).
    renderer_prefer_cpu: Option<bool>,
    /// The `config.lowmem` the attached head was built with, so a mem
    /// flip on a live slot (the `Client` flips `set_lowmem`, never a
    /// restart) drops the head until the next paint rebuilds it.
    renderer_lowmem: Option<bool>,
    /// `Instant` of the last paint of any kind; the watch-only 1 fps
    /// decision repaints when this is ≥1 s old.
    raster_last: Option<Instant>,
    raster_was_on: bool,
    /// `client.draw` from the previous frame. The draw-off detach
    /// dematerializes the headed overlay meshes on the falling edge, so a
    /// parked draw-off slot does not re-walk the tile grid every frame.
    draw_was_on: bool,
    loop_ns: u64,
    raster_ns: u64,
    /// Wall time of the observe hook (`script_observe` + snapshot encode).
    observe_ns: u64,
    /// Max single observe in the current `BOT_DEBUG` window.
    observe_max_ns: u64,
    paint_n: u64,
    skip_n: u64,
    /// Game-tick edges (`PLAYER_INFO` this drain). Counted internally;
    /// printed in the 50-frame summary, not per tick.
    tick_n: u64,
    log_n: u32,
    /// Totals at the last `BOT_DEBUG` window line (deltas, not cumulatives).
    dbg: DebugSnap,
    dbg_at: Option<Instant>,
    /// Opt-in renderer residency/paint counters; `None` while profiling off.
    render_prof: Option<render_profile::Local>,
    /// Opt-in decode→script / input latency counters; `None` while off.
    resp_prof: Option<responsiveness_profile::Local>,
}

impl SlotLoop {
    fn new() -> Self {
        Self {
            pump: Pump::new(),
            snapshot: GameSnapshot::new(),
            run_on: false,
            run_sends: 0,
            settings: ProfileSettings::default(),
            random_events: Arc::new(AtomicBool::new(true)),
            lamp_auto: Arc::new(AtomicBool::new(true)),
            lamp_skill: Arc::new(Mutex::new("strength".to_string())),
            guardian: Guardian::new(),
            renderer: None,
            renderer_prefer_cpu: None,
            renderer_lowmem: None,
            raster_last: None,
            raster_was_on: false,
            draw_was_on: false,
            loop_ns: 0,
            raster_ns: 0,
            observe_ns: 0,
            observe_max_ns: 0,
            paint_n: 0,
            skip_n: 0,
            tick_n: 0,
            log_n: 0,
            dbg: DebugSnap::default(),
            dbg_at: None,
            render_prof: None,
            resp_prof: None,
        }
    }

    fn after_drain(&mut self, client: &mut Client) -> DrainResult {
        let result = drain_and_rebuild_snapshot(&mut self.pump, &mut self.snapshot, client);

        // Live client field: UPDATE_RUNENERGY writes here. Snapshot energy
        // can stay 0 if a stat-family rebuild ran before the energy packet.
        let energy = client.runenergy;
        if let Some(echo) = run_echo(client) {
            self.run_on = echo;
        }
        if energy == 0 {
            // Cannot be running; wins over a stale run-on echo.
            self.run_on = false;
        }
        if auto_run_ready(client.ingame, client.scene_state)
            && auto_run_tick(energy, self.run_on)
            && set_run(client, true)
        {
            self.run_on = true;
            self.run_sends += 1;
        }
        result
    }
}

/// Production host snapshot publication used by [`SlotLoop::after_drain`]:
/// drain `Client.gens` through [`Pump`], then rebuild only the dirty families.
/// Exposed so offline frame-equivalence tests can drive the real Host path
/// without cloning the dirty-family map.
pub fn drain_and_rebuild_snapshot(
    pump: &mut Pump,
    snapshot: &mut GameSnapshot,
    client: &Client,
) -> DrainResult {
    let result = pump.drain(client.gens);
    rebuild_dirty(snapshot, client, result.dirty);
    result
}

fn rebuild_dirty(snapshot: &mut GameSnapshot, client: &Client, dirty: DirtyFamilies) {
    if dirty.npc {
        snapshot.rebuild_family(client, Family::Npc);
    }
    if dirty.player {
        snapshot.rebuild_family(client, Family::Player);
    }
    if dirty.inv {
        snapshot.rebuild_family(client, Family::Inv);
    }
    if dirty.varp {
        snapshot.rebuild_family(client, Family::Varp);
    }
    if dirty.stat {
        snapshot.rebuild_family(client, Family::Stat);
    }
    if dirty.chat {
        snapshot.rebuild_family(client, Family::Chat);
    }
    if dirty.scene {
        snapshot.rebuild_family(client, Family::Scene);
        // Loc and ground-item changes bump the scene gen, so the same
        // drain flag rebuilds their views.
        snapshot.rebuild_family(client, Family::Loc);
        snapshot.rebuild_family(client, Family::GroundItem);
    }
    if dirty.iface {
        snapshot.rebuild_family(client, Family::Iface);
    }
    if dirty.camera {
        snapshot.rebuild_family(client, Family::Camera);
    }
    if dirty.map_flag {
        snapshot.rebuild_family(client, Family::MapFlag);
    }
    if dirty.world {
        snapshot.rebuild_family(client, Family::World);
    }
    // The iface-derived families re-read the materialized `client.ifaces`
    // (and the inv slot data), so their gens are the iface and inv flags;
    // each family's own gate no-ops the ones that did not move.
    if dirty.iface || dirty.inv {
        snapshot.rebuild_family(client, Family::Inventory);
        snapshot.rebuild_family(client, Family::Equipment);
        snapshot.rebuild_family(client, Family::Bank);
        snapshot.rebuild_family(client, Family::BankSide);
        snapshot.rebuild_family(client, Family::Trade);
        snapshot.rebuild_family(client, Family::Widgets);
        snapshot.rebuild_family(client, Family::SideTabs);
        snapshot.rebuild_family(client, Family::ChatOptions);
        snapshot.rebuild_family(client, Family::MakeProducts);
        snapshot.rebuild_family(client, Family::QuestStatuses);
        snapshot.rebuild_family(client, Family::Modals);
        snapshot.rebuild_family(client, Family::Controls);
        snapshot.rebuild_family(client, Family::Menu);
    }
}

/// Run on/off from the orb pair. 152 visible and 153 hidden → running;
/// the inverse → walking. Both the same (unpacked defaults) is unknown —
/// a packed jag starts with `hide = false` on every component.
fn run_echo(client: &Client) -> Option<bool> {
    let off = client.if_(152)?;
    let on = client.if_(153)?;
    if off.hide == on.hide {
        return None;
    }
    Some(!off.hide)
}

#[cfg(test)]
mod tests {
    use super::*;
    use api::interact::RUN_ORB_IFACE;
    use client::dash3d::TerrainOverlayShape;
    use client::io::ClientProt;
    use std::sync::OnceLock;
    use std::time::Instant;

    /// Force the wgpu backend's process-wide init to fail so every
    /// renderer this test process constructs lands on `CpuBackend` (the
    /// client's documented `R274_TEST_FORCE_NO_GPU` test hook): the host's
    /// GPU-first default must not open a real device inside
    /// `cargo test -p host`. Once set, the client caches the failure, so
    /// the first renderer construction wins — call before any test
    /// constructs one.
    static FORCE_CPU_BACKEND: OnceLock<()> = OnceLock::new();
    fn force_cpu_backend() {
        FORCE_CPU_BACKEND.get_or_init(|| {
            std::env::set_var("R274_TEST_FORCE_NO_GPU", "1");
            Renderer::set_prefer_gpu(true);
        });
    }

    fn cfg() -> ClientConfig {
        ClientConfig {
            host: "127.0.0.1".into(),
            port: 43594,
            cache_dir: "/tmp".into(),
            members: true,
            lowmem: true,
        }
    }

    #[test]
    fn prepare_client_shares_arc_and_clears_error_loading() {
        let cache = Arc::new(Cache::default());
        let a = prepare_client(cfg(), 1, Arc::clone(&cache), Arc::new(vec![]), Vec::new());
        let b = prepare_client(cfg(), 2, Arc::clone(&cache), Arc::new(vec![]), Vec::new());
        assert!(Arc::ptr_eq(&a.cache, &b.cache));
        assert!(Arc::ptr_eq(&a.cache, &cache));
        assert!(!a.error_loading);
        assert!(!b.error_loading);
        assert_eq!(a.login_uid, 1);
        assert_eq!(b.login_uid, 2);
    }

    #[test]
    fn slot_rebuilds_from_drain_dirty_not_post_drain_pump_dirty() {
        let mut client = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();
        client.gens.npc = 1;
        let result = slot.after_drain(&mut client);
        assert!(result.dirty.npc);
        assert_eq!(slot.snapshot.gens().npc, 1);
        assert_eq!(slot.pump.dirty(client.gens), DirtyFamilies::default());
    }

    /// The drain's dirty flags must feed `rebuild_dirty` for the four new
    /// families too, or `snapshot.gens().{iface,camera,map_flag,world}`
    /// stay permanently 0 (the snapshot views rely on this path).
    #[test]
    fn drain_rebuilds_the_four_new_families() {
        let mut client = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();

        client.gens.iface = 1;
        let result = slot.after_drain(&mut client);
        assert!(result.dirty.iface);
        assert_eq!(
            slot.snapshot.gens().iface,
            1,
            "drain must rebuild the iface family"
        );

        client.gens.camera = 1;
        let result = slot.after_drain(&mut client);
        assert!(result.dirty.camera);
        assert_eq!(
            slot.snapshot.gens().camera,
            1,
            "drain must rebuild the camera family"
        );

        client.gens.map_flag = 1;
        let result = slot.after_drain(&mut client);
        assert!(result.dirty.map_flag);
        assert_eq!(
            slot.snapshot.gens().map_flag,
            1,
            "drain must rebuild the map_flag family"
        );

        client.gens.world = 1;
        let result = slot.after_drain(&mut client);
        assert!(result.dirty.world);
        assert_eq!(
            slot.snapshot.gens().world,
            1,
            "drain must rebuild the world family"
        );
    }

    /// The drain's iface/inv flags must rebuild the iface-derived
    /// snapshot families too, or the host path (as opposed to the scenario
    /// runner's `GameSnapshot::rebuild`) would keep their views
    /// permanently empty.
    #[test]
    fn drain_rebuilds_the_iface_derived_families() {
        use client::config::if_type::ComponentType;

        let mut ifaces = vec![None; 1000];
        ifaces[500] = Some(Box::new(IfType {
            id: 500,
            r#type: ComponentType::TYPE_INV,
            obj_ops: true,
            ..IfType::default()
        }));
        let mut ifaces_mut = vec![None; 1000];
        ifaces_mut[500] = Some(Arc::new(IfTypeMut {
            link_obj_type: Some(vec![4, 5, 0]),
            link_obj_number: Some(vec![1, 100, 0]),
            ..IfTypeMut::default()
        }));
        let mut client = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(ifaces),
            ifaces_mut,
        );
        client.side_icon[3] = 500;
        let mut slot = SlotLoop::new();

        client.gens.iface = 1;
        client.gens.inv = 1;
        let result = slot.after_drain(&mut client);
        assert!(result.dirty.iface);
        assert!(result.dirty.inv);
        assert_eq!(
            slot.snapshot.inventory().len(),
            2,
            "an iface/inv drain must rebuild the inventory family"
        );
        assert_eq!(slot.snapshot.inventory_size(), 3);

        // A quiet drain leaves the snapshot gens alone: unchanged gens do not
        // re-mark anything dirty.
        let result = slot.after_drain(&mut client);
        assert!(!result.dirty.any());
    }

    fn ingame_scene2(client: &mut Client) {
        client.ingame = true;
        client.scene_state = 2;
    }

    #[test]
    fn auto_run_does_not_send_on_the_title() {
        let mut client = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();
        client.runenergy = 100;
        client.gens.stat = 1;
        slot.after_drain(&mut client);
        assert_eq!(
            slot.run_sends, 0,
            "title IF_BUTTON is ignored; sending here sticks run_on"
        );
        assert!(!slot.run_on);

        ingame_scene2(&mut client);
        slot.after_drain(&mut client);
        assert_eq!(slot.run_sends, 1);
        assert!(slot.run_on);
    }

    #[test]
    fn auto_run_20_0_20_sends_twice() {
        let mut client = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();
        ingame_scene2(&mut client);
        client.runenergy = 20;
        client.gens.stat = 1;
        slot.after_drain(&mut client);
        assert_eq!(slot.run_sends, 1);
        assert_eq!(client.out.data()[0], ClientProt::IF_BUTTON.id as u8);
        let iface = u16::from_be_bytes([client.out.data()[1], client.out.data()[2]]);
        assert_eq!(iface, RUN_ORB_IFACE as u16);

        client.out.pos = 0;
        client.runenergy = 0;
        client.gens.stat = 2;
        slot.after_drain(&mut client);
        assert!(!slot.run_on);
        assert_eq!(slot.run_sends, 1);

        client.runenergy = 20;
        client.gens.stat = 3;
        slot.after_drain(&mut client);
        assert_eq!(slot.run_sends, 2);
        assert!(slot.run_on);
    }

    #[test]
    fn already_running_echo_does_not_send() {
        let mut ifaces = vec![None; 154];
        ifaces[152] = Some(Box::new(IfType::default()));
        ifaces[153] = Some(Box::new(IfType::default()));
        let mut ifaces_mut = vec![None; 154];
        ifaces_mut[152] = Some(Arc::new(IfTypeMut {
            hide: false,
            ..IfTypeMut::default()
        }));
        ifaces_mut[153] = Some(Arc::new(IfTypeMut {
            hide: true,
            ..IfTypeMut::default()
        }));
        let mut client = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(ifaces),
            ifaces_mut,
        );
        client.runenergy = 20;
        client.gens.stat = 1;
        ingame_scene2(&mut client);
        let mut slot = SlotLoop::new();
        slot.after_drain(&mut client);
        assert_eq!(slot.run_sends, 0, "already on → no extra send");
        assert!(slot.run_on);
    }

    #[test]
    fn unpacked_ifaces_both_visible_still_sends() {
        let mut ifaces = vec![None; 154];
        ifaces[152] = Some(Box::new(IfType::default()));
        ifaces[153] = Some(Box::new(IfType::default()));
        let mut client = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(ifaces),
            Vec::new(),
        );
        client.runenergy = 20;
        client.gens.stat = 1;
        ingame_scene2(&mut client);
        let mut slot = SlotLoop::new();
        slot.after_drain(&mut client);
        assert_eq!(slot.run_sends, 1);
    }

    #[test]
    fn client_frame_applies_click_only_when_input_enabled() {
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let inp = SlotInput::new();
        let (tx, rx) = std::sync::mpsc::channel();
        inp.connect_rx(rx);
        tx.send(InputEv::Down {
            button: 1,
            x: 20,
            y: 20,
        })
        .unwrap();
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        inp.set_enabled(false);
        Host::client_frame(&mut c, &mut slot, "t", Some(&inp), None, &mut sends, None);
        assert_eq!(c.shell.mouse_click_button, 0);
        inp.set_enabled(true);
        Host::client_frame(&mut c, &mut slot, "t", Some(&inp), None, &mut sends, None);
        assert_eq!(c.shell.mouse_click_button, 1);
    }

    #[test]
    fn client_frame_skips_frame_store_when_draw_off() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let buf = FrameBuf::new();
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        // Renderer off: no frame is rendered and nothing is stored.
        c.set_draw(false);
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert!(buf.snapshot().is_empty(), "draw off must not store pixels");
        // Renderer on: the first (rising-edge) tick paints a full applet
        // into the buffer (with no title assets in this test the paint is
        // empty, but the frame still packs a full applet; the non-zero
        // paint is proven live by the panel_view e2e).
        c.set_draw(true);
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert_eq!(
            buf.snapshot().len(),
            (client::client::APPLET_W * client::client::APPLET_H) as usize
        );
    }

    #[test]
    fn headless_slot_constructs_no_renderer_and_never_draws() {
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        // `client.draw` defaults false: a headless slot never paints. The
        // check is slot-local (not the global `Renderer::constructed()`
        // counter, which other tests' renderers bump concurrently).
        for _ in 0..3 {
            Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        }
        assert!(
            slot.renderer.is_none(),
            "draw off must not construct a Renderer"
        );
        assert_eq!(slot.skip_n, 3);
        assert_eq!(slot.paint_n, 0);
        assert!(slot.loop_ns > 0, "mainloop still ran");
    }

    #[test]
    fn draw_off_drops_renderer_draw_on_reattaches() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert!(slot.renderer.is_some());
        let loop_after_on = slot.loop_ns;
        c.set_draw(false);
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert!(slot.renderer.is_none(), "unheaded must drop headed data");
        assert!(slot.loop_ns > loop_after_on, "sim still ticks");
        c.set_draw(true);
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert!(slot.renderer.is_some(), "attach at any time");
    }

    #[test]
    fn render_profile_observes_attach_detach_and_cpu_backend() {
        force_cpu_backend();
        render_profile::enable();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();
        slot.render_prof = render_profile::Local::new(render_profile::slot_id_for("profile-t"));
        let gen = slot.render_prof.as_ref().unwrap().generation();
        let mut sends = 0u32;
        c.set_draw(true);
        Host::client_frame(&mut c, &mut slot, "profile-t", None, None, &mut sends, None);
        assert!(slot.renderer.is_some());
        c.set_draw(false);
        Host::client_frame(&mut c, &mut slot, "profile-t", None, None, &mut sends, None);
        assert!(slot.renderer.is_none());
        // Drop publishes ended=true into the registry.
        drop(slot);
        let snap = render_profile::read().expect("enabled");
        let row = snap
            .iter()
            .find(|s| s.generation == gen)
            .expect("slot observation");
        assert!(row.ended);
        assert!(row.paint_n >= 1);
        assert!(row.skip_n >= 1);
        assert!(row.attach_n >= 1);
        assert!(row.detach_n >= 1);
        assert_eq!(row.backend, render_profile::BackendObs::Absent);
        // Prefer-cpu false + force-no-gpu lands CpuFallback when attached;
        // after detach backend is Absent. paint path under force_cpu uses Cpu.
        assert!(row.client_loop_n >= 2);
    }

    /// Draw-off (only-render-selected, 49 heads dropping) must drain the
    /// mailbox so a `FrameOutput::Texture` cannot outlive `frame_texture`.
    #[test]
    fn draw_off_drains_the_frame_mailbox_before_dropping_the_head() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let buf = FrameBuf::new();
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert!(buf.take().is_some(), "a paint tick stores a frame");
        c.set_draw(true);
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert!(slot.renderer.is_some());
        c.set_draw(false);
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert!(slot.renderer.is_none());
        assert!(
            buf.take().is_none(),
            "draw-off must take the mailbox before dropping the renderer"
        );
    }

    /// Final-review fix: a draw-off detach must dematerialize the headed
    /// overlay meshes (`Square.ground`/`quick_ground`) from the sim — keep
    /// the compact `overlay_stamp` typecodes and re-arm the attach
    /// materialize — so an unheaded slot never holds headed data, and the
    /// next attach restores the mesh without a rebuild.
    #[test]
    fn draw_off_dematerializes_overlay_draw_on_restores_mesh() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        // A headed overlay mesh, planted on the sim directly (no full
        // map_build needed to exercise the hook).
        c.world.fill_base_level(0);
        c.set_draw(true);
        c.world.set_ground(
            0,
            2,
            2,
            TerrainOverlayShape::TRAPEZIUM,
            1,
            7,
            1000,
            1004,
            1010,
            1006,
            0x111111,
            0x222222,
            0x333333,
            0x444444,
            0x555555,
            0x666666,
            0x777777,
            0x888888,
            0x99,
            0xaa,
        );
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert!(
            c.world
                .square(0, 2, 2)
                .and_then(|s| s.ground.as_ref())
                .is_some(),
            "headed draw must build the overlay mesh"
        );

        // Draw off drops the head and the headed mesh; the stamp survives
        // and the next attach is re-armed.
        c.set_draw(false);
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert!(slot.renderer.is_none());
        let sq = c.world.square(0, 2, 2).expect("stamped tile");
        assert!(sq.ground.is_none(), "draw off must drop the overlay mesh");
        assert!(sq.quick_ground.is_none());
        assert!(
            sq.overlay_stamp.is_some(),
            "the stamp must survive a detach"
        );
        assert!(
            c.world.overlay_pending,
            "a detach must re-arm the attach materialize"
        );
        assert!(
            c.world.share_light_pending,
            "a detach must re-arm share_light: loc models died with the head"
        );
        assert_eq!(
            c.minimap_level, -1,
            "a detach must dirty the minimap so the next head recomposes it"
        );

        // Draw on: the reattached head's first paint consumes the pending
        // flag and restores the mesh from the stamp — no map_build.
        c.ingame = true;
        c.scene_state = 2;
        c.set_draw(true);
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert!(slot.renderer.is_some());
        assert!(
            c.world
                .square(0, 2, 2)
                .and_then(|s| s.ground.as_ref())
                .is_some(),
            "attach must rematerialize the overlay mesh"
        );
        assert!(
            !c.world.overlay_pending,
            "the first paint must consume the attach materialize"
        );
    }

    #[test]
    fn backend_flip_rearms_share_light_without_dropping_overlay() {
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        c.world.share_light_pending = false;
        c.world.overlay_pending = false;
        c.minimap_level = 0;
        rearm_after_head_drop(&mut c, false, true);
        assert!(
            c.world.share_light_pending,
            "GPU↔CPU / mem flip must re-arm share_light; loc models died with the head"
        );
        assert!(
            !c.world.overlay_pending,
            "a backend flip must not dematerialize overlay meshes still on the sim"
        );
        assert_eq!(c.minimap_level, -1);
    }

    #[test]
    fn prefer_cpu_rebuilds_renderer_not_client() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let inp = SlotInput::new();
        inp.set_prefer_cpu(false);
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        Host::client_frame(&mut c, &mut slot, "t", Some(&inp), None, &mut sends, None);
        let uid = c.login_uid;
        inp.set_prefer_cpu(true);
        Host::client_frame(&mut c, &mut slot, "t", Some(&inp), None, &mut sends, None);
        assert_eq!(c.login_uid, uid);
        assert!(slot.renderer.is_some());
        // Under `force_cpu_backend` both preferences land on
        // `BackendKind::Cpu`, so the kind alone cannot prove a rebuild:
        // the head must carry the *new* `prefer_cpu` request, and the flip
        // tick must have repainted with it.
        assert_eq!(
            slot.renderer_prefer_cpu,
            Some(true),
            "the flip must rebuild the head for the new prefer_cpu"
        );
        assert_eq!(slot.paint_n, 2, "the flip tick must repaint the new head");
        assert_eq!(
            slot.renderer.as_ref().unwrap().backend_kind(),
            client::render::backend::BackendKind::Cpu
        );
    }

    #[test]
    fn bot_cpu_env_forces_cpu_even_when_slot_input_prefers_gpu() {
        force_cpu_backend();
        let prev = std::env::var("BOT_CPU").ok();
        std::env::set_var("BOT_CPU", "1");
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let inp = SlotInput::new();
        inp.set_prefer_cpu(false);
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        Host::client_frame(&mut c, &mut slot, "t", Some(&inp), None, &mut sends, None);
        match prev {
            Some(v) => std::env::set_var("BOT_CPU", v),
            None => std::env::remove_var("BOT_CPU"),
        }
        assert_eq!(
            slot.renderer_prefer_cpu,
            Some(true),
            "BOT_CPU=1 must force CpuPix3D even when SlotInput.prefer_cpu is false"
        );
    }

    #[test]
    fn lowmem_flip_rebuilds_renderer_not_client() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        assert!(c.config.lowmem, "cfg() spawns lowmem");
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert_eq!(slot.renderer_lowmem, Some(true));
        let uid = c.login_uid;
        c.set_lowmem(false);
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert_eq!(c.login_uid, uid);
        assert!(slot.renderer.is_some());
        assert_eq!(
            slot.renderer_lowmem,
            Some(false),
            "a mem flip must drop the head so the next paint reads the new config.lowmem"
        );
    }

    #[test]
    fn client_frame_keeps_loop_counters_slot_local() {
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(false);
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert_eq!(slot.skip_n, 1);
        assert_eq!(slot.paint_n, 0);
        assert!(slot.loop_ns > 0);
    }

    #[test]
    fn client_frame_draw_on_paints_this_tick() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert_eq!(slot.paint_n, 1);
        assert_eq!(slot.skip_n, 0);
    }

    #[test]
    fn mainredraw_runs_check_minimap_on_a_paint_tick() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let buf = FrameBuf::new();
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        c.ingame = true;
        c.scene_state = 2;
        // A fresh client starts with `minimap_level = -1` (reset by login)
        // while `minusedlevel` is 0. Only `Renderer::mainredraw`'s
        // `check_minimap` render half brings `minimap_level` up to
        // `minusedlevel`; the raw `game_draw` stage does not, so this
        // pins the render dispatch to `mainredraw`.
        assert_eq!(c.minimap_level, -1);
        assert_ne!(c.minimap_level, c.minusedlevel);
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert_eq!(
            c.minimap_level, c.minusedlevel,
            "mainredraw must run the check_minimap render half"
        );
        assert_eq!(slot.paint_n, 1);
        assert_eq!(
            buf.snapshot().len(),
            (client::client::APPLET_W * client::client::APPLET_H) as usize
        );
    }

    #[test]
    fn client_tick_observe_runs_before_the_frame_paint() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let buf = FrameBuf::new();
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        assert!(!c.draw, "slots start with the renderer off");
        // A drawing slot paints this tick; an observe-after-frame would
        // skip it, so observe-before must run first.
        c.set_draw(true);
        let observed = AtomicBool::new(false);
        Host::client_tick(
            &mut c,
            &mut slot,
            "t",
            None,
            Some(&buf),
            &mut sends,
            &mut |_, _, _, _| {
                observed.store(true, Ordering::Relaxed);
                false
            },
            None,
            &RandomStatus::default(),
        );
        assert!(observed.load(Ordering::Relaxed));
        assert_eq!(
            buf.snapshot().len(),
            (client::client::APPLET_W * client::client::APPLET_H) as usize
        );
        let gen = buf.generation();
        c.set_draw(false);
        Host::client_tick(
            &mut c,
            &mut slot,
            "t",
            None,
            Some(&buf),
            &mut sends,
            &mut |_, _, _, _| false,
            None,
            &RandomStatus::default(),
        );
        assert!(!c.draw);
        assert_eq!(
            buf.generation(),
            gen,
            "renderer off must not store a frame this tick"
        );
    }

    #[test]
    fn debug_window_delta_is_since_last_summary_not_lifetime() {
        let prev = DebugSnap {
            loop_ns: 1_000_000,
            raster_ns: 2_000_000,
            observe_ns: 100_000,
            paint_n: 50,
            skip_n: 10,
            tick_n: 3,
        };
        let now = DebugSnap {
            loop_ns: 1_500_000,
            raster_ns: 2_400_000,
            observe_ns: 400_000,
            paint_n: 100,
            skip_n: 10,
            tick_n: 5,
        };
        assert_eq!(
            debug_window_delta(prev, now),
            (500, 400, 300, 50, 0, 2),
            "summary must be a window, not cumulative totals"
        );
    }

    #[test]
    fn debug_hitch_is_one_frame_over_50ms_not_every_tick() {
        assert_eq!(debug_hitch_us(20_000), None);
        assert_eq!(debug_hitch_us(49_999), None);
        assert_eq!(debug_hitch_us(50_000), Some(50_000));
        assert_eq!(debug_hitch_us(120_000), Some(120_000));
    }

    #[test]
    fn debug_observe_hitch_is_one_missed_frame_not_every_tick() {
        assert_eq!(debug_observe_hitch_us(15_999), None);
        assert_eq!(debug_observe_hitch_us(16_000), Some(16_000));
        assert_eq!(debug_observe_hitch_us(40_000), Some(40_000));
    }

    #[test]
    fn raster_this_tick_watch_is_wall_clock_one_fps_capture_is_every_tick() {
        let t0 = Instant::now();
        let mut last = None;
        let mut on = false;
        assert!(!raster_this_tick(false, false, t0, &mut last, &mut on));
        assert!(
            raster_this_tick(true, false, t0, &mut last, &mut on),
            "rising edge paints now"
        );
        // Sub-second wakes (the parked slot's cadence) stay quiet…
        assert!(!raster_this_tick(
            true,
            false,
            t0 + Duration::from_millis(500),
            &mut last,
            &mut on
        ));
        // …and the paint lands once a wall-clock second elapses.
        assert!(raster_this_tick(
            true,
            false,
            t0 + Duration::from_secs(1),
            &mut last,
            &mut on
        ));
        assert!(!raster_this_tick(
            true,
            false,
            t0 + Duration::from_secs(1) + Duration::from_millis(100),
            &mut last,
            &mut on
        ));
        // Capture paints every tick (minimenu / TV static / full-rate).
        assert!(raster_this_tick(
            true,
            true,
            t0 + Duration::from_secs(1),
            &mut last,
            &mut on
        ));
        assert!(raster_this_tick(
            true,
            true,
            t0 + Duration::from_secs(1),
            &mut last,
            &mut on
        ));
        on = false;
        assert!(
            raster_this_tick(true, false, t0 + Duration::from_secs(1), &mut last, &mut on),
            "draw rising after off paints immediately"
        );
    }

    #[test]
    fn watch_only_paints_first_tick_then_once_per_second() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let buf = FrameBuf::new();
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        c.ingame = true;
        c.scene_state = 2;
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert_eq!(buf.generation(), 1);
        // A fast second tick (the parked slot draining a burst) must not
        // repaint before a wall-clock second elapses.
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert_eq!(buf.generation(), 1);
        thread::sleep(Duration::from_secs(1) + Duration::from_millis(50));
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert_eq!(buf.generation(), 2, "watch-only repaints after 1 s");
    }

    #[test]
    fn full_rate_paints_every_tick_after_scene_ready() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let buf = FrameBuf::new();
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        // The sidecar-50 pref drives the frame cadence through the shared
        // SlotInput, not a slot-local field.
        let inp = SlotInput::new();
        inp.set_full_rate(true);
        c.ingame = true;
        c.scene_state = 2;
        Host::client_frame(
            &mut c,
            &mut slot,
            "t",
            Some(&inp),
            Some(&buf),
            &mut sends,
            None,
        );
        assert_eq!(buf.generation(), 1);
        Host::client_frame(
            &mut c,
            &mut slot,
            "t",
            Some(&inp),
            Some(&buf),
            &mut sends,
            None,
        );
        assert_eq!(
            buf.generation(),
            2,
            "TV full_rate must redraw 2D+3D every 20 ms, not 1 fps watch"
        );
        // Clearing the latch drops back to the 1 fps watch cadence.
        inp.set_full_rate(false);
        Host::client_frame(
            &mut c,
            &mut slot,
            "t",
            Some(&inp),
            Some(&buf),
            &mut sends,
            None,
        );
        assert_eq!(
            buf.generation(),
            2,
            "full_rate off must not paint sub-second"
        );
    }

    #[test]
    fn loading_scene_paints_every_tick_for_tv_static() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let buf = FrameBuf::new();
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        c.ingame = true;
        c.scene_state = 1;
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert_eq!(buf.generation(), 1);
        Host::client_frame(&mut c, &mut slot, "t", None, Some(&buf), &mut sends, None);
        assert_eq!(
            buf.generation(),
            2,
            "scene_state != 2 must re-roll static every 20 ms"
        );
    }

    #[test]
    fn capture_draw_copies_every_tick() {
        force_cpu_backend();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let buf = FrameBuf::new();
        let inp = SlotInput::new();
        inp.set_full_rate(true);
        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        c.set_draw(true);
        Host::client_frame(
            &mut c,
            &mut slot,
            "t",
            Some(&inp),
            Some(&buf),
            &mut sends,
            None,
        );
        Host::client_frame(
            &mut c,
            &mut slot,
            "t",
            Some(&inp),
            Some(&buf),
            &mut sends,
            None,
        );
        assert_eq!(buf.generation(), 2);
    }

    /// Observe mirror: the shared handle the slot thread's observe hook
    /// updates, so a `run_client` thread is observable without owning the
    /// client. `(loop_cycle, reboot_timer)` for packet tests.
    type Seen = std::sync::Arc<std::sync::Mutex<(i32, i32)>>;

    fn seen() -> (Seen, Seen) {
        let s = std::sync::Arc::new(std::sync::Mutex::new((0, 0)));
        (std::sync::Arc::clone(&s), s)
    }

    // `Client` is !Send (its `present` target is a `Box<dyn PresentTarget>`),
    // so like host-play's slot threads the tests build the client *inside*
    // the spawned closure and only move Send handles across the boundary.

    #[test]
    fn idle_slot_parks_between_packets_and_wakes_on_one() {
        use std::io::Write;
        use std::net::TcpListener;
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();
        let (wake, park) = crate::slot_io::wake_channel();
        let (mirror, seen) = seen();
        let stop = Arc::new(AtomicBool::new(false));
        let stop2 = Arc::clone(&stop);
        let (done_tx, done_rx) = std::sync::mpsc::channel();
        let handle = thread::spawn(move || {
            let mut c = prepare_client(
                cfg(),
                1,
                Arc::new(Cache::default()),
                Arc::new(vec![]),
                Vec::new(),
            );
            let stream =
                client::io::ClientStream::connect(&addr.ip().to_string(), addr.port()).unwrap();
            c.stream = Some(stream);
            c.ingame = true;
            // The login handshake leaves the packet decoder mid-frame
            // (`ptype == -1` → read the next header byte); without it a
            // fresh client misreads the first socket byte as a header.
            c.ptype = -1;
            Host::run_client(
                &mut c,
                "idle",
                ProfileSettings::default(),
                Arc::new(AtomicBool::new(true)),
                Arc::new(AtomicBool::new(true)),
                Arc::new(Mutex::new("strength".to_string())),
                None,
                None,
                Some(Arc::new(park)),
                #[cfg(feature = "snapshot-dedup")]
                None,
                |c, _, _, _| {
                    let mut v = mirror.lock().unwrap();
                    v.0 = c.loop_cycle;
                    v.1 = c.reboot_timer;
                    false
                },
                |_| stop2.load(Ordering::Relaxed),
                |_| RandomClaim::Host,
            );
            done_tx.send(()).unwrap();
        });
        let (mut server, _) = listener.accept().unwrap();

        // First park happens after the opening tick; a quiet window must
        // not advance mainloop at all (no packet, no control, no timer yet).
        thread::sleep(Duration::from_millis(120));
        let before = *seen.lock().unwrap();
        thread::sleep(Duration::from_millis(120));
        let after = *seen.lock().unwrap();
        assert_eq!(
            after, before,
            "idle slot must not call mainloop between packet arrivals"
        );

        // A server packet (UPDATE_REBOOT_TIMER, two payload bytes) must
        // wake the park and apply within a frame.
        server.write_all(&[89, 0, 10]).unwrap();
        let deadline = Instant::now() + Duration::from_secs(2);
        loop {
            let (_, reboot) = *seen.lock().unwrap();
            if reboot > 0 {
                break;
            }
            assert!(Instant::now() < deadline, "packet never applied");
            thread::sleep(Duration::from_millis(5));
        }

        stop.store(true, Ordering::Relaxed);
        wake.wake();
        done_rx
            .recv_timeout(Duration::from_secs(1))
            .expect("stop control must return a parked slot");
        handle.join().unwrap();
    }

    #[test]
    fn focused_slot_keeps_the_twenty_ms_cadence() {
        force_cpu_backend();
        let (mirror, seen) = seen();
        let stop = Arc::new(AtomicBool::new(false));
        let stop2 = Arc::clone(&stop);
        let inp = SlotInput::new();
        inp.set_enabled(true);
        let handle = thread::spawn(move || {
            let mut c = prepare_client(
                cfg(),
                1,
                Arc::new(Cache::default()),
                Arc::new(vec![]),
                Vec::new(),
            );
            c.set_draw(true);
            Host::run_client(
                &mut c,
                "focused",
                ProfileSettings::default(),
                Arc::new(AtomicBool::new(true)),
                Arc::new(AtomicBool::new(true)),
                Arc::new(Mutex::new("strength".to_string())),
                Some(inp),
                None,
                None,
                #[cfg(feature = "snapshot-dedup")]
                None,
                |c, _, _, _| {
                    mirror.lock().unwrap().0 = c.loop_cycle;
                    false
                },
                |_| stop2.load(Ordering::Relaxed),
                |_| RandomClaim::Host,
            );
        });
        // Gate on the count, not a fixed sleep: a parked slot (600 ms
        // timeout, no socket/control) manages ≤8 ticks in 5 s, so reaching
        // 12 proves the frame loop is running no matter how contended the
        // test machine is.
        let deadline = Instant::now() + Duration::from_secs(5);
        loop {
            let cycles = seen.lock().unwrap().0;
            if cycles >= 12 {
                break;
            }
            assert!(
                Instant::now() < deadline,
                "focused slot never entered the frame loop, {cycles} ticks in 5 s"
            );
            thread::sleep(Duration::from_millis(10));
        }
        // Then the rate: the 20 ms cadence yields dozens per 300 ms; a
        // parked slot would yield ≤1.
        let t1 = seen.lock().unwrap().0;
        thread::sleep(Duration::from_millis(300));
        let t2 = seen.lock().unwrap().0;
        assert!(
            t2 >= t1 + 3,
            "focused slot must tick at ~20 ms, {t1} -> {t2} over 300 ms"
        );
        stop.store(true, Ordering::Relaxed);
        handle.join().unwrap();
    }

    #[test]
    fn busy_observe_keeps_the_slot_on_the_frame_loop() {
        let (mirror, seen) = seen();
        let stop = Arc::new(AtomicBool::new(false));
        let stop2 = Arc::clone(&stop);
        let handle = thread::spawn(move || {
            let mut c = prepare_client(
                cfg(),
                1,
                Arc::new(Cache::default()),
                Arc::new(vec![]),
                Vec::new(),
            );
            Host::run_client(
                &mut c,
                "scripted",
                ProfileSettings::default(),
                Arc::new(AtomicBool::new(true)),
                Arc::new(AtomicBool::new(true)),
                Arc::new(Mutex::new("strength".to_string())),
                None,
                None,
                None,
                #[cfg(feature = "snapshot-dedup")]
                None,
                |c, _, _, _| {
                    mirror.lock().unwrap().0 = c.loop_cycle;
                    true // script/cheat/nav work due: never park
                },
                |_| stop2.load(Ordering::Relaxed),
                |_| RandomClaim::Host,
            );
        });
        // Same gate as the focused test: ≥12 ticks in 5 s is unreachable
        // for a parked slot (≤8), so this proves a busy slot never parks.
        let deadline = Instant::now() + Duration::from_secs(5);
        loop {
            let cycles = seen.lock().unwrap().0;
            if cycles >= 12 {
                break;
            }
            assert!(
                Instant::now() < deadline,
                "a busy (scripted) slot must keep ticking, {cycles} ticks in 5 s"
            );
            thread::sleep(Duration::from_millis(10));
        }
        stop.store(true, Ordering::Relaxed);
        handle.join().unwrap();
    }

    #[test]
    fn watch_only_sidecar_parks_wakes_once_per_second_and_paints() {
        force_cpu_backend();
        let (wake, park) = crate::slot_io::wake_channel();
        let (mirror, seen) = seen();
        let buf = FrameBuf::new();
        let buf2 = Arc::clone(&buf);
        let stop = Arc::new(AtomicBool::new(false));
        let stop2 = Arc::clone(&stop);
        let handle = thread::spawn(move || {
            let mut c = prepare_client(
                cfg(),
                1,
                Arc::new(Cache::default()),
                Arc::new(vec![]),
                Vec::new(),
            );
            c.set_draw(true);
            c.ingame = true;
            c.scene_state = 2;
            Host::run_client(
                &mut c,
                "sidecar",
                ProfileSettings::default(),
                Arc::new(AtomicBool::new(true)),
                Arc::new(AtomicBool::new(true)),
                Arc::new(Mutex::new("strength".to_string())),
                None,
                Some(buf2),
                Some(Arc::new(park)),
                #[cfg(feature = "snapshot-dedup")]
                None,
                |c, _, _, _| {
                    mirror.lock().unwrap().0 = c.loop_cycle;
                    false
                },
                |_| stop2.load(Ordering::Relaxed),
                |_| RandomClaim::Host,
            );
        });
        // The rising edge paints the first frame, then the slot parks.
        // Poll for the first paint — no fixed sleep, because under parallel
        // `--workspace` load the slot thread can be delayed arbitrarily.
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            if buf.generation() >= 1 {
                break;
            }
            assert!(
                Instant::now() < deadline,
                "watch-only sidecar never painted its first frame"
            );
            thread::sleep(Duration::from_millis(10));
        }
        let g0 = buf.generation();
        assert!(g0 >= 1, "watch-only rising edge must paint the first frame");
        // The second paint is gated on a wall-clock second since the first
        // (the elapsed-time paint decision), so it must still arrive on the
        // 1 s park — poll for it with a generous deadline.
        let second = Instant::now();
        let deadline = second + Duration::from_secs(10);
        loop {
            if buf.generation() >= g0 + 2 {
                break;
            }
            assert!(
                Instant::now() < deadline,
                "watch-only sidecar never repainted (gen stuck at {})",
                buf.generation()
            );
            thread::sleep(Duration::from_millis(10));
        }
        assert!(
            second.elapsed() >= Duration::from_millis(900),
            "watch-only repaint must wait a wall-clock second, not every tick"
        );
        // Parking proof: a 20 ms loop would tick ~100× in 2.2 s; the 1 s
        // park stays near 2–3 wakes.
        let t1 = seen.lock().unwrap().0;
        thread::sleep(Duration::from_secs(2) + Duration::from_millis(200));
        let t2 = seen.lock().unwrap().0;
        let ticks = t2 - t1;
        assert!(
            (1..=5).contains(&ticks),
            "watch-only sidecar must wake ~1×/s, not 50×/s: ticks {t1} -> {t2} ({ticks} in 2.2 s)"
        );
        stop.store(true, Ordering::Relaxed);
        wake.wake();
        handle.join().unwrap();
    }

    #[test]
    fn stop_control_wakes_a_parked_slot_and_returns() {
        let (wake, park) = crate::slot_io::wake_channel();
        let stop = Arc::new(AtomicBool::new(false));
        let stop2 = Arc::clone(&stop);
        let (done_tx, done_rx) = std::sync::mpsc::channel();
        let handle = thread::spawn(move || {
            let mut c = prepare_client(
                cfg(),
                1,
                Arc::new(Cache::default()),
                Arc::new(vec![]),
                Vec::new(),
            );
            Host::run_client(
                &mut c,
                "parked",
                ProfileSettings::default(),
                Arc::new(AtomicBool::new(true)),
                Arc::new(AtomicBool::new(true)),
                Arc::new(Mutex::new("strength".to_string())),
                None,
                None,
                Some(Arc::new(park)),
                #[cfg(feature = "snapshot-dedup")]
                None,
                |_, _, _, _| false,
                |_| stop2.load(Ordering::Relaxed),
                |_| RandomClaim::Host,
            );
            done_tx.send(()).unwrap();
        });
        // Let the slot park, then stop + kick must return it promptly.
        thread::sleep(Duration::from_millis(100));
        stop.store(true, Ordering::Relaxed);
        wake.wake();
        done_rx
            .recv_timeout(Duration::from_secs(1))
            .expect("a stop control must wake a parked slot");
        handle.join().unwrap();
    }

    #[test]
    fn draw_kick_wakes_a_parked_slot_into_the_frame_loop() {
        force_cpu_backend();
        let (wake, park) = crate::slot_io::wake_channel();
        let (mirror, seen) = seen();
        let inp = SlotInput::new();
        // The panel mirrors focus into the slot thread via the observe
        // hook (per_frame → `set_draw`, capture → `input.set_enabled`).
        // The kick flips the slot from draw-off to focused+capture, which
        // must wake the park into the 20 ms frame loop.
        let want = Arc::new(AtomicBool::new(false));
        let want2 = Arc::clone(&want);
        let stop = Arc::new(AtomicBool::new(false));
        let stop2 = Arc::clone(&stop);
        let handle = thread::spawn(move || {
            let mut c = prepare_client(
                cfg(),
                1,
                Arc::new(Cache::default()),
                Arc::new(vec![]),
                Vec::new(),
            );
            Host::run_client(
                &mut c,
                "kicked",
                ProfileSettings::default(),
                Arc::new(AtomicBool::new(true)),
                Arc::new(AtomicBool::new(true)),
                Arc::new(Mutex::new("strength".to_string())),
                Some(Arc::clone(&inp)),
                None,
                Some(Arc::new(park)),
                #[cfg(feature = "snapshot-dedup")]
                None,
                |c, _, _, _| {
                    let on = want2.load(Ordering::Relaxed);
                    c.set_draw(on);
                    inp.set_enabled(on);
                    mirror.lock().unwrap().0 = c.loop_cycle;
                    false
                },
                |_| stop2.load(Ordering::Relaxed),
                |_| RandomClaim::Host,
            );
        });
        // Opening tick, then parked (draw off): a quiet window must not
        // advance the tick count.
        thread::sleep(Duration::from_millis(80));
        let before = seen.lock().unwrap().0;
        assert!(before <= 1, "draw-off slot must park, got {before} ticks");
        // The panel flips its draw intent and kicks the parked thread.
        want.store(true, Ordering::Relaxed);
        wake.wake();
        // Gate on the tick count, not a fixed deadline: under parallel load
        // the kicked slot can take a while to run 8 ticks, so give it a
        // generous window (a still-parked slot would be far slower).
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            let t = seen.lock().unwrap().0;
            if t >= before + 8 {
                break; // the kicked slot is ticking again
            }
            assert!(
                Instant::now() < deadline,
                "kicked slot never resumed ticking, {t} ticks in 10 s"
            );
            thread::sleep(Duration::from_millis(10));
        }
        // Then the rate: ≥3 ticks per 300 ms is the ~20 ms cadence (a
        // parked slot yields ≤1), so the kick really re-entered the frame
        // loop instead of just ticking slowly.
        let t1 = seen.lock().unwrap().0;
        thread::sleep(Duration::from_millis(300));
        let t2 = seen.lock().unwrap().0;
        assert!(
            t2 >= t1 + 3,
            "kicked slot must tick at ~20 ms, {t1} -> {t2} over 300 ms"
        );
        stop.store(true, Ordering::Relaxed);
        handle.join().unwrap();
    }

    #[test]
    fn spurious_kick_does_not_busy_loop_a_parked_slot() {
        let (wake, park) = crate::slot_io::wake_channel();
        let (mirror, seen) = seen();
        let stop = Arc::new(AtomicBool::new(false));
        let stop2 = Arc::clone(&stop);
        let (done_tx, done_rx) = std::sync::mpsc::channel();
        let handle = thread::spawn(move || {
            let mut c = prepare_client(
                cfg(),
                1,
                Arc::new(Cache::default()),
                Arc::new(vec![]),
                Vec::new(),
            );
            Host::run_client(
                &mut c,
                "kicked-idle",
                ProfileSettings::default(),
                Arc::new(AtomicBool::new(true)),
                Arc::new(AtomicBool::new(true)),
                Arc::new(Mutex::new("strength".to_string())),
                None,
                None,
                Some(Arc::new(park)),
                #[cfg(feature = "snapshot-dedup")]
                None,
                |c, _, _, _| {
                    mirror.lock().unwrap().0 = c.loop_cycle;
                    false // stays idle after the kick
                },
                |_| stop2.load(Ordering::Relaxed),
                |_| RandomClaim::Host,
            );
            done_tx.send(()).unwrap();
        });
        thread::sleep(Duration::from_millis(80));
        let before = seen.lock().unwrap().0;
        // Two kicks while the slot stays idle: each must wake it once and
        // re-park — an undrained control fd would re-fire every park and
        // spin the thread.
        wake.wake();
        wake.wake();
        thread::sleep(Duration::from_millis(120));
        let after = seen.lock().unwrap().0;
        assert!(
            after <= before + 2,
            "a spurious kick must not busy-loop a parked slot, ticks {before} -> {after}"
        );
        stop.store(true, Ordering::Relaxed);
        wake.wake();
        done_rx
            .recv_timeout(Duration::from_secs(1))
            .expect("stop must still return the slot");
        handle.join().unwrap();
    }

    #[test]
    fn park_prefers_socket_when_control_and_socket_both_ready() {
        use std::io::Write;
        use std::net::TcpListener;

        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let stream =
            client::io::ClientStream::connect(&addr.ip().to_string(), addr.port()).unwrap();
        c.stream = Some(stream);
        let (mut server, _) = listener.accept().unwrap();
        let (wake, park_end) = crate::slot_io::wake_channel();

        server.write_all(&[1]).unwrap();
        let deadline = Instant::now() + Duration::from_secs(2);
        loop {
            let h = stream_wait_handle(c.stream.as_ref().unwrap());
            if slot_io::wait_readable(&[h], Duration::from_millis(0))[0] {
                break;
            }
            assert!(Instant::now() < deadline, "socket never ready");
            thread::sleep(Duration::from_millis(5));
        }
        wake.wake();
        assert_eq!(
            park(&c, Some(&park_end), true, Duration::from_millis(1000)),
            ParkWake::Socket,
            "socket must win when both control and socket are ready"
        );
    }

    #[test]
    fn park_suppresses_socket_when_poll_socket_false() {
        use std::io::Write;
        use std::net::TcpListener;

        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();
        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let stream =
            client::io::ClientStream::connect(&addr.ip().to_string(), addr.port()).unwrap();
        c.stream = Some(stream);
        let (mut server, _) = listener.accept().unwrap();
        let (wake, park_end) = crate::slot_io::wake_channel();

        server.write_all(&[1]).unwrap();
        let deadline = Instant::now() + Duration::from_secs(2);
        loop {
            let h = stream_wait_handle(c.stream.as_ref().unwrap());
            if slot_io::wait_readable(&[h], Duration::from_millis(0))[0] {
                break;
            }
            assert!(Instant::now() < deadline, "socket never ready");
            thread::sleep(Duration::from_millis(5));
        }
        // Socket is readable, but poll_socket=false (stalled path): only control
        // is waited. Without a kick, park must time out instead of busy-spinning.
        let start = Instant::now();
        assert_eq!(
            park(&c, Some(&park_end), false, Duration::from_millis(50)),
            ParkWake::Timeout
        );
        assert!(start.elapsed() >= Duration::from_millis(30));
        wake.wake();
        assert_eq!(
            park(&c, Some(&park_end), false, Duration::from_millis(1000)),
            ParkWake::Control,
            "with socket suppressed, a control kick must still wake as Control"
        );
    }

    #[test]
    fn park_no_fds_sleeps_timeout() {
        let c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let start = Instant::now();
        assert_eq!(
            park(&c, None, true, Duration::from_millis(60)),
            ParkWake::Timeout
        );
        assert!(start.elapsed() >= Duration::from_millis(40));
    }

    /// The guardian kicks from `client_frame` right after `after_drain`
    /// (Task 4): a dialog NPC on a fresh snapshot gets a Talk-to through
    /// the real `Client` driver, and the slot latches `in_flight`.
    #[test]
    fn client_frame_kicks_guardian_after_drain() {
        use client::client::{ClientNpc, ClientPlayer};
        use client::config::NpcType;

        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        // Attached + ingame scene-2 so the `Interactions` preconditions
        // pass; the guardian then sends through the real client driver.
        let listener = std::net::TcpListener::bind("127.0.0.1:0").expect("bind");
        let addr = listener.local_addr().expect("local addr");
        let stream = client::io::ClientStream::connect(&addr.ip().to_string(), addr.port())
            .expect("connect");
        std::mem::forget(listener);
        c.stream = Some(stream);
        c.ingame = true;
        c.scene_state = 2;
        c.map_build_base_x = 0;
        c.map_build_base_z = 0;
        c.self_slot = 0;

        // The local player and a dialog NPC that owns us (overhead name).
        let mut lp = ClientPlayer::at(0, 0);
        lp.name = Some("Test".to_string());
        c.local_player = Some(lp);
        {
            let cache = Arc::get_mut(&mut c.cache).expect("sole cache owner");
            cache.npcs.push(NpcType {
                id: 0,
                name: "Genie".to_string(),
                op: vec![Some("Talk-to".to_string())],
                ..Default::default()
            });
        }
        let mut npc = ClientNpc::at(0, 0);
        npc.r#type = Some(0);
        npc.entity.chat_message = Some("Greetings Test!".to_string());
        c.npc[0] = Some(Box::new(npc));
        c.npc_ids[0] = 0;
        c.npc_count = 1;
        // Dirty families so `after_drain` rebuilds the snapshot.
        c.gens.npc = 1;
        c.gens.player = 1;
        c.gens.scene = 1;

        let mut slot = SlotLoop::new();
        let mut sends = 0u32;
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert!(
            slot.guardian.in_flight,
            "client_frame must run the guardian on a dialog NPC"
        );
        assert!(
            c.out.pos > 0,
            "the Talk-to went out on the real client driver"
        );
    }

    /// Lamp auto is live-mirrored like `random_events`: spawn with auto
    /// off, flip the shared atomic mid-session, and the next guardian
    /// tick rubs without a respawn.
    #[test]
    fn lamp_auto_live_mirror_reaches_guardian_without_respawn() {
        const LAMP_OBJ: i32 = 2528;

        let mut c = prepare_client(
            cfg(),
            1,
            Arc::new(Cache::default()),
            Arc::new(vec![]),
            Vec::new(),
        );
        let listener = std::net::TcpListener::bind("127.0.0.1:0").expect("bind");
        let addr = listener.local_addr().expect("local addr");
        let stream = client::io::ClientStream::connect(&addr.ip().to_string(), addr.port())
            .expect("connect");
        std::mem::forget(listener);
        c.stream = Some(stream);
        ingame_scene2(&mut c);
        c.map_build_base_x = 0;
        c.map_build_base_z = 0;
        {
            let cache = Arc::get_mut(&mut c.cache).expect("sole cache owner");
            while cache.objs.len() <= LAMP_OBJ as usize {
                cache.objs.push(client::config::ObjType::default());
            }
            cache.objs[LAMP_OBJ as usize] = client::config::ObjType {
                id: LAMP_OBJ,
                iop: [None, None, None, Some("Rub".into()), None],
                ..Default::default()
            };
        }
        c.side_icon[3] = 300;
        c.set_iface(
            300,
            IfType {
                id: 300,
                layer_id: 300,
                children: Some(vec![301]),
                ..Default::default()
            },
        );
        c.set_iface(
            301,
            IfType {
                id: 301,
                layer_id: 300,
                r#type: client::config::if_type::ComponentType::TYPE_INV,
                obj_ops: true,
                ..Default::default()
            },
        );
        c.set_iface_mut(
            301,
            IfTypeMut {
                link_obj_type: Some(vec![LAMP_OBJ + 1, 0]),
                link_obj_number: Some(vec![1, 0]),
                ..Default::default()
            },
        );
        c.gens.inv = 1;
        c.gens.iface = 1;
        c.gens.scene = 1;
        c.gens.player = 1;

        let lamp_auto = Arc::new(AtomicBool::new(false));
        let lamp_skill = Arc::new(Mutex::new("strength".to_string()));
        let mut slot = SlotLoop {
            settings: ProfileSettings {
                lamp_auto: false,
                ..ProfileSettings::default()
            },
            random_events: Arc::new(AtomicBool::new(true)),
            lamp_auto: Arc::clone(&lamp_auto),
            lamp_skill: Arc::clone(&lamp_skill),
            ..SlotLoop::new()
        };
        let mut sends = 0u32;
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert!(
            c.out.pos == 0,
            "lamp_auto off at spawn: guardian must not rub"
        );

        lamp_auto.store(true, Ordering::Relaxed);
        c.gens.player = 2;
        Host::client_frame(&mut c, &mut slot, "t", None, None, &mut sends, None);
        assert!(
            c.out.pos > 0,
            "lamp_auto flipped live: next guardian tick must rub"
        );
    }

    #[test]
    fn bot_debug_env_requires_exact_one_and_handles_all_values() {
        use std::ffi::OsStr;

        assert!(!debug_env_value(None));
        assert!(!debug_env_value(Some(OsStr::new("0"))));
        assert!(debug_env_value(Some(OsStr::new("1"))));
        assert!(!debug_env_value(Some(OsStr::new("true"))));
        assert!(!debug_env_value(Some(OsStr::new("1 "))));
        #[cfg(unix)]
        {
            use std::os::unix::ffi::OsStrExt;
            assert!(!debug_env_value(Some(OsStr::from_bytes(b"\xff"))));
        }
    }

    #[test]
    fn bot_debug_env_cache_initializes_once() {
        use std::sync::atomic::AtomicUsize;

        let cache = OnceLock::new();
        let reads = AtomicUsize::new(0);
        assert!(!*cache.get_or_init(|| {
            reads.fetch_add(1, Ordering::Relaxed);
            false
        }));
        // The second check is the production fast path: the initializer is
        // not called again after the environment decision is cached.
        assert!(!*cache.get_or_init(|| {
            reads.fetch_add(1, Ordering::Relaxed);
            true
        }));
        assert_eq!(reads.load(Ordering::Relaxed), 1);
    }

    #[test]
    fn set_debug_is_a_live_latch_independent_of_cached_environment() {
        let env_enabled = *BOT_DEBUG_ENV.get_or_init(read_bot_debug_env);
        set_debug(false);
        assert_eq!(debug_enabled(), env_enabled);
        set_debug(true);
        assert!(debug_enabled());
        set_debug(false);
        assert_eq!(debug_enabled(), env_enabled);
    }
}
