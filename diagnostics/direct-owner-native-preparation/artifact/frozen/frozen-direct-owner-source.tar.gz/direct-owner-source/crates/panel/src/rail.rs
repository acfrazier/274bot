//! Sidecar rail chrome: window geometry, the tile size, and the traffic
//! light that colours each member's cap dot.

/// Width of the MultiBox sidecar rail (rs2b0t's 264px strip).
pub const RAIL_W: f32 = 264.0;
/// Cap-body tile draw size inside the rail (rs2b0t ~236×155).
pub const TILE_W: f32 = 236.0;
pub const TILE_H: f32 = 155.0;
/// Default OS window without the rail (game + 330 chrome).
pub const BASE_WINDOW_W: f32 = 1120.0;
/// Default OS window height.
pub const BASE_WINDOW_H: f32 = 580.0;

/// Minimum inner size so the native 765×503 blit is not covered by the
/// 330px panel (and the 264px rail when open).
pub fn os_window_size(rail_open: bool) -> (f32, f32) {
    (
        BASE_WINDOW_W + if rail_open { RAIL_W } else { 0.0 },
        BASE_WINDOW_H,
    )
}

/// Next OS inner size when the rail opens or closes. Opening grows to
/// at least the rail-open minimum. Closing subtracts [`RAIL_W`] (the
/// MultiBox strip on the 274bot panel) and never goes below the
/// closed minimum — a window the operator stretched keeps the extra.
pub fn next_os_window_size(
    current: (f32, f32),
    rail_was_open: bool,
    rail_open: bool,
) -> (f32, f32) {
    let (need_w, need_h) = os_window_size(rail_open);
    if rail_was_open && !rail_open {
        ((current.0 - RAIL_W).max(need_w), current.1.max(need_h))
    } else {
        (current.0.max(need_w), current.1.max(need_h))
    }
}

/// Rail split so the sidecar stays [`RAIL_W`] px at `window_w`.
pub fn rail_split_ratio(window_w: f32) -> f32 {
    (RAIL_W / window_w.max(1.0)).clamp(0.05, 0.85)
}

/// Status dot glyph (U+2059), colored by [`Light::rgb`].
pub const STATUS_GLYPH: &str = "\u{2059}";
/// Remove glyph (U+2717), drawn in `theme::ERROR` red.
pub const REMOVE_GLYPH: &str = "\u{2717}";
/// Fold the rail blit (squash the head). Operator may swap; see spec.
pub const FOLD_GLYPH: &str = "\u{2582}";
/// Unfold the rail blit (raise the head).
pub const UNFOLD_GLYPH: &str = "\u{2585}";

/// Cap dot state: error red wins, then not-ingame grey (logged out),
/// then running green, else idle yellow. A FIFO-queued login slot is not
/// ingame, so it is grey.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Light {
    /// Unknown / logged out — not ingame and no error.
    Grey,
    /// Login or runtime error.
    Red,
    /// Idle — ingame and nothing running (paused/stopping scripts, the
    /// run orb).
    Yellow,
    /// Running — ingame and a script is Running or nav is queued.
    Green,
}

impl Light {
    /// The cap dot's fill color (amber CRT palette).
    pub fn rgb(&self) -> [f32; 4] {
        match self {
            Light::Grey => crate::theme::TEXT_DIM,
            Light::Red => crate::theme::ERROR,
            Light::Yellow => crate::theme::ACCENT,
            Light::Green => crate::theme::GREEN,
        }
    }

    /// Short status label for the cap head title (`"{name}: {brief}"`).
    pub fn brief(&self) -> &'static str {
        match self {
            Light::Grey => "logged out",
            Light::Red => "error",
            Light::Yellow => "idle",
            Light::Green => "running",
        }
    }
}

/// The cap head title: member name plus the light's brief status.
pub fn cap_title(name: &str, light: Light) -> String {
    format!("{name}: {}", light.brief())
}

/// Whether this rail/grid tile shows its blit. `only_selected` stays
/// cap-only. Default: grid keeps every blit (the grid *is* the Game pane);
/// the sidecar folds the focused member (the Game pane already shows it).
pub fn rail_preview_open(
    name: &str,
    focused: Option<&str>,
    only_selected: bool,
    grid: bool,
    preview: &std::collections::HashMap<String, bool>,
) -> bool {
    if only_selected {
        return false;
    }
    preview
        .get(name)
        .copied()
        .unwrap_or(grid || focused != Some(name))
}

/// Map a slot's status to its tile's traffic light: error red wins, then
/// not-ingame → grey, then running → green, else idle yellow.
pub fn traffic_light(ingame: bool, error: bool, running: bool) -> Light {
    if error {
        Light::Red
    } else if !ingame {
        Light::Grey
    } else if running {
        Light::Green
    } else {
        Light::Yellow
    }
}

#[cfg(test)]
mod tests {
    use super::{
        cap_title, os_window_size, rail_preview_open, rail_split_ratio, traffic_light, Light,
        BASE_WINDOW_H, BASE_WINDOW_W, FOLD_GLYPH, RAIL_W, REMOVE_GLYPH, STATUS_GLYPH, TILE_H,
        TILE_W, UNFOLD_GLYPH,
    };

    #[test]
    fn rail_constants_match_the_plan() {
        assert_eq!(RAIL_W, 264.0);
        assert_eq!(TILE_W, 236.0);
        assert_eq!(TILE_H, 155.0);
        assert_eq!(crate::theme::RAIL_WINDOW, "274bot-rail");
    }

    #[test]
    fn rail_preview_defaults_fold_focused() {
        let empty = std::collections::HashMap::new();
        assert!(
            !rail_preview_open("a", Some("a"), false, false, &empty),
            "sidecar folds the focused blit by default"
        );
        assert!(
            rail_preview_open("b", Some("a"), false, false, &empty),
            "other members show a blit by default"
        );
        assert!(!rail_preview_open("b", Some("a"), true, false, &empty));
        assert!(
            rail_preview_open("a", Some("a"), false, true, &empty),
            "grid keeps the focused blit — there is no separate Game pane"
        );
        let mut on = std::collections::HashMap::new();
        on.insert("a".into(), true);
        assert!(rail_preview_open("a", Some("a"), false, false, &on));
    }

    #[test]
    fn os_window_grows_by_rail_width_and_keeps_height() {
        assert_eq!(os_window_size(false), (BASE_WINDOW_W, BASE_WINDOW_H));
        assert_eq!(
            os_window_size(true),
            (BASE_WINDOW_W + RAIL_W, BASE_WINDOW_H)
        );
        let r = rail_split_ratio(2000.0);
        assert!((r * 2000.0 - RAIL_W).abs() < 0.01);
    }

    #[test]
    fn next_os_window_size_shrinks_when_the_rail_closes() {
        let base = os_window_size(false);
        let rail = os_window_size(true);
        assert_eq!(
            super::next_os_window_size(base, false, true),
            rail,
            "MultiBox on grows by the strip"
        );
        assert_eq!(
            super::next_os_window_size(rail, true, false),
            base,
            "MultiBox off on the 274bot panel re-shrinks by the strip"
        );
        let stretched = (rail.0 + 80.0, rail.1);
        assert_eq!(
            super::next_os_window_size(stretched, true, false),
            (base.0 + 80.0, base.1),
            "an operator-stretched window keeps the extra after the strip closes"
        );
        assert_eq!(
            super::next_os_window_size(stretched, false, false),
            stretched,
            "already-closed must not keep subtracting RAIL_W every frame"
        );
    }

    #[test]
    fn traffic_light_maps_all_four_states() {
        // Unknown / logged out: not ingame, no error.
        assert_eq!(traffic_light(false, false, false), Light::Grey);
        // A FIFO-queued login slot is not ingame, so it is grey, not running.
        assert_eq!(traffic_light(false, false, true), Light::Grey);
        // Error red wins over ingame and running.
        assert_eq!(traffic_light(false, true, false), Light::Red);
        assert_eq!(traffic_light(true, true, true), Light::Red);
        assert_eq!(traffic_light(false, true, true), Light::Red);
        // Idle yellow: ingame and nothing running.
        assert_eq!(traffic_light(true, false, false), Light::Yellow);
        // Running green: ingame and (script running or nav queued).
        assert_eq!(traffic_light(true, false, true), Light::Green);
    }

    #[test]
    fn idle_is_not_running() {
        // Paused / Stopping scripts and the run orb are not running.
        assert_ne!(
            traffic_light(true, false, false),
            traffic_light(true, false, true)
        );
        // A queued-login (title screen) slot is not running either.
        assert_eq!(traffic_light(false, false, true), Light::Grey);
    }

    #[test]
    fn brief_labels_each_state() {
        assert_eq!(Light::Grey.brief(), "logged out");
        assert_eq!(Light::Red.brief(), "error");
        assert_eq!(Light::Yellow.brief(), "idle");
        assert_eq!(Light::Green.brief(), "running");
    }

    #[test]
    fn cap_title_renders_name_and_brief() {
        assert_eq!(cap_title("bob", Light::Grey), "bob: logged out");
        assert_eq!(cap_title("bob", Light::Red), "bob: error");
        assert_eq!(cap_title("bob", Light::Yellow), "bob: idle");
        assert_eq!(cap_title("bob", Light::Green), "bob: running");
    }

    #[test]
    fn cap_glyphs_are_the_spec_code_points() {
        assert_eq!(STATUS_GLYPH, "\u{2059}");
        assert_eq!(REMOVE_GLYPH, "\u{2717}");
        assert_eq!(FOLD_GLYPH, "\u{2582}");
        assert_eq!(UNFOLD_GLYPH, "\u{2585}");
    }
}
